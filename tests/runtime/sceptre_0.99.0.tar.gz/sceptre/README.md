
<!-- README.md is generated from README.Rmd. Please edit that file -->

# sceptre <img src="man/figures/logo.png" align="right" width="150" alt="sceptre hex sticker" />

<!-- badges: start -->
[![R-CMD-check (main)](https://img.shields.io/github/actions/workflow/status/Katsevich-Lab/sceptre/check-standard.yaml?branch=main&cacheSeconds=30)](https://github.com/Katsevich-Lab/sceptre/actions/workflows/check-standard.yaml?query=branch%3Amain)
[![Installed coverage workflow (main)](https://img.shields.io/github/actions/workflow/status/Katsevich-Lab/sceptre/coverage.yaml?branch=main&label=coverage%20workflow)](https://github.com/Katsevich-Lab/sceptre/actions/workflows/coverage.yaml?query=branch%3Amain)
[![Development version 0.99.0](https://img.shields.io/badge/development-0.99.0-blue)](DESCRIPTION)
[![License GPL-3](https://img.shields.io/badge/license-GPL--3-blue)](LICENSE.md)
[![Documentation](https://img.shields.io/badge/docs-analysis%20book-blue)](https://timothy-barry.github.io/sceptre-book/)
[![Citations](https://img.shields.io/badge/cite-method%20references-blue)](inst/CITATION)
<!-- badges: end -->

Workflow badges track **main**, not an unmerged PR. Each coverage run retains
separate measured R and native coverage badges and browsable reports in its
[Actions artifact](https://github.com/Katsevich-Lab/sceptre/actions/workflows/coverage.yaml).
See [coverage scope and local reproduction](tools/coverage/README.md).

`sceptre` implements an analysis pipeline for single-cell CRISPR screen
(i.e., Perturb-seq) data, including data import, gRNA-to-cell
assignment, quality control, and testing association between CRISPR
perturbations and changes in gene expression. It is built on three
principles:

- **Statistical rigor.** Association testing is built on a principled
  resampling-based methodology. Built-in calibration and power checks
  let you verify that false positives are controlled and that real
  effects are detectable — on your own data.
- **Massive scalability.** Optimized C++ routines improve performance.
  Optional [disk-backed data
  structures](https://github.com/timothy-barry/ondisc) allow the
  analysis of datasets too large to fit in memory. The companion
  [`sceptre` Nextflow
  pipeline](https://github.com/timothy-barry/sceptre-pipeline)
  distributes analyses across hundreds of processors on a cluster or
  cloud.
- **Ease of use.** A small, pipe-friendly set of functions takes you
  from raw count matrices to results in a handful of steps.

## Installation

Install the development version of `sceptre` from GitHub:

``` r
# install.packages("remotes")
remotes::install_github("Katsevich-Lab/sceptre")
```

### Optional disk-backed analyses

Optional backed analyses are qualified with ondisc source commit
`589803edea2a66ad15e7f07186bee16c7739ab8c`, which includes a pair-iteration
bounds fix. The package version `1.3.5` alone does not identify that source;
CRAN's source with that version lacked the guard during qualification.
In-memory SCEPTRE needs no ondisc installation. For the qualified backed setup,
install a C++ toolchain and the HDF5 requirements for your platform, then run:

```r
# install.packages(c("remotes", "BiocManager"))
BiocManager::install("Rhdf5lib", type = "source")
remotes::install_github(
    "timothy-barry/ondisc@589803edea2a66ad15e7f07186bee16c7739ab8c",
    upgrade = "never"
)
stopifnot(identical(utils::packageDescription("ondisc")$RemoteSha,
    "589803edea2a66ad15e7f07186bee16c7739ab8c"))
```

Backed CRT is still unsupported. Dependency release/distribution follow-up is
separate from enabling any new backend or method.

## Documentation

New to `sceptre`? [Get
started](https://katsevich-lab.github.io/sceptre/articles/sceptre.html)
offers a brief tour of the pipeline, with plots and explanation at each
step. Other resources are the [function
reference](https://katsevich-lab.github.io/sceptre/reference/index.html)
and the comprehensive [`sceptre`
manual](https://timothy-barry.github.io/sceptre-book/).

## Project roadmap and community

`sceptre` is maintained as an open-source research-software project. The
current [roadmap](ROADMAP.md) describes the package’s technical and
sustainability priorities. Please read the [contribution
guide](CONTRIBUTING.md), [governance model](GOVERNANCE.md), and [Code of
Conduct](CODE_OF_CONDUCT.md) before contributing. The [support
guide](SUPPORT.md) explains where to ask questions, report bugs, and
request features.

## Featured publications

- [Barry et al.,
  2024](https://link.springer.com/article/10.1186/s13059-024-03254-2).
  “Robust differential expression testing…”. *Genome Biology*.
- [Barry et al.,
  2024](https://timothy-barry.github.io/biostatistics_2024.pdf).
  “Exponential family measurement error models…”. *Biostatistics.*
- [Morris et al.,
  2023](http://sanjanalab.org/reprints/Morris_Science_2023.pdf).
  “Discovery of target genes and pathways…”. *Science*.
- [Barry et al.,
  2021](https://link.springer.com/article/10.1186/s13059-021-02545-2).
  “SCEPTRE improves calibration and sensitivity…”. *Genome Biology*.

`sceptre` is also featured in a [10x Genomics analysis
guide](https://www.10xgenomics.com/analysis-guides/single-cell-crispr-screen-analysis-with-sceptre).
