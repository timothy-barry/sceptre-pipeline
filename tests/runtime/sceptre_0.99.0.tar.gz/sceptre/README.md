
<!-- README.md is generated from README.Rmd. Please edit that file -->

# sceptre <img src="man/figures/logo.png" align="right" width="150" alt="sceptre hex sticker" />

<!-- badges: start -->

[![R-CMD-check](https://img.shields.io/github/actions/workflow/status/Katsevich-Lab/sceptre/check-standard.yaml?branch=main&cacheSeconds=30)](https://github.com/Katsevich-Lab/sceptre/actions?query=workflow%3AR-CMD-check+branch%3Amain)
<!-- badges: end -->

`sceptre` implements an analysis pipeline for single-cell CRISPR screen
(i.e., Perturb-seq) data, including data import, gRNA-to-cell
assignment, quality control, and testing association between CRISPR
perturbations and changes in gene expression. It is built on three
principles:

- **Statistical rigor.** Association testing is built on a principled
  resampling-based methodology. Built-in calibration and power checks
  let you verify that false positives are controlled and that real
  effects are detectable — on your own data.
- **Massive scalability.** Optimized C++ routines improve performance.
  Optional [disk-backed matrices](https://bioconductor.org/packages/HDF5Array) allow the
  analysis of datasets too large to fit in memory. The companion
  [`sceptre` Nextflow
  pipeline](https://github.com/timothy-barry/sceptre-pipeline)
  distributes analyses across hundreds of processors on a cluster or
  cloud.
- **Ease of use.** A small, pipe-friendly set of functions takes you
  from raw count matrices to results in a handful of steps.

## Installation

Install the development version of `sceptre` from GitHub:

This backend-development branch requires R 4.5 or later, a compatible
Bioconductor installation and a C++17 toolchain. The native matrix interface
uses beachmat >= 2.26 and beachmat.hdf5 >= 1.8. Local qualification currently
uses R 4.6; older releases and hosted CI remain separate qualification targets.
Install this local development checkout with `R CMD INSTALL .` after installing
its dependencies.

``` r
# install.packages("remotes")
remotes::install_github("Katsevich-Lab/sceptre")
```

### Native Bioconductor counts

This candidate stores counts directly as ordinary `DelayedMatrix` objects.
`CountStore` and `BackedCountStore` are removed. Native HDF5 counts use
HDF5Array, and transient beachmat readers provide numerical access. The ondisc
package is not a dependency of this candidate; the preserved legacy package is
used separately for benchmarks.

`import_data(..., use_hdf5 = TRUE, directory_to_write = ...)` writes native
sparse HDF5 counts. The historical `use_ondisc = TRUE` argument now aliases
this native path. Existing ODM files and saved ODM wrappers require reimport;
keep the legacy package available when converting old analyses.

`write_sceptre_object(object, file)` and `read_sceptre_object(file)` verify
anchored backing content. Count files remain external. To relocate them, supply
matching native descriptors through the reader's `response_matrix` and
`grna_matrix` arguments. Copies with changed values, feature order, cell order
or view metadata are rejected. Ordinary base R serialization also preserves the
native descriptors but does not copy backing files.

### Standard matrix backends

`import_data()` also accepts native supported `DelayedMatrix` assays, including
HDF5Array matrices. Existing backing files remain in place and the count
matrices stay backed. Both physical row and column layouts are supported;
use feature-major sparse storage for repeated gene and guide reads. Import
preserves physical layout. Column-oriented HDF5 can be much slower for these
operations; accepting the assay does not make its layout efficient.
Native readers are opened inside each worker and reused across its response
rows, then closed on success or error. They are never serialized in the
analysis object. Unknown seeds and delayed
arithmetic are rejected rather than silently falling back to R block reads.

```r
# response_counts and guide_counts are complete feature-by-cell raw assays.
object <- import_data(
    response_counts, guide_counts, guide_metadata, moi = "low"
)

# Or import an SCE whose guide alternative experiment is named "gRNA".
object <- import_from_sce(sce, guide_metadata, moi = "low")
```

Standard count inputs must be finite nonnegative integer UMI counts; fractional
counts are rejected rather than rounded. Cell summaries retain SCEPTRE's
detected-feature counts, first-row maximum ties and empty-cell conventions.
Ordinary import validates counts while computing these summaries in one pass.
Supply the complete feature library:
normalization or upstream feature removal changes the covariates. Gene symbols
for mitochondrial identification can be supplied through `response_names`, or
through `response_name_column` when importing an SCE.

For standard backed guide assays with `vector_id`, also supply
`directory_to_write`. Aggregation writes a new sparse HDF5 file there, using
native sparse sums one vector at a time. Guide
covariates are calculated after aggregation. Input backing files are unchanged. Native
`DelayedMatrix` assays with RAM seeds instead aggregate into sparse RAM storage
and do not require an output directory.

`base::saveRDS()` preserves descriptors while backing files remain at their
saved locations; use the validated helpers above when saving for continued
analysis or relocating files.

## Documentation

New to `sceptre`? [Get
started](https://katsevich-lab.github.io/sceptre/articles/sceptre.html)
offers a brief tour of the pipeline, with plots and explanation at each
step. Other resources are the [function
reference](https://katsevich-lab.github.io/sceptre/reference/index.html)
and the comprehensive [`sceptre`
manual](https://timothy-barry.github.io/sceptre-book/).

## Project roadmap and community

`sceptre` is maintained as an open-source research-software project. The
current [roadmap](ROADMAP.md) describes the package’s technical and
sustainability priorities. Please read the [contribution
guide](CONTRIBUTING.md), [governance model](GOVERNANCE.md), and [Code of
Conduct](CODE_OF_CONDUCT.md) before contributing. The [support
guide](SUPPORT.md) explains where to ask questions, report bugs, and
request features.

## Featured publications

- [Barry et al.,
  2024](https://link.springer.com/article/10.1186/s13059-024-03254-2).
  “Robust differential expression testing…”. *Genome Biology*.
- [Barry et al.,
  2024](https://timothy-barry.github.io/biostatistics_2024.pdf).
  “Exponential family measurement error models…”. *Biostatistics.*
- [Morris et al.,
  2023](http://sanjanalab.org/reprints/Morris_Science_2023.pdf).
  “Discovery of target genes and pathways…”. *Science*.
- [Barry et al.,
  2021](https://link.springer.com/article/10.1186/s13059-021-02545-2).
  “SCEPTRE improves calibration and sensitivity…”. *Genome Biology*.

`sceptre` is also featured in a [10x Genomics analysis
guide](https://www.10xgenomics.com/analysis-guides/single-cell-crispr-screen-analysis-with-sceptre).
