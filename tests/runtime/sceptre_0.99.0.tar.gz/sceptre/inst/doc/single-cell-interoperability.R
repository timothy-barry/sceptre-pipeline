## ----setup, include=FALSE-----------------------------------------------------
has_sce <- requireNamespace("SingleCellExperiment", quietly = TRUE)
knitr::opts_chunk$set(eval = has_sce)

## ----import-sce---------------------------------------------------------------
library(sceptre)
library(SingleCellExperiment)
data("lowmoi_example_data")
x <- lowmoi_example_data
sce <- SingleCellExperiment(
    assays = list(counts = x$response_matrix),
    colData = S4Vectors::DataFrame(x$extra_covariates))
altExp(sce, "gRNA") <- SummarizedExperiment::SummarizedExperiment(
    assays = list(counts = x$grna_matrix))
object <- import_from_sce(sce, x$grna_target_data_frame, "low",
    covariates = "batch")

## ----analyze-export-sce-------------------------------------------------------
target <- x$grna_target_data_frame$grna_target[1L]
pairs <- data.frame(grna_target = target, response_id = rownames(sce)[1L])
object <- set_analysis_parameters(object, discovery_pairs = pairs,
    formula_object = ~ log(response_n_umis), control_group = "complement",
    resampling_approximation = "no_approximation", side = "left")
# Transparent demonstration caller, not a universal recommended threshold.
calls <- x$grna_matrix >= 5
object <- set_grna_assignments(object, calls, "example caller: raw UMI >=5")
object <- run_qc(object, response_n_umis_range = c(0, 1),
    response_n_nonzero_range = c(0, 1), p_mito_threshold = 1,
    n_nonzero_trt_thresh = 3L, n_nonzero_cntrl_thresh = 3L)
object <- run_discovery_analysis(object, print_progress = FALSE)
returned <- export_results_to_sce(object, sce)
S4Vectors::metadata(returned)$sceptre$results$run_discovery_analysis

## ----session-information, eval=TRUE-------------------------------------------
sessionInfo()

