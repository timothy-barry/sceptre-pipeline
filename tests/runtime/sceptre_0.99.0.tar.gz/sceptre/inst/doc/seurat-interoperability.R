## ----setup, include=FALSE-----------------------------------------------------
has_seurat <- requireNamespace("SeuratObject", quietly = TRUE) &&
    utils::packageVersion("SeuratObject") >= "5.0.0"
knitr::opts_chunk$set(eval = has_seurat)

## ----import-seurat------------------------------------------------------------
library(sceptre)
library(SeuratObject)
data("lowmoi_example_data")
x <- lowmoi_example_data
metadata <- x$grna_target_data_frame
# Seurat replaces underscores in feature IDs. Make a transparent source mapping
# before construction, then keep and supply the actual stored identifiers.
metadata$original_grna_id <- metadata$grna_id
ids <- paste0("guide", seq_len(nrow(x$grna_matrix)))
rownames(x$grna_matrix) <- metadata$grna_id <- ids
s <- CreateSeuratObject(
    counts = Matrix::Matrix(x$response_matrix, sparse = TRUE),
    meta.data = x$extra_covariates, min.cells = 0, min.features = 0)
s[["gRNA"]] <- CreateAssay5Object(
    counts = Matrix::Matrix(x$grna_matrix, sparse = TRUE),
    min.cells = 0, min.features = 0)
object <- import_from_seurat(s, metadata, "low", covariates = "batch")

## ----analyze-export-seurat----------------------------------------------------
pairs <- data.frame(response_id = rownames(x$response_matrix)[1L],
                    grna_target = metadata$grna_target[1L])
object <- set_analysis_parameters(object, discovery_pairs = pairs,
    formula_object = ~ log(response_n_umis), control_group = "complement",
    side = "left", resampling_approximation = "no_approximation")
object <- set_grna_assignments(object, x$grna_matrix >= 5,
    "demonstration raw UMI >=5 caller")
object <- run_qc(object, response_n_umis_range = c(0, 1),
    response_n_nonzero_range = c(0, 1), p_mito_threshold = 1,
    n_nonzero_trt_thresh = 3L, n_nonzero_cntrl_thresh = 3L)
object <- run_discovery_analysis(object, print_progress = FALSE)
returned <- export_results_to_seurat(object, s)
Misc(returned, slot = "sceptre")$results$run_discovery_analysis

## ----session-information, eval=TRUE-------------------------------------------
sessionInfo()

