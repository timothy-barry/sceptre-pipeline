test_that("prepared public analysis hashes stages once at entry and freshly before commit", {
    object <- refactor_prepare(refactor_make_inputs(), refactor_case_definitions()$high_complement_crt)
    counts <- new.env(parent = emptyenv())
    counts$stage <- stats::setNames(integer(4L), preparation_stage_names())
    counts$inputs <- 0L
    stage <- stage_input_identity
    inputs <- analysis_input_identity
    testthat::local_mocked_bindings(
        stage_input_identity = function(object, name, ...) {
            counts$stage[[name]] <- counts$stage[[name]] + 1L
            stage(object, name, ...)
        },
        analysis_input_identity = function(...) {
            counts$inputs <- counts$inputs + 1L
            inputs(...)
        }, .package = "sceptre")
    result <- suppressMessages(run_discovery_analysis(object, print_progress = FALSE))
    expect_identical(unname(counts$stage), rep(2L, 4L))
    expect_identical(counts$inputs, 2L)
    expect_true(result_record_is_current(result, "run_discovery_analysis"))
})

test_that("entry status does not inspect unrelated results and refreshes after preparation", {
    inputs <- refactor_make_inputs()
    prepared <- refactor_prepare(inputs, refactor_case_definitions()$high_perm)
    testthat::local_mocked_bindings(
        currentness_result_record_is_current = function(...) stop("unrelated result queried"),
        .package = "sceptre")
    entry <- prepare_analysis_entry(prepared, FALSE, 2L)
    expect_identical(entry$object, prepared)
    expect_true(entry$query$stage("run_qc"))
    initial <- refactor_import(inputs, refactor_case_definitions()$high_perm)
    initial <- set_analysis_parameters(initial, discovery_pairs = inputs$discovery_pairs,
        formula_object = ~ batch + z)
    entry <- suppressMessages(prepare_analysis_entry(initial, FALSE, 2L))
    expect_true(entry$query$stage("assignment"))
    expect_true(entry$query$stage("run_qc"))
    expect_true(stage_complete(entry$object, "run_qc"))
    expect_false(stage_complete(initial, "assignment"))
})

test_that("fresh post-worker guards reject shared table mutations before any publication", {
    for (mechanism in c("high_perm", "high_complement_crt")) {
        for (analysis in analysis_names()) {
            object <- refactor_prepare(refactor_make_inputs(), refactor_case_definitions()[[mechanism]])
            object@preparation@discovery_pairs_with_info <- data.table::as.data.table(object@preparation@discovery_pairs_with_info)
            expect_true(stage_complete(object, "run_qc"))
            worker <- if (mechanism == "high_perm") "run_permutation_analysis" else "run_crt_analysis"
            original <- getFromNamespace(worker, "sceptre")
            invoked <- FALSE
            replacement <- function(...) {
                output <- original(...)
                invoked <<- TRUE
                values <- object@preparation@discovery_pairs_with_info$n_nonzero_trt
                data.table::set(object@preparation@discovery_pairs_with_info,
                    j = "n_nonzero_trt", value = values + 1L)
                output
            }
            execute <- function() {
                arguments <- list(object, print_progress = FALSE)
                if (analysis == "run_calibration_check") arguments <- c(arguments,
                    list(n_calibration_pairs = 4L, calibration_group_size = 2L))
                expect_error(suppressMessages(do.call(getExportedValue("sceptre", analysis), arguments)),
                    "must be called successfully|no longer matches", info = paste(mechanism, analysis))
            }
            withr::with_seed(702, {
                if (worker == "run_permutation_analysis") {
                    testthat::with_mocked_bindings(execute(), run_permutation_analysis = replacement, .package = "sceptre")
                } else {
                    testthat::with_mocked_bindings(execute(), run_crt_analysis = replacement, .package = "sceptre")
                }
            })
            expect_true(invoked)
            expect_true(all(vapply(object@results, is.null, logical(1))))
            expect_length(object@fits@response_fits, 0L)
        }
    }
})

test_that("direct context and calibration phase-two helpers validate fresh inputs", {
    object <- refactor_prepare(refactor_make_inputs(), refactor_case_definitions()$high_perm)
    plan <- make_run_plan(object, "run_discovery_analysis")
    query <- new_currentness_query(object)
    expect_identical(run_plan_identity(object, plan, query), plan@identity)
    changed <- object
    changed@preparation@design_matrix[1L, 1L] <- 2
    expect_error(validate_run_plan(changed, plan), "no longer matches")
    expect_error(prepare_analysis_context(changed, "run_discovery_analysis",
        dplyr::filter(plan@pairs, pass_qc), plan), "no longer matches")
    expect_error(require_stage(changed, "run_qc"), "must be called successfully")
    prepared <- suppressMessages(run_calibration_check_pt_1(object,
        n_calibration_pairs = 4L, calibration_group_size = 2L))
    prepared$object@preparation@design_matrix[1L, 1L] <- 2
    expect_error(run_calibration_check_pt_2(prepared$object, prepared$plan,
        print_progress = FALSE), "must be called successfully|no longer matches")
})

test_that("shared complement certificates equal fresh actual scopes and NT slices stay independent", {
    for (name in c("high_complement_crt", "low_nt_perm")) {
        object <- refactor_prepare(refactor_make_inputs(), refactor_case_definitions()[[name]])
        plan <- make_run_plan(object, "run_discovery_analysis")
        context <- prepare_analysis_context(object, "run_discovery_analysis",
            dplyr::filter(plan@pairs, pass_qc), plan)
        lookup <- make_treatment_index_lookup(context$index)
        for (id in unique(context$pairs$grna_group)) {
            prepared <- prepare_crt_guide(context, id, lookup)
            cells <- if (context$shared_response_fit) context$common_view$source_cells else prepared$view$source_cells
            trt <- if (context$shared_response_fit) prepared$treatment$trt_idxs else prepared$view$trt_fit_pos
            fresh <- perturbation_fit_identity(cells, prepared$design, trt)
            cached <- perturbation_fit_identity(cells, prepared$design, trt,
                if (context$shared_response_fit) context$shared_perturbation_scope else NULL)
            expect_identical(cached, fresh)
        }
        if (!context$shared_response_fit) expect_null(context$shared_perturbation_scope)
    }
})


test_that("checked context and direct analysis retain cache structural admission", {
    object <- refactor_prepare(refactor_make_inputs(), refactor_case_definitions()$high_complement_crt)
    object <- suppressMessages(run_discovery_analysis(object, print_progress = FALSE))
    plan <- make_run_plan(object, "run_discovery_analysis")
    id <- names(object@fits@response_fits)[1L]
    object@fits@response_fits[[id]]$fitted_coefs <- as.character(object@fits@response_fits[[id]]$fitted_coefs)
    expect_error(prepare_analysis_context(object, "run_discovery_analysis",
        dplyr::filter(plan@pairs, pass_qc), plan), "Response fit coefficients|invalid class")
    expect_error(analyze_association_pairs(object, plan@pairs,
        "run_discovery_analysis", output_amount = 1L, print_progress = FALSE,
        parallel = FALSE, n_processors = 2L, log_dir = tempdir(), plan = plan),
        "Response fit coefficients|invalid class")
})
