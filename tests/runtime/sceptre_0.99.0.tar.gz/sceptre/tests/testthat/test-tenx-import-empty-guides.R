test_that("native empty-guide summaries and maximum assignment follow Matrix", {
    standard_matrix_require()
    counts <- Matrix::sparseMatrix(
        i = c(1L, 2L),
        j = c(1L, 3L),
        x = c(8, 6),
        dims = c(2L, 4L),
        dimnames = list(c("g1", "g2"), paste0("cell", 1:4))
    )
    native <- tenx_write_feature_major(
        list(DelayedArray::DelayedArray(methods::as(counts, "RsparseMatrix"))),
        file.path(withr::local_tempdir(), "guides.h5"),
        block_rows = 1L
    )
    expected <- storage_cell_covariates(counts, integer(), FALSE, TRUE)
    actual <- storage_cell_covariates(native, integer(), FALSE, TRUE)
    expect_identical(actual, expected)
    expect_true(all(is.nan(actual$frac_umis_max_feature[c(2L, 4L)])))
    expect_identical(actual$n_umi[c(2L, 4L)], c(0, 0))
    # These are the maximum-assignment defaults in assign_grnas(). Empty-guide
    # cells are excluded through the total-UMI rule, even though NaN fractions
    # do not satisfy the ambiguous-guide comparison.
    assignment <- assign_grnas_to_cells_maximum(
        max_grna = rownames(counts)[actual$max_feature + 1L],
        max_grna_frac_umis = actual$frac_umis_max_feature,
        umi_fraction_threshold = 0.8,
        grna_n_umis = actual$n_umi,
        min_grna_n_umis_threshold = 5L,
        grna_ids = rownames(counts)
    )
    expect_identical(assignment$cells_w_zero_or_twoplus_grnas, c(2L, 4L))
    retained <- lapply(assignment$initial_assignment_list, function(cells) {
        setdiff(cells, assignment$cells_w_zero_or_twoplus_grnas)
    })
    expect_identical(retained, list(g1 = 1L, g2 = 3L))
})
