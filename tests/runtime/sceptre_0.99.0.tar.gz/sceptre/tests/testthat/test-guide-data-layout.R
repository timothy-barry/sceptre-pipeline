guide_layout_input <- function() {
    input <- refactor_make_inputs()
    input$grna_target_data_frame <- input$grna_target_data_frame[
        c(7L, 2L, 5L, 1L), , drop = FALSE
    ]
    input$grna_target_data_frame[[".sceptre_annotation_order"]] <-
        seq_len(nrow(input$grna_target_data_frame)) + 100L
    input$grna_target_data_frame[[".sceptre_annotation_order.1"]] <-
        letters[seq_len(nrow(input$grna_target_data_frame))]
    input$grna_target_data_frame$category <- factor(
        c("b", "a", "b", "a"), levels = c("b", "a", "unused")
    )
    input
}

guide_layout_import <- function(input, backed = FALSE, directory = NULL) {
    suppressMessages(refactor_import(
        input, refactor_case_definitions()$high_perm,
        backed = backed, directory = directory
    ))
}

test_that("guide maxima have guide colData ownership and model covariates stay main", {
    input <- refactor_make_inputs()
    object <- guide_layout_import(input)
    sce <- get_screen_experiment(object)
    main <- SummarizedExperiment::colData(sce)
    guide <- screen_guides(sce)
    guide_cells <- SummarizedExperiment::colData(guide)
    summaries <- screen_guide_summary(sce)
    expect_identical(object@schema_version, 7L)
    expect_identical(screen_meta(sce)$layout, 2L)
    expect_false(any(c("guide_summary_columns", "covariate_names") %in%
        names(screen_meta(sce))))
    expect_identical(names(guide_cells), c("max_grna", "max_grna_frac_umis"))
    expect_identical(guide_cells$max_grna, summaries$max_grna)
    expect_identical(guide_cells$max_grna_frac_umis, summaries$max_grna_frac_umis)
    expect_false(any(c("max_grna", "max_grna_frac_umis",
        ".sceptre_max_grna", ".sceptre_max_grna_frac_umis") %in% names(main)))
    expect_true(all(c("grna_n_umis", "grna_n_nonzero") %in% names(main)))
    expect_identical(main$grna_n_umis, unname(colSums(input$high_grna_matrix)))
    expect_identical(main$grna_n_nonzero,
        as.integer(colSums(input$high_grna_matrix > 0.5)))
    expected_top <- rownames(input$high_grna_matrix)[
        apply(input$high_grna_matrix, 2L, which.max)
    ]
    expected_fraction <- apply(input$high_grna_matrix, 2L, max) /
        colSums(input$high_grna_matrix)
    expect_identical(unname(guide_cells$max_grna), unname(expected_top))
    expect_identical(unname(guide_cells$max_grna_frac_umis),
        unname(expected_fraction))
    expect_identical(screen_cell_covariates(sce), main)
    included <- auto_construct_formula_object(main, include_grna_covariates = TRUE)
    excluded <- auto_construct_formula_object(main, include_grna_covariates = FALSE)
    expect_true(all(c("grna_n_umis", "grna_n_nonzero") %in% all.vars(included)))
    expect_false(any(c("grna_n_umis", "grna_n_nonzero") %in% all.vars(excluded)))
    expect_false(any(c("max_grna", "max_grna_frac_umis") %in% all.vars(included)))
    expect_true(validObject(object))
})

test_that("cell views keep guide-owned summaries aligned independently of main covariates", {
    object <- guide_layout_import(refactor_make_inputs())
    original <- get_screen_experiment(object)
    cells <- c(9L, 2L, 7L, 2L)
    view <- original[, cells]
    expect_identical(SummarizedExperiment::colData(view),
        SummarizedExperiment::colData(original)[cells, , drop = FALSE])
    expect_identical(SummarizedExperiment::colData(screen_guides(view)),
        SummarizedExperiment::colData(screen_guides(original))[cells, , drop = FALSE])
    for (field in names(screen_guide_summary(original))) {
        expect_identical(screen_guide_summary(view)[[field]],
            screen_guide_summary(original)[[field]][cells])
    }
    guide_before <- SummarizedExperiment::colData(screen_guides(view))
    main <- screen_cell_covariates(view)
    main$user_batch <- rep(c("left", "right"), length.out = ncol(view))
    screen_cell_covariates(view) <- main
    expect_identical(SummarizedExperiment::colData(screen_guides(view)), guide_before)
    expect_identical(screen_cell_covariates(view)$user_batch, main$user_batch)
    expect_true(validObject(view))
})

test_that("guide rowData aligns all count rows while access preserves supplied annotation order", {
    input <- guide_layout_input()
    before <- serialize(input, NULL)
    object <- guide_layout_import(input)
    sce <- get_screen_experiment(object)
    guide <- screen_guides(sce)
    rows <- SummarizedExperiment::rowData(guide)
    ids <- rownames(screen_guide_counts(sce))
    expect_identical(nrow(rows), length(ids))
    expect_identical(rownames(rows), ids)
    positions <- match(ids, input$grna_target_data_frame$grna_id)
    expect_identical(rows$grna_target,
        input$grna_target_data_frame$grna_target[positions])
    expect_true(all(is.na(rows$grna_target[is.na(positions)])))
    expect_null(S4Vectors::metadata(guide)$sceptre_annotations)
    expect_identical(S4Vectors::metadata(guide)$sceptre$annotation_order,
        input$grna_target_data_frame$grna_id)
    annotation <- screen_guide_annotations(sce)
    for (field in names(input$grna_target_data_frame)) {
        expect_identical(annotation[[field]],
            input$grna_target_data_frame[[field]], info = field)
    }
    expect_identical(determine_grnas_in_use(object),
        input$grna_target_data_frame$grna_id)
    expect_identical(serialize(input, NULL), before)
    expect_true(validObject(object))
})

test_that("guide row subsets and reorders preserve surviving source annotation order", {
    input <- guide_layout_input()
    sce <- get_screen_experiment(guide_layout_import(input))
    guide <- screen_guides(sce)[c(2L, 7L), ]
    SingleCellExperiment::altExp(sce, "gRNA") <- guide
    rows <- SummarizedExperiment::rowData(screen_guides(sce))
    expect_identical(rownames(rows), rownames(guide))
    keep <- input$grna_target_data_frame$grna_id %in% rownames(guide)
    expected <- input$grna_target_data_frame[keep, , drop = FALSE]
    annotation <- screen_guide_annotations(sce)
    expect_identical(annotation$grna_id, expected$grna_id)
    expect_identical(annotation$grna_target, expected$grna_target)
    expect_identical(annotation$category, expected$category)
    expect_identical(annotation$.sceptre_annotation_order,
        expected$.sceptre_annotation_order)
    expect_false(identical(annotation$grna_id, rownames(guide)))
    expect_true(validObject(sce))
    SingleCellExperiment::altExp(sce, "gRNA") <- guide[integer(), ]
    empty <- screen_guide_annotations(sce)
    expect_identical(nrow(empty), 0L)
    expect_identical(names(empty), names(annotation))
    expect_identical(levels(empty$category), levels(annotation$category))
})

test_that("duplicate and conflicting guide annotation mappings fail without modifying inputs", {
    input <- guide_layout_input()
    for (conflicting in c(FALSE, TRUE)) {
        repeated <- input$grna_target_data_frame[c(1L, 2L, 1L), , drop = FALSE]
        if (conflicting) repeated$grna_target[[3L]] <- "conflicting-target"
        invalid <- input
        invalid$grna_target_data_frame <- repeated
        before <- serialize(invalid, NULL)
        expect_error(guide_layout_import(invalid),
            "one|unique|repeat|duplicat|multiple")
        expect_identical(serialize(invalid, NULL), before)
        object <- guide_layout_import(input)
        original <- serialize(object, NULL)
        expect_error(screen_guide_annotations(object@data) <- repeated,
            "one|unique|repeat|duplicat|multiple")
        expect_identical(serialize(object, NULL), original)
    }
})

test_that("native backed save and reopen retain guide rowData and guide colData", {
    standard_matrix_require()
    input <- guide_layout_input()
    object <- guide_layout_import(input, backed = TRUE,
        directory = withr::local_tempdir())
    sce <- get_screen_experiment(object)
    response <- screen_response_counts(sce)
    guides <- screen_guide_counts(sce)
    expect_true(count_matrix_is_backed(response))
    expect_true(count_matrix_is_backed(guides))
    path <- withr::local_tempfile(fileext = ".rds")
    before <- serialize(object, NULL)
    write_sceptre_object(object, path)
    restored <- read_sceptre_object(path)
    expect_identical(SummarizedExperiment::colData(restored@data),
        SummarizedExperiment::colData(sce))
    expect_identical(SummarizedExperiment::rowData(screen_guides(restored@data)),
        SummarizedExperiment::rowData(screen_guides(sce)))
    expect_identical(SummarizedExperiment::colData(screen_guides(restored@data)),
        SummarizedExperiment::colData(screen_guides(sce)))
    expect_identical(screen_guide_annotations(restored@data),
        screen_guide_annotations(sce))
    expect_identical(screen_guide_summary(restored@data), screen_guide_summary(sce))
    expect_identical(screen_identity(restored@data), screen_identity(sce))
    expect_identical(as.matrix(screen_response_counts(restored@data)),
        as.matrix(input$response_matrix))
    expect_identical(as.matrix(screen_guide_counts(restored@data)),
        as.matrix(input$high_grna_matrix))
    expect_identical(serialize(object, NULL), before)
    expect_true(validObject(restored))
})
