test_that("integer MTX import shares one backing and retains structural zeros", {
    standard_matrix_require()
    skip_if_not_installed("DropletUtils", "1.32.0")
    input <- withr::local_tempdir()
    writeLines(c("guide\tGuide\tCRISPR Guide Capture", "g\tMT-one\tGene Expression",
                 "antibody\tAntibody\tAntibody Capture"), file.path(input, "features.tsv"))
    writeLines(c("a", "b", "c"), file.path(input, "barcodes.tsv"))
    writeLines(c("%%MatrixMarket matrix coordinate integer general", "3 3 6",
                 "1 1 5", "1 3 1", "2 1 2", "2 2 0", "3 1 7", "3 3 3"),
               file.path(input, "matrix.mtx"))
    output <- withr::local_tempdir()
    object <- suppressMessages(import_data_from_10x(input, "low",
        data.frame(grna_id = "guide", grna_target = "non-targeting"), output))
    expect_identical(storage_read_response(get_response_matrix(object), 1L), c(2, 0, 0))
    expect_identical(storage_threshold_row(get_response_matrix(object), 1L, 0), 1:2)
    expect_identical(storage_read_response(get_grna_matrix(object), 1L), c(5, 0, 1))
    expect_identical(dimnames(get_response_matrix(object)), list("g", c("a", "b", "c")))
    expect_identical(DelayedArray::type(get_response_matrix(object)), "integer")
    expect_length(list.files(output, pattern = "\\.h5$", recursive = TRUE), 1L)
})

test_that("maintained 10x writing rejects invalid source entries before normalization", {
    standard_matrix_require()
    skip_if_not_installed("DropletUtils", "1.32.0")
    input <- withr::local_tempdir()
    writeLines(c("g\tG\tGene Expression", "guide\tGuide\tCRISPR Guide Capture"),
               file.path(input, "features.tsv"))
    writeLines(c("a", "b"), file.path(input, "barcodes.tsv"))
    writeLines(c("%%MatrixMarket matrix coordinate integer general", "2 2 4",
                 "1 1 2", "1 1 3", "2 1 5", "2 2 1"), file.path(input, "matrix.mtx"))
    output <- withr::local_tempdir()
    writeLines("preserve", file.path(output, "keep.txt"))
    expect_error(suppressMessages(import_data_from_10x(input, "low",
        data.frame(grna_id = "guide", grna_target = "non-targeting"), output)),
        "canonical|duplicat")
    expect_identical(list.files(output), "keep.txt")
    for (level in list(-1, 10, 1.5, NA_real_)) {
        expect_error(suppressMessages(import_data_from_10x(input, "low",
            data.frame(grna_id = "guide", grna_target = "non-targeting"), output,
            compression_level = level)), "compression_level")
    }
})

test_that("complex tenx views preserve repeated cells and stored zeros", {
    standard_matrix_require()
    original <- DelayedArray::DelayedArray(standard_matrix_integer_input())
    views <- list(original[c(2, 1, 1), c(8, 1, 8, 4, 2), drop = FALSE],
                  original[c(1, 2), c(1, 4, 8, 11), drop = FALSE])
    for (view in views) {
        output <- tenx_write_feature_major(list(view),
            file.path(withr::local_tempdir(), "view.h5"), 2L, level = 3L)
        expect_identical(dimnames(output), dimnames(view))
        for (row in seq_len(nrow(view))) {
            expect_identical(storage_read_response(output, row), storage_read_response(view, row))
            expect_identical(storage_threshold_row(output, row, 0), storage_threshold_row(view, row, 0))
        }
    }
    output <- tenx_write_feature_major(list(original, original),
        file.path(withr::local_tempdir(), "combined.h5"), 2L, level = 3L)
    for (row in seq_len(nrow(original))) {
        expect_identical(storage_read_response(output, row), rep(storage_read_response(original, row), 2L))
        expected <- storage_threshold_row(original, row, 0)
        expect_identical(storage_threshold_row(output, row, 0), c(expected, expected + ncol(original)))
    }
})


test_that("backed tenx writing retains explicit HDF5 stored zeros", {
    standard_matrix_require()
    expected <- standard_matrix_integer_input()
    input <- standard_matrix_fixture(expected, withr::local_tempdir(),
        preserve_stored_zeros = TRUE)
    output <- tenx_write_feature_major(list(input),
        file.path(withr::local_tempdir(), "backed.h5"), 2L, level = 3L)
    for (row in seq_len(nrow(expected))) {
        expect_identical(storage_read_response(output, row), storage_read_response(expected, row))
        expect_identical(storage_threshold_row(output, row, 0), storage_threshold_row(expected, row, 0))
    }
})
