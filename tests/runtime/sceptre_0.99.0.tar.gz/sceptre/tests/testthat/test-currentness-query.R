# This isolated qualification retains the exact frozen SCE pre-optimization functions.
query_reference <- function() {
    environment <- new.env(parent = asNamespace("sceptre"))
    environment$screen_field <- screen_test_field
    # Compare the frozen traversal against the current semantic providers.
    # The immutable historical source itself remains unchanged.
    for (file in c("workflow_state.R", "result_records.R")) {
        sys.source(test_path("fixtures", "currentness-query", file), environment)
    }
    reference_currentness <- environment$result_record_is_current
    environment$result_record_is_current <- function(object, analysis) {
        records <- stats::setNames(lapply(analysis_names(), function(method) {
            record <- object@results[[analysis_result_key(method)]]
            if (!is.null(record) && is.null(record$scope)) record$scope <- "complete_family"
            record
        }), analysis_names())
        attr(object, "results") <- new("ResultRecord", records = records)
        reference_currentness(object, analysis)
    }
    environment$stage_input_identity <- sceptre:::stage_input_identity
    environment$run_plan_identity <- sceptre:::run_plan_identity
    environment
}

query_fixture <- function() {
    withr::with_seed(91307L, {
        inputs <- readRDS(file.path(refactor_fixture_dir(), "inputs.rds"))
        case <- readRDS(file.path(refactor_fixture_dir(), "cases.rds"))$low_complement_perm
        object <- suppressMessages(refactor_prepare(inputs, case))
        object <- suppressMessages(run_calibration_check(object,
            n_calibration_pairs = 4L, calibration_group_size = 2L,
            print_progress = FALSE, output_amount = 2L))
        object <- suppressMessages(run_power_check(object,
            print_progress = FALSE, output_amount = 2L))
        suppressMessages(run_discovery_analysis(object,
            print_progress = FALSE, output_amount = 2L))
    })
}

query_capture <- function(expression) {
    warnings <- character()
    value <- withCallingHandlers(tryCatch(force(expression), error = function(e) {
        list(error_class = class(e), message = conditionMessage(e))
    }), warning = function(w) {
        warnings <<- c(warnings, conditionMessage(w))
        invokeRestart("muffleWarning")
    })
    list(value = value, warnings = warnings)
}

test_that("query resolver preserves frozen reference status and lazy failures", {
    old <- query_reference()
    complete <- query_fixture()
    variants <- list(complete = complete)
    for (stage in preparation_stage_names()) {
        object <- complete
        object@preparation@stages[[stage]] <- NULL
        variants[[paste0("missing_", stage)]] <- object
    }
    object <- complete
    object@preparation@stages$assignment <- 7L
    object@preparation@stages$pair_qc <- NULL
    variants$atomic_upstream_missing_pair <- object
    object <- complete
    object@results <- new_analysis_results()
    variants$missing_results <- object
    for (analysis in analysis_names()) {
        object <- complete
        object@results[[analysis_result_key(analysis)]]$provenance$plan <- list(broken = TRUE)
        variants[[paste0("malformed_", analysis)]] <- object
        object@results[[analysis_result_key(analysis)]]$scope <- "raw_shard"
        variants[[paste0("shard_", analysis)]] <- object
        object@results[[analysis_result_key(analysis)]]$invalidated_by <- "test change"
        variants[[paste0("invalidated_", analysis)]] <- object
    }
    stages <- c("import_data", preparation_stage_names(), "run_qc",
        "set_analysis_parameters", "assign_grnas", "unknown", "")
    analyses <- c(analysis_names(), "power_check", "unknown", "")
    for (name in names(variants)) {
        object <- variants[[name]]
        expect_identical(query_capture(workflow_status(object)),
            query_capture(old$workflow_status(object)), info = name)
        for (stage in stages) {
            expect_identical(query_capture(stage_complete(object, stage)),
                query_capture(old$stage_complete(object, stage)),
                info = paste(name, stage))
        }
        for (analysis in analyses) {
            expect_identical(query_capture(result_record_is_current(object, analysis)),
                query_capture(old$result_record_is_current(object, analysis)),
                info = paste(name, analysis))
        }
    }
})

test_that("new queries cannot reuse saved certificates after actual payload mutation", {
    old <- query_reference()
    complete <- query_fixture()
    baseline <- workflow_status(complete)
    expect_true(all(baseline))
    saved_stages <- complete@preparation@stages
    mutate <- list(
        design = function(x) { x@preparation@design_matrix[1L, 1L] <- 999; x },
        assignments = function(x) {
            x@preparation@guide_assignments[[1L]] <- rev(x@preparation@guide_assignments[[1L]])
            x
        },
        source_groups = function(x) {
            x@preparation@source_groups$grna_group_idxs[[1L]] <- integer(); x
        },
        cells = function(x) { x@preparation@analysis_cells <- rev(x@preparation@analysis_cells); x },
        analysis_groups = function(x) {
            x@preparation@analysis_groups$grna_group_idxs[[1L]] <- integer(); x
        },
        pairs = function(x) {
            x@preparation@discovery_pairs_with_info$response_id[1L] <- "changed-response"; x
        },
        alpha = function(x) { x@spec@multiple_testing_alpha <- 0.123; x },
        data = function(x) { screen_identity(x@data) <- "changed-data"; x },
        certificate = function(x) { x@preparation@stages$design$identity <- "changed-certificate"; x }
    )
    for (name in names(mutate)) {
        changed <- mutate[[name]](complete)
        if (name != "certificate") expect_identical(changed@preparation@stages, saved_stages)
        expect_identical(workflow_status(changed), old$workflow_status(changed), info = name)
        expect_false(all(workflow_status(changed)), info = name)
        expect_identical(workflow_status(complete), baseline, info = name)
        for (analysis in analysis_names()) {
            expect_identical(result_record_is_current(changed, analysis),
                old$result_record_is_current(changed, analysis), info = paste(name, analysis))
        }
    }
})

test_that("resolver hashes valid stages once and does not retain objects or alter RNG", {
    withr::local_seed(9817L)
    object <- query_fixture()
    before <- serialize(object, NULL)
    seed <- .Random.seed
    calls <- character()
    original <- stage_input_identity
    testthat::local_mocked_bindings(
        stage_input_identity = function(object, stage) {
            calls <<- c(calls, stage)
            original(object, stage)
        }, .package = "sceptre"
    )
    expect_true(all(workflow_status(object)))
    expect_identical(sort(calls), sort(preparation_stage_names()))
    calls <- character()
    query <- new_currentness_query(object)
    expect_true(query$stage("assignment"))
    expect_true(query$stage("assign_grnas"))
    expect_true(query$stage("run_qc"))
    expect_true(query$result("run_power_check"))
    expect_true(query$result("run_power_check"))
    expect_identical(sort(calls), sort(preparation_stage_names()))
    calls <- character()
    expect_true(stage_complete(object, "run_qc"))
    expect_true(stage_complete(object, "run_qc"))
    expect_identical(sort(calls), sort(rep(preparation_stage_names(), 2L)))
    expect_identical(serialize(object, NULL), before)
    expect_identical(.Random.seed, seed)
})

test_that("missing stage records and invalid result records remain short-circuited", {
    object <- query_fixture()
    object@preparation@stages$pair_qc <- NULL
    testthat::local_mocked_bindings(
        prepared_pair_qc_inputs = function(...) stop("must not hash absent stage"),
        result_input_identity = function(...) stop("must not hash invalid result"),
        .package = "sceptre"
    )
    expect_false(stage_complete(object, "pair_qc"))
    expect_false(result_record_is_current(object, "run_power_check"))
    object@preparation@stages$assignment <- 7L
    expect_false(stage_complete(object, "assignment"))
})

test_that("invalid result guards do not evaluate malformed saved plan payloads", {
    complete <- query_fixture()
    testthat::local_mocked_bindings(
        result_input_identity = function(...) stop("must not hash invalid result"),
        .package = "sceptre"
    )
    for (case in c("missing", "not_frame", "empty", "scope", "invalidated", "identity")) {
        object <- complete
        record <- object@results$power_check
        record$provenance$plan <- list(broken = TRUE)
        if (case == "not_frame") record$table <- 1L
        if (case == "empty") record$table <- data.frame()
        if (case == "scope") record$scope <- "raw_shard"
        if (case == "invalidated") record$invalidated_by <- "test change"
        if (case == "identity") record$identity <- NULL
        object@results["power_check"] <- list(if (case == "missing") NULL else record)
        expect_false(result_record_is_current(object, "run_power_check"), info = case)
    }
})

test_that("currentness leaves owned data.tables and saved list plans untouched", {
    withr::local_seed(9818L)
    old <- query_reference()
    object <- query_fixture()
    pairs <- data.table::as.data.table(object@preparation@discovery_pairs_with_info)
    data.table::setattr(pairs, "nested", list(table = data.table::data.table(value = 1L)))
    object@preparation@discovery_pairs_with_info <- pairs
    object <- commit_preparation_stage(object, "pair_qc")
    plan <- make_run_plan(object, "run_discovery_analysis")
    object@results$discovery_analysis$identity <- plan@identity
    object@results$discovery_analysis$provenance$plan <-
        run_plan_payload(plan, include_identity = TRUE)
    object@results$discovery_analysis$table <-
        data.table::as.data.table(object@results$discovery_analysis$table)
    data.table::setattr(object@results$discovery_analysis$table,
        "nested", list(table = data.table::data.table(value = 2L)))
    before <- serialize(object, NULL)
    seed <- .Random.seed
    expected <- old$workflow_status(object)
    expect_identical(workflow_status(object), expected)
    expect_identical(result_record_is_current(object, "run_discovery_analysis"),
        old$result_record_is_current(object, "run_discovery_analysis"))
    expect_identical(serialize(object, NULL), before)
    expect_identical(.Random.seed, seed)
})

test_that("resolver captures the forced object rather than a later caller binding", {
    object <- query_fixture()
    query <- new_currentness_query(object)
    object@preparation@design_matrix[1L, 1L] <- 999
    expect_true(query$stage("run_qc"))
    expect_false(stage_complete(object, "run_qc"))
    expect_true(query$result("run_power_check"))
    expect_false(result_record_is_current(object, "run_power_check"))
})

test_that("fresh public queries notice by-reference table edits between calls", {
    old <- query_reference()
    object <- query_fixture()
    # Keep the prepared family/plan representation intact. Changing their class
    # would itself stale the frozen result before the intended by-reference edit.
    object@spec@discovery_pairs <- data.table::as.data.table(object@spec@discovery_pairs)
    object <- commit_preparation_stage(object, "design")
    expect_true(all(workflow_status(object)))
    expect_true(all(old$workflow_status(object)))
    expect_true(result_record_is_current(object, "run_discovery_analysis"))
    expect_true(old$result_record_is_current(object, "run_discovery_analysis"))
    certificates <- object@preparation@stages
    data.table::set(object@spec@discovery_pairs,
        i = 1L, j = "response_id", value = "changed-response")
    expect_identical(object@preparation@stages, certificates)
    expect_false(stage_complete(object, "design"))
    expect_false(stage_complete(object, "pair_qc"))
    expect_false(result_record_is_current(object, "run_discovery_analysis"))
    expect_identical(workflow_status(object), old$workflow_status(object))
})
