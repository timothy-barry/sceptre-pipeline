# Small examples spell out the current count rules, including differences
# between matrix formats that the refactor must preserve.

test_that("legacy storage retains stored-zero and fractional semantics", {
    mat <- storage_test_matrix()
    expect_identical(
        load_row(mat, "r1"),
        c(0, 0, 0, 2.5, 0, 0, 0, 3.8, 0, 0, 4.2, 0)
    )
    expect_identical(
        threshold_count_matrix(mat@j, mat@p, mat@x, 1L, 2.8),
        c(8L, 11L)
    )
    expect_identical(
        threshold_count_matrix(mat@j, mat@p, mat@x, 1L, 0),
        c(1L, 4L, 8L, 11L)
    )
    # A stored zero is counted by position, even though its loaded value is zero.
    counts <- sparse_pair_counts(
        mat@j,
        mat@p,
        12L,
        list(c(2L, 3L)),
        list(4L, c(1L, 5L)),
        c(1L, 2L),
        c(1L, 1L),
        TRUE,
        c(2L, 4L, 5L, 8L, 11L)
    )
    expect_identical(counts$n_nonzero_trt, c(1L, 1L))
    expect_identical(counts$n_nonzero_cntrl, c(2L, 2L))
    expect_identical(counts$n_nonzero_mat, matrix(c(1L, 1L, 1L, 1L), 2L))
    expect_identical(counts$n_nonzero_tot, c(3L, 3L))
})

test_that("owned sparse group coordinates remain unchanged across calls", {
    mat <- storage_test_matrix()
    groups <- list(c(2L, 3L), c(4L, 1L, 5L))
    before <- serialize(groups, NULL)
    out <- sparse_group_counts(
        mat@j,
        mat@p,
        12L,
        groups,
        c(2L, 4L, 5L, 8L, 11L)
    )
    expect_identical(out, matrix(c(1L, 2L, 1L, 2L), 2L))
    expect_identical(serialize(groups, NULL), before)
    expect_identical(
        sparse_group_counts(mat@j, mat@p, 12L, groups, c(2L, 4L, 5L, 8L, 11L)),
        out
    )
})

test_that("sparse layout conversion preserves independently specified values", {
    mat <- storage_test_matrix()
    for (input in list(
        mat,
        methods::as(mat, "CsparseMatrix"),
        methods::as(mat, "TsparseMatrix"),
        as.matrix(mat)
    )) {
        before <- serialize(input, NULL)
        for (row_access in c(TRUE, FALSE)) {
            actual <- set_matrix_accessibility(input, row_access)
            expect_s4_class(
                actual,
                if (row_access) "RsparseMatrix" else "CsparseMatrix"
            )
            expect_identical(as.matrix(actual), as.matrix(mat))
        }
        expect_identical(serialize(input, NULL), before)
    }
})

test_that("native backed UMI counts preserve stored positions and double thresholds", {
    standard_matrix_require()
    mat <- storage_test_matrix(200L)
    mat@x <- floor(mat@x)
    native <- standard_matrix_fixture(
        mat,
        withr::local_tempdir(),
        preserve_stored_zeros = TRUE
    )
    expect_identical(
        storage_read_response(native, 1L)[c(1L, 4L, 8L, 11L)],
        c(0, 2, 3, 4)
    )
    expect_identical(
        storage_threshold_row(native, 1L, 2.8),
        as.integer(unlist(lapply(0:199, function(block) {
            c(8L, 11L) + 12L * block
        })))
    )
    expect_identical(
        storage_threshold_row(native, 1L, 0),
        as.integer(unlist(lapply(0:199, function(block) {
            c(1L, 4L, 8L, 11L) + 12L * block
        })))
    )
    groups <- list(c(2L, 3L), c(4L, 1L, 5L))
    before <- serialize(groups, NULL)
    expect_identical(
        storage_group_counts(native, 1:2, groups, c(2L, 4L, 5L, 8L, 11L)),
        matrix(c(1L, 2L, 1L, 2L), 2L)
    )
    expect_identical(serialize(groups, NULL), before)
})

test_that("storage reads preserve requested source order and repeated cells", {
    mat <- storage_test_matrix()
    expect_identical(storage_response_index(mat, "r2"), 2L)
    expect_identical(
        storage_read_response(mat, 1L, c(11L, 4L, 11L, 8L, 1L)),
        c(4.2, 2.5, 4.2, 3.8, 0)
    )
    expect_identical(storage_read_response(mat, 2L, 8L), 0)
    expect_identical(storage_read_response(mat, 2L, integer()), numeric())
    expect_identical(storage_read_response(mat, 1L), load_row(mat, "r1"))
    expect_identical(storage_threshold_row(mat, 1L, 2.8), c(8L, 11L))
})

storage_test_contract <- function(mat) {
    cells <- c(2L, 4L, 5L, 8L, 11L)
    groups <- list(A = c(2L, 3L), B = c(4L, 1L, 5L))
    nt_groups <- list(nt1 = 4L, nt2 = c(1L, 5L))
    controls <- c(4L, 1L, 5L)
    pairs <- data.frame(
        response_idx = c(2L, 1L, 2L, 1L),
        group_idx = c(2L, 1L, 1L, 1L)
    )
    original <- serialize(list(cells, groups, nt_groups, controls, pairs), NULL)
    for (control in list("complement", controls)) {
        for (summarize in c(TRUE, FALSE)) {
            out <- expect_no_warning(storage_pair_counts(
                mat,
                pairs,
                groups,
                cells,
                control,
                if (summarize) nt_groups else NULL
            ))
            expect_identical(out$n_nonzero_trt, c(2L, 1L, 1L, 1L))
            expect_identical(
                out$n_nonzero_cntrl,
                if (identical(control, "complement")) {
                    c(1L, 2L, 2L, 2L)
                } else {
                    rep(2L, 4L)
                }
            )
            if (summarize) {
                expect_identical(out$n_nonzero_mat, matrix(rep(1L, 4L), 2L))
                expect_identical(
                    out$n_nonzero_tot,
                    if (identical(control, "complement")) {
                        c(3L, 3L)
                    } else {
                        c(2L, 2L)
                    }
                )
            } else {
                expect_identical(out$n_nonzero_mat, matrix())
                expect_identical(out$n_nonzero_tot, integer())
            }
        }
        # Pair-only API must agree without constructing unused NT summaries.
        pair_only <- expect_no_warning(storage_pair_counts(
            mat,
            pairs,
            groups,
            cells,
            control
        ))
        expect_identical(pair_only$n_nonzero_trt, out$n_nonzero_trt)
        expect_identical(pair_only$n_nonzero_cntrl, out$n_nonzero_cntrl)
        expect_identical(pair_only$n_nonzero_tot, integer())
        empty <- expect_no_warning(storage_pair_counts(
            mat,
            pairs[integer(), ],
            groups,
            cells,
            control
        ))
        expect_identical(empty$n_nonzero_trt, integer())
        expect_identical(empty$n_nonzero_cntrl, integer())
        empty_summary <- expect_no_warning(storage_pair_counts(
            mat,
            pairs[integer(), ],
            groups,
            cells,
            control,
            nt_groups
        ))
        expect_identical(empty_summary$n_nonzero_trt, integer())
        expect_identical(empty_summary$n_nonzero_cntrl, integer())
        expect_identical(empty_summary$n_nonzero_mat, matrix(rep(1L, 4L), 2L))
        expect_identical(
            empty_summary$n_nonzero_tot,
            if (identical(control, "complement")) c(3L, 3L) else c(2L, 2L)
        )
    }
    expected <- matrix(c(1L, 2L, 1L, 2L), 2L)
    for (repeat_call in seq_len(2L)) {
        expect_identical(
            storage_group_counts(mat, c(2L, 1L, 2L), groups, cells),
            expected[, c(2L, 1L, 2L), drop = FALSE]
        )
    }
    expect_identical(
        storage_group_counts(mat, 1L, groups[1L], cells),
        matrix(1L, 1L, 1L)
    )
    expect_identical(
        storage_group_counts(mat, integer(), groups, cells),
        matrix(integer(), 2L, 0L)
    )
    expect_identical(
        storage_group_counts(mat, c(1L, 2L), list(), cells),
        matrix(integer(), 0L, 2L)
    )
    # Reordering cells kept after QC also changes group positions within that
    # list; update both so they still select the same original matrix columns.
    reordered <- storage_pair_counts(
        mat,
        pairs,
        list(c(4L, 5L), c(1L, 2L, 3L)),
        cells[c(4L, 1L, 5L, 2L, 3L)],
        "complement"
    )
    expect_identical(reordered$n_nonzero_trt, c(2L, 1L, 1L, 1L))
    expect_identical(reordered$n_nonzero_cntrl, c(1L, 2L, 2L, 2L))
    expect_identical(
        serialize(list(cells, groups, nt_groups, controls, pairs), NULL),
        original
    )
}

test_that("sparse storage counts preserve requests and caller-owned indices", {
    storage_test_contract(storage_test_matrix())
})

test_that("native backed storage has ordered count, RNG and ownership contracts", {
    standard_matrix_require()
    directory <- withr::local_tempdir()
    mat <- storage_test_matrix(200L)
    mat@x <- floor(mat@x)
    set.seed(79)
    rng <- .Random.seed
    pair <- storage_create_backed_pair(mat, mat, directory)
    expect_identical(.Random.seed, rng)
    expect_s4_class(pair$response_matrix, "DelayedMatrix")
    expect_s4_class(pair$grna_matrix, "DelayedMatrix")
    expect_identical(
        storage_read_response(
            pair$response_matrix,
            1L,
            c(11L, 4L, 11L, 8L, 1L)
        ),
        c(4, 2, 4, 3, 0)
    )
    storage_test_contract(pair$response_matrix)
    reopened <- storage_reopen_backed_pair(
        count_backing_paths(pair$response_matrix),
        count_backing_paths(pair$grna_matrix)
    )
    dimnames(reopened$response_matrix) <- dimnames(pair$response_matrix)
    expect_identical(
        storage_read_response(reopened$response_matrix, 1L),
        storage_read_response(pair$response_matrix, 1L)
    )
    expect_silent(validate_count_backing(
        reopened$response_matrix,
        count_backing_descriptor(pair$response_matrix)
    ))
})
