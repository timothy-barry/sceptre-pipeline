test_that("component count slots contain ordinary DelayedMatrix values", {
    standard_matrix_require()
    counts <- standard_matrix_integer_input()
    before <- serialize(counts, NULL)
    native <- as_count_matrix(counts)
    expect_s4_class(native, "DelayedMatrix")
    expect_identical(DelayedArray::seed(native), counts)
    expect_identical(require_count_matrix(native), native)
    expect_identical(as_count_matrix(native), native)
    expect_identical(serialize(counts, NULL), before)
    expect_null(count_backing_descriptor(native))
    expect_identical(
        getSlots("ScreenData")[["response_matrix"]],
        "DelayedMatrix"
    )
    expect_identical(getSlots("ScreenData")[["grna_matrix"]], "DelayedMatrix")
    expect_true(validObject(new("ScreenData")))
    expect_error(as_count_matrix(list()), "Count matrices must be")
    expect_error(
        as_count_matrix(NULL, list(path = "old.odm")),
        "explicit conversion or reimport"
    )
})

test_that("schema-three Matrix migration preserves scientific certificates", {
    counts <- standard_matrix_integer_input()
    object <- new("sceptre_object")
    object@data <- new_screen_experiment(response_matrix = counts, grna_matrix = counts)
    object <- initialize_screen_identity(object)
    object@preparation@stages <- list(
        saved = list(identity = "saved-certificate")
    )
    # Recreate physical schema-three slots from before the representation
    # change, without using the new slot setter to manufacture an invalid value.
    fields <- names(formals(sceptre:::new_screen_experiment))
    physical <- do.call(methods::new,c(list(Class="ScreenData"),setNames(lapply(fields,function(n)screen_test_field(object@data,n)),fields)))
    attr(physical, "response_matrix") <- counts
    attr(physical, "grna_matrix") <- counts
    attr(object, "data") <- physical
    attr(object,"schema_version") <- 3L
    before <- serialize(object, NULL)
    migrated <- normalize_saved_count_matrices(object)
    expect_s4_class(sceptre:::screen_response_counts(migrated@data), "DelayedMatrix")
    expect_identical(DelayedArray::seed(sceptre:::screen_response_counts(migrated@data)), counts)
    expect_identical(sceptre:::screen_identity(migrated@data), attr(physical,"identity"))
    expect_identical(migrated@preparation, object@preparation)
    expect_identical(serialize(object, NULL), before)
    expect_identical(normalize_saved_count_matrices(migrated), migrated)
})

test_that("native backing identities bind content and delayed views, not locations", {
    standard_matrix_require()
    counts <- standard_matrix_integer_input()
    original <- standard_matrix_fixture(
        counts,
        withr::local_tempdir(),
        preserve_stored_zeros = TRUE
    )
    anchor <- count_backing_descriptor(original)
    expect_match(anchor$content_md5, "^[a-f0-9]{32}$")
    expect_identical(anchor$dimensions, as.integer(dim(counts)))
    expect_identical(anchor$dimnames, dimnames(counts))
    expect_silent(validate_count_backing(original, anchor))
    expect_error(
        validate_count_backing(original[2:1, ], anchor),
        "content does not match"
    )
    expect_error(
        validate_count_backing(original[, 2:1], anchor),
        "content does not match"
    )
    moved_path <- file.path(withr::local_tempdir(), "moved.h5")
    expect_true(file.copy(anchor$files$path, moved_path))
    relocated <- t(HDF5Array::TENxMatrix(moved_path, "counts"))
    dimnames(relocated) <- dimnames(original)
    expect_silent(validate_count_backing(relocated, anchor))
    expect_identical(as.matrix(relocated), as.matrix(original))
    expect_false(identical(
        count_backing_descriptor(relocated)$files$path,
        anchor$files$path
    ))
    object <- new("sceptre_object")
    object@data <- new_screen_experiment(response_matrix = original, grna_matrix = original)
    object <- initialize_screen_identity(object)
    expect_identical(
        screen_backing_anchors(object@data)$response,
        anchor
    )
    expect_silent(validate_count_backing_for_save(object))
    sceptre:::screen_response_counts(object@data) <- relocated
    expect_silent(validate_count_backing_for_save(object))
    path <- file.path(withr::local_tempdir(), "screen.rds")
    base::saveRDS(object, path)
    restored <- readRDS(path)
    expect_identical(
        as.matrix(sceptre:::screen_response_counts(restored@data)),
        as.matrix(counts)
    )
    expect_identical(sceptre:::screen_identity(restored@data), sceptre:::screen_identity(object@data))
    values <- rhdf5::h5read(moved_path, "counts/data")
    values[1L] <- values[1L] + 1
    rhdf5::h5write(values, moved_path, "counts/data")
    expect_error(validate_count_backing_for_save(restored), "content does not match")
    expect_identical(
        screen_backing_anchors(restored@data)$response,
        anchor
    )
})

test_that("cached response summaries validate ordinary counts before native guide aggregation", {
    standard_matrix_require()
    guides <- standard_matrix_integer_input()
    metadata <- data.frame(
        grna_id = rownames(guides),
        grna_target = c("A", "non-targeting"),
        vector_id = c("vector-a", "vector-nt")
    )
    for (invalid in c(0.5, -1, NA_real_, Inf)) {
        responses <- methods::as(guides, "CsparseMatrix")
        responses@x[1L] <- invalid
        directory <- withr::local_tempdir()
        writeLines("preserve", file.path(directory, "keep.txt"))
        expect_error(
            import_data(
                responses,
                DelayedArray::DelayedArray(guides),
                metadata,
                "low",
                directory_to_write = directory
            ),
            "integer.*UMI|UMI.*integer"
        )
        expect_identical(list.files(directory), "keep.txt")
    }
})

test_that("native relocation preserves screens with one backed modality", {
    standard_matrix_require()
    counts <- standard_matrix_integer_input()
    metadata <- data.frame(
        grna_id = rownames(counts),
        grna_target = c("A", "non-targeting")
    )
    for (modality in c("response", "grna")) {
        backed <- standard_matrix_fixture(counts, withr::local_tempdir())
        object <- suppressMessages(import_data(
            if (modality == "response") backed else counts,
            if (modality == "grna") backed else counts,
            metadata,
            "low"
        ))
        path <- file.path(withr::local_tempdir(), "screen.rds")
        write_sceptre_object(object, path)
        relocated_path <- file.path(withr::local_tempdir(), "moved.h5")
        expect_true(file.copy(count_backing_paths(backed), relocated_path))
        relocated <- t(HDF5Array::TENxMatrix(relocated_path, "counts"))
        dimnames(relocated) <- dimnames(backed)
        restored <- read_sceptre_object(
            path,
            if (modality == "response") {
                relocated
            } else {
                get_response_matrix(object)
            },
            if (modality == "grna") relocated else get_grna_matrix(object)
        )
        expect_identical(sceptre:::screen_identity(restored@data), sceptre:::screen_identity(object@data))
        expect_identical(
            as.matrix(get_response_matrix(restored)),
            as.matrix(counts)
        )
        expect_identical(
            as.matrix(get_grna_matrix(restored)),
            as.matrix(counts)
        )
    }
})
