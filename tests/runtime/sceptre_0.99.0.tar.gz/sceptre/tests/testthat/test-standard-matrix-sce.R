test_that("SCE import retains backed counts and symbol-based covariates", {
    standard_matrix_require()
    skip_if_not_installed("SingleCellExperiment")
    skip_if_not_installed("SummarizedExperiment")
    input <- refactor_make_inputs()
    response <- standard_matrix_fixture(
        input$response_matrix,
        tempfile(),
        "sce-response"
    )
    guides <- standard_matrix_fixture(
        input$low_grna_matrix,
        tempfile(),
        "sce-guides"
    )
    sce <- SingleCellExperiment::SingleCellExperiment(
        assays = list(counts = response)
    )
    SingleCellExperiment::altExp(sce, "gRNA", withDimnames = FALSE) <-
        SummarizedExperiment::SummarizedExperiment(
            assays = list(counts = guides)
        )
    SummarizedExperiment::colData(sce)$batch <- input$extra_covariates$batch
    symbols <- c("MT-one", paste0("g", 2:nrow(sce)))
    SummarizedExperiment::rowData(sce)$symbol <- symbols
    imported <- import_from_sce(
        sce,
        input$grna_target_data_frame,
        "low",
        covariates = "batch",
        response_name_column = "symbol"
    )
    expected <- import_data(
        input$response_matrix,
        input$low_grna_matrix,
        input$grna_target_data_frame,
        "low",
        extra_covariates = input$extra_covariates[, "batch", drop = FALSE],
        response_names = symbols
    )
    expect_s4_class(get_response_matrix(imported), "DelayedMatrix")
    expect_s4_class(get_grna_matrix(imported), "DelayedMatrix")
    expect_identical(
        get_cell_covariates(imported),
        get_cell_covariates(expected)
    )
    expect_identical(colnames(sce), colnames(input$response_matrix))
    expect_identical(SummarizedExperiment::assay(sce), response)
    expect_error(
        import_from_sce(
            sce,
            input$grna_target_data_frame[nrow(guides):1, ],
            "low"
        ),
        "metadata"
    )
    expect_error(
        import_from_sce(
            sce,
            input$grna_target_data_frame,
            "low",
            response_assay = "logcounts"
        ),
        "assay"
    )
})

test_that("SCE guides inherit a parent-only cell axis without changing the input", {
    standard_matrix_require()
    skip_if_not_installed("SingleCellExperiment")
    skip_if_not_installed("SummarizedExperiment")
    input <- refactor_make_inputs()
    guides <- input$low_grna_matrix
    colnames(guides) <- NULL
    sce <- SingleCellExperiment::SingleCellExperiment(
        assays = list(counts = input$response_matrix)
    )
    SingleCellExperiment::altExp(sce, "gRNA", withDimnames = FALSE) <-
        SummarizedExperiment::SummarizedExperiment(
            assays = list(counts = guides)
        )
    expect_null(colnames(SingleCellExperiment::altExp(
        sce,
        "gRNA",
        withDimnames = FALSE
    )))
    before <- serialize(sce, NULL)
    imported <- import_from_sce(sce, input$grna_target_data_frame, "low")
    expected <- import_data(
        input$response_matrix,
        input$low_grna_matrix,
        input$grna_target_data_frame,
        "low"
    )
    expect_identical(
        get_cell_covariates(imported),
        get_cell_covariates(expected)
    )
    expect_identical(colnames(get_grna_matrix(imported)), colnames(sce))
    expect_identical(serialize(sce, NULL), before)
})
