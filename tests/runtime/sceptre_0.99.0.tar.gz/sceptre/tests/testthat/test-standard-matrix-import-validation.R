test_that("vector aggregation rejects invalid individual guides before writing", {
    standard_matrix_require()
    response <- matrix(1, 2L, 3L, dimnames = list(c("r1", "r2"), NULL))
    guides <- Matrix::sparseMatrix(
        i = c(1L, 2L),
        j = c(1L, 1L),
        x = c(.5, .5),
        dims = c(2L, 3L),
        dimnames = list(c("g1", "g2"), NULL)
    )
    metadata <- data.frame(
        grna_id = c("g1", "g2"),
        grna_target = c("A", "A"),
        vector_id = c("v1", "v1")
    )
    directory <- tempfile("invalid-raw-vector-counts-")
    on.exit(unlink(directory, recursive = TRUE), add = TRUE)
    expect_error(
        sceptre::import_data(
            response,
            DelayedArray::DelayedArray(guides),
            metadata,
            "high",
            directory_to_write = directory
        ),
        "finite|integer|UMI"
    )
    expect_false(dir.exists(directory))
})

test_that("response validation completes before creating vector backing files", {
    standard_matrix_require()
    response <- matrix(
        c(.25, 1, 2, 3, 4, 5),
        2L,
        3L,
        dimnames = list(c("r1", "r2"), NULL)
    )
    guides <- Matrix::sparseMatrix(
        i = c(1L, 2L),
        j = c(1L, 1L),
        x = c(1, 1),
        dims = c(2L, 3L),
        dimnames = list(c("g1", "g2"), NULL)
    )
    metadata <- data.frame(
        grna_id = c("g1", "g2"),
        grna_target = c("A", "A"),
        vector_id = c("v1", "v1")
    )
    directory <- tempfile("invalid-response-vector-counts-")
    dir.create(directory)
    on.exit(unlink(directory, recursive = TRUE), add = TRUE)
    writeLines("preserve", file.path(directory, "keep.txt"))
    expect_error(
        sceptre::import_data(
            DelayedArray::DelayedArray(response),
            DelayedArray::DelayedArray(guides),
            metadata,
            "high",
            directory_to_write = directory
        ),
        "finite|integer|UMI"
    )
    expect_identical(list.files(directory), "keep.txt")
    expect_identical(readLines(file.path(directory, "keep.txt")), "preserve")
})
