test_that("native Poisson QR preserves the reference fit and inputs", {
    withr::with_seed(6021, {
        for (n in c(40L, 1000L)) {
            for (p in c(1L, 3L, 8L)) {
                x <- cbind(1, matrix(rnorm(n * (p - 1L)), n))
                colnames(x) <- paste0("b", seq_len(p))
                for (scale in c(0.1, 3, 40)) {
                    y <- rpois(n, scale * exp(x[, 1L] / 5))
                    before <- serialize(list(x, y, .Random.seed), NULL)
                    warnings <- list(reference = character(), native = character())
                    capture <- function(fun, label) withCallingHandlers(fun(),
                        warning = function(w) {
                            warnings[[label]] <<- c(warnings[[label]], conditionMessage(w))
                            invokeRestart("muffleWarning")
                        })
                    reference <- capture(function() glm.fit(x, y, family = poisson()), "reference")
                    fit <- capture(function() fit_poisson_mean(y, x), "native")
                    expect_identical(warnings$reference, warnings$native)
                    expect_identical(fit$coefficients, reference$coefficients)
                    expect_identical(fit$fitted.values, reference$fitted.values)
                    expect_identical(fit$df.residual, reference$df.residual)
                    expect_identical(serialize(list(x, y, .Random.seed), NULL), before)
                }
            }
        }
    })
})

test_that("difficult Poisson designs retain reference fallback and diagnostics", {
    y <- c(0, 1, 2, 0, 3, 5, 1, 2)
    x <- cbind(1, seq_along(y))
    expect_null(poisson_qr_fit_cpp(cbind(x, x[, 2L]), y))
    expect_error(fit_response(y, cbind(x, x[, 2L])), "cannot be estimated")
    zero <- rep(0, length(y))
    expect_identical(fit_poisson_mean(zero, x)$coefficients,
        glm.fit(x, zero, family = poisson())$coefficients)
    fractional <- y + 0.5
    expect_null(poisson_qr_fit_cpp(x, fractional))
    capture_fractional <- function(fun) {
        warnings <- character()
        fit <- withCallingHandlers(fun(), warning = function(w) {
            warnings <<- c(warnings, conditionMessage(w))
            invokeRestart("muffleWarning")
        })
        list(fit = fit, warnings = warnings)
    }
    fractional_fit <- capture_fractional(function() fit_poisson_mean(fractional, x))
    fractional_reference <- capture_fractional(function() glm.fit(x, fractional,
        family = poisson()))
    expect_true(length(fractional_reference$warnings) > 0L)
    expect_true(all(grepl("non-integer x", fractional_reference$warnings)))
    expect_identical(fractional_fit, fractional_reference)
    withr::local_options(matprod = "internal")
    reference <- glm.fit(x, y, family = poisson())
    fit <- fit_poisson_mean(y, x)
    expect_identical(fit, reference)
})

test_that("workflow traversal shares checks only within its unchanged input", {
    inputs <- readRDS(file.path(refactor_fixture_dir(), "inputs.rds"))
    case <- readRDS(file.path(refactor_fixture_dir(), "cases.rds"))$low_complement_perm
    object <- refactor_capture(refactor_prepare(inputs, case))$value
    before <- serialize(object, NULL)
    status <- workflow_status(object)
    expect_true(all(status[seq_len(4L)]))
    expect_identical(serialize(object, NULL), before)
    for (stage in preparation_stage_names()) {
        changed <- object
        changed@preparation@stages[[stage]]$identity <- "tampered"
        observed <- workflow_status(changed)
        expected <- c(stage_complete(changed, "import_data"),
            stage_complete(changed, "design"), stage_complete(changed, "assignment"),
            stage_complete(changed, "run_qc"))
        expect_identical(unname(observed[seq_len(4L)]), expected)
        expect_false(any(observed[-seq_len(4L)]))
    }
    object@preparation@design_matrix[1L, 1L] <- 9
    expect_false(workflow_status(object)[["set_analysis_parameters"]])
})

test_that("cache-friendly null scoring matches the ordered score formula", {
    withr::with_seed(404, {
        n <- 24L
        a <- rnorm(n)
        w <- rep(5, n)
        mu <- rep(1, n)
        draws <- list(integer(), c(2L, 0L, 5L), c(9L, 4L), seq.int(0L, 15L))
        bridge <- refactor_native_bridge(test_path("fixtures", "refactor", "native-bridge.cpp"))
        pointer <- bridge$refactor_native_pointer(draws, n)
        for (p in c(0L, 1L, 2L, 3L, 4L, 8L, 11L, 16L, 20L, 24L, 32L)) {
            D <- matrix(rnorm(p * n, sd = 0.01), p, n)
            expected <- vapply(draws, function(draw) {
                top <- left <- right <- 0
                for (i in seq_len(p)) {
                    value <- 0
                    for (cell in draw + 1L) value <- value + D[i, cell]
                    right <- right + value * value
                }
                for (cell in draw + 1L) {
                    top <- top + a[cell]
                    left <- left + w[cell]
                }
                top / sqrt(left - right)
            }, numeric(1))
            seed <- .Random.seed
            result <- run_association_test(a, mu, a, w, D, 1:3, 3L, TRUE,
                pointer, length(draws), 0L, 0L, FALSE, TRUE, 0L)
            expect_equal(result$resampling_dist, expected, tolerance = 1e-14)
            expect_identical(.Random.seed, seed)
        }
    })
})
