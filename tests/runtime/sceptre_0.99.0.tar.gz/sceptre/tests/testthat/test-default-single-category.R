test_that("default formulas omit categorical terms without observed variation", {
    covariates <- data.frame(
        one_factor = factor(rep("a", 6L)),
        unused_levels = factor(
            rep("a", 6L),
            levels = c("unused", "a", "other")
        ),
        one_character = rep("a", 6L),
        one_logical = rep(TRUE, 6L),
        one_with_missing = c("a", NA_character_, rep("a", 4L)),
        no_observed = factor(rep(NA_character_, 6L), levels = c("a", "b")),
        aaa_n_umis = 0:5,
        numeric_constant = rep(7, 6L),
        varying_factor = factor(rep(c("a", "b"), 3L)),
        varying_character = rep(c("b", "a"), 3L),
        varying_logical = rep(c(FALSE, TRUE), 3L),
        n_nonzero_aaa = 1:6,
        response_p_mito = rep(0.2, 6L)
    )
    before <- serialize(covariates, NULL)
    withr::local_seed(271L)
    seed <- .Random.seed
    actual <- auto_construct_formula_object(covariates, TRUE)
    expected <- ~ log(aaa_n_umis + 1) +
        numeric_constant +
        varying_factor +
        varying_character +
        varying_logical +
        log(n_nonzero_aaa)
    expect_identical(as.character(actual), as.character(expected))
    expect_identical(environment(actual), baseenv())
    expect_identical(
        stats::model.matrix(actual, covariates),
        stats::model.matrix(expected, covariates)
    )
    expect_identical(serialize(covariates, NULL), before)
    expect_identical(.Random.seed, seed)
    only_constant <- covariates[c(
        "one_factor",
        "unused_levels",
        "one_character",
        "one_logical"
    )]
    expect_identical(
        as.character(auto_construct_formula_object(only_constant, FALSE)),
        as.character(~1)
    )
})

test_that("public default setup and mixture ignore single-category extra covariates", {
    inputs <- refactor_make_inputs()
    import <- function(extra = data.frame()) {
        suppressMessages(import_data(
            inputs$response_matrix,
            inputs$high_grna_matrix,
            inputs$grna_target_data_frame,
            "high",
            extra_covariates = extra
        ))
    }
    plain <- import()
    prepared <- suppressMessages(set_analysis_parameters(
        plain,
        discovery_pairs = inputs$discovery_pairs
    ))
    expected <- suppressMessages(assign_grnas(prepared, print_progress = FALSE))
    fit_em <- getFromNamespace("run_reduced_em_algo_cpp", "sceptre")
    calls <- 0L
    testthat::local_mocked_bindings(
        run_reduced_em_algo_cpp = function(...) {
            calls <<- calls + 1L
            fit_em(...)
        },
        .package = "sceptre"
    )
    n <- ncol(inputs$response_matrix)
    for (batch in list(
        factor(rep("one", n)),
        factor(rep("one", n), levels = c("unused", "one", "unused2")),
        rep("one", n),
        rep(TRUE, n)
    )) {
        object <- import(data.frame(
            batch = if (is.factor(batch)) droplevels(batch) else batch,
            row.names = colnames(inputs$response_matrix)
        ))
        if (is.factor(batch) && nlevels(batch) > length(unique(batch))) {
            # Import deliberately rejects unused factor levels. Construct a
            # saved legacy-style fixture to exercise public setup/reassignment
            # on an existing covariate frame without relaxing that validation.
            covariates <- screen_cell_covariates(object@data)
            covariates$batch <- batch
            screen_cell_covariates(object@data) <- covariates
            object <- initialize_screen_identity(object)
            saved <- tempfile(fileext = ".rds")
            withr::defer(unlink(saved))
            write_sceptre_object(object, saved)
            object <- read_sceptre_object(saved)
        }
        before <- serialize(object, NULL)
        expect_error(
            suppressMessages(set_analysis_parameters(
                object,
                discovery_pairs = inputs$discovery_pairs,
                formula_object = ~batch
            )),
            "contrasts|redundant"
        )
        withr::with_seed(271L, {
            seed <- .Random.seed
            configured <- suppressMessages(set_analysis_parameters(
                object,
                discovery_pairs = inputs$discovery_pairs
            ))
            expect_identical(
                configured@spec@formula_object,
                prepared@spec@formula_object
            )
            expect_identical(
                configured@preparation@design_matrix,
                prepared@preparation@design_matrix
            )
            expect_false("batch" %in% all.vars(configured@spec@formula_object))
            before_calls <- calls
            assigned <- suppressMessages(assign_grnas(
                configured,
                print_progress = FALSE
            ))
            expect_gt(calls, before_calls)
            expect_identical(
                assigned@preparation@guide_assignments,
                expected@preparation@guide_assignments
            )
            expect_identical(
                assigned@preparation@assignment_exclusions,
                expected@preparation@assignment_exclusions
            )
            expect_identical(
                assigned@preparation@guide_counts_per_cell,
                expected@preparation@guide_counts_per_cell
            )
            expect_identical(.Random.seed, seed)
        })
        expect_identical(serialize(object, NULL), before)
    }
})
