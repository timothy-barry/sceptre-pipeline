# These tiny file fixtures specify coordinates/values directly. They do not pass
# the old malformed CSC layouts into Matrix arithmetic or a native kernel.
refactor_write_cellranger_coordinates <- function(directory, entries) {
    dir.create(directory)
    writeLines(
        c(
            "gene-z\tZ\tGene Expression",
            "guide-a\tA\tCRISPR Guide Capture",
            "gene-a\tA\tGene Expression",
            "guide-b\tB\tCRISPR Guide Capture",
            "gene-m\tM\tGene Expression"
        ),
        file.path(directory, "features.tsv")
    )
    writeLines(c("cell-z", "cell-a"), file.path(directory, "barcodes.tsv"))
    writeLines(
        c(
            "%%MatrixMarket matrix coordinate real general",
            "% fixture",
            paste(5L, 2L, length(entries)),
            entries
        ),
        file.path(directory, "matrix.mtx")
    )
    directory
}

test_that("file CSC construction sorts complete owned slots without dropping zeros", {
    dt <- data.table::data.table(
        cell_idx = c(1L, 0L, 1L, 0L),
        feature_idx = c(1L, 1L, 0L, 0L),
        x = c(11, 1, 10, 0)
    )
    before <- serialize(dt, NULL)
    out <- refactor_private("create_csc_matrix")(dt, 3L, 2L)
    expect_s4_class(out, "dgCMatrix")
    expect_true(methods::validObject(out))
    expect_identical(out@Dim, c(2L, 3L))
    expect_identical(out@p, c(0L, 2L, 4L, 4L))
    expect_identical(out@i, c(0L, 1L, 0L, 1L))
    expect_identical(out@x, c(0, 1, 10, 11))
    expect_identical(tail(out@p, 1L), nrow(dt))
    expect_identical(serialize(dt, NULL), before)

    # Historically this accepted ordering made only one of three entries visible,
    # despite passing Matrix validity. Check completeness, not validity alone.
    missing <- data.table::data.table(
        cell_idx = c(1L, 0L, 1L),
        feature_idx = c(0L, 1L, 2L),
        x = c(2, 3, 4)
    )
    out <- refactor_private("create_csc_matrix")(missing, 2L, 3L)
    expect_identical(out@p, c(0L, 1L, 3L))
    expect_identical(out@i, c(1L, 0L, 2L))
    expect_identical(out@x, c(3, 2, 4))
    expect_identical(as.matrix(out), matrix(c(0, 3, 0, 2, 0, 4), 3L, 2L))
})

test_that("file CSC construction rejects duplicate coordinates before native use", {
    construct <- refactor_private("create_csc_matrix")
    dt <- data.table::data.table(
        cell_idx = c(1L, 0L, 1L),
        feature_idx = c(0L, 1L, 0L),
        x = c(0, 7, 3)
    )
    before <- serialize(dt, NULL)
    expect_error(
        construct(dt, 2L, 2L),
        "Repeated (cell, feature) coordinates",
        fixed = TRUE
    )
    expect_identical(serialize(dt, NULL), before)
    for (field in c("cell_idx", "feature_idx")) {
        for (bad in c(-1L, 2L, NA_integer_)) {
            invalid <- data.table::data.table(
                cell_idx = 0L,
                feature_idx = 0L,
                x = 1
            )
            invalid[[field]] <- bad
            expect_error(
                construct(invalid, 2L, 2L),
                "outside the matrix dimensions",
                fixed = TRUE
            )
        }
    }
    empty <- data.table::data.table(
        cell_idx = integer(),
        feature_idx = integer(),
        x = numeric()
    )
    out <- construct(empty, 3L, 2L)
    expect_identical(out@p, rep(0L, 4L))
    expect_identical(out@i, integer())
    expect_identical(out@x, numeric())
    expect_identical(out@Dim, c(2L, 3L))
    expect_error(
        construct(empty, .Machine$integer.max, 2L),
        "final sparse pointer",
        fixed = TRUE
    )
    expect_error(construct(empty, 1.5, 2L), "finite integer", fixed = TRUE)
})

test_that("Cell Ranger import maps interleaved modalities and preserves file IDs", {
    directory <- refactor_write_cellranger_coordinates(
        file.path(withr::local_tempdir(), "interleaved"),
        c(
            "5 2 3",
            "2 1 8",
            "1 2 0",
            "4 2 4",
            "3 1 2",
            "1 1 5",
            "2 2 2",
            "4 1 6",
            "3 2 7"
        )
    )
    metadata <- data.frame(
        grna_id = c("guide-a", "guide-b"),
        grna_target = c("target-a", "non-targeting")
    )
    object <- suppressMessages(import_data_from_cellranger(
        directory,
        "low",
        metadata
    ))
    expect_false("batch" %in% names(get_cell_covariates(object)))
    response <- DelayedArray::seed(get_response_matrix(object))
    guides <- DelayedArray::seed(get_grna_matrix(object))
    expect_true(methods::validObject(response))
    expect_true(methods::validObject(guides))
    expect_identical(rownames(response), c("gene-z", "gene-a", "gene-m"))
    expect_identical(rownames(guides), c("guide-a", "guide-b"))
    expect_identical(colnames(response), c("cell-z", "cell-a"))
    expect_identical(colnames(guides), c("cell-z", "cell-a"))
    expect_identical(response@p, c(0L, 2L, 4L, 5L))
    expect_identical(response@j, c(0L, 1L, 0L, 1L, 1L))
    expect_identical(response@x, c(5, 0, 2, 7, 3))
    expect_identical(guides@p, c(0L, 2L, 4L))
    expect_identical(guides@j, c(0L, 1L, 0L, 1L))
    expect_identical(guides@x, c(8, 2, 6, 4))

    # The same coordinate in a different supplied batch is independent.
    batches <- suppressMessages(import_data_from_cellranger(
        rep(directory, 2L),
        "low",
        metadata
    ))
    expect_identical(
        colnames(get_response_matrix(batches)),
        c("b1_cell-z", "b1_cell-a", "b2_cell-z", "b2_cell-a")
    )
    duplicate <- refactor_write_cellranger_coordinates(
        file.path(withr::local_tempdir(), "duplicate"),
        c("1 1 2", "2 1 1", "1 1 0")
    )
    expect_error(
        suppressMessages(import_data_from_cellranger(
            duplicate,
            "low",
            metadata
        )),
        "Repeated (cell, feature) coordinates",
        fixed = TRUE
    )
})

test_that("Parse import sorts cell-first file coordinates and rejects repetitions", {
    directory <- withr::local_tempdir()
    gene <- file.path(directory, "gene.mtx")
    guide <- file.path(directory, "guide.mtx")
    gene_ids <- file.path(directory, "genes.csv")
    guide_ids <- file.path(directory, "guides.csv")
    header <- c(
        "%%MatrixMarket matrix coordinate real general",
        "% fixture",
        "2 2 4"
    )
    writeLines(c(header, "2 2 7", "1 1 5", "2 1 0", "1 2 2"), gene)
    writeLines(c(header, "2 1 2", "1 2 6", "2 2 4", "1 1 8"), guide)
    writeLines(
        c("feature_id,feature_name,genome", "gene-z,Z,human", "gene-a,A,human"),
        gene_ids
    )
    writeLines(
        c(
            "feature_id,feature_name,genome",
            "a,guide-a,human",
            "b,guide-b,human"
        ),
        guide_ids
    )
    metadata <- data.frame(
        grna_id = c("guide-a", "guide-b"),
        grna_target = c("target-a", "non-targeting")
    )
    object <- suppressMessages(import_data_from_parse(
        gene,
        guide,
        gene_ids,
        guide_ids,
        "low",
        metadata
    ))
    response <- DelayedArray::seed(get_response_matrix(object))
    expect_identical(response@p, c(0L, 2L, 4L))
    expect_identical(response@j, c(0L, 1L, 0L, 1L))
    expect_identical(response@x, c(5, 0, 2, 7))
    expect_identical(rownames(response), c("gene-z", "gene-a"))
    expect_identical(
        DelayedArray::seed(get_grna_matrix(object))@x,
        c(8, 2, 6, 4)
    )
    writeLines(c(header, "1 1 5", "2 2 7", "1 1 0", "1 2 2"), gene)
    expect_error(
        suppressMessages(import_data_from_parse(
            gene,
            guide,
            gene_ids,
            guide_ids,
            "low",
            metadata
        )),
        "Repeated (cell, feature) coordinates",
        fixed = TRUE
    )
})


test_that("public count import rejects fractional UMIs rather than rounding", {
    response <- Matrix::sparseMatrix(
        i = 1L,
        j = 1L,
        x = 1.5,
        dims = c(1L, 2L),
        dimnames = list("r1", c("a", "b"))
    )
    guides <- Matrix::sparseMatrix(
        i = 1L,
        j = 1L,
        x = 8,
        dims = c(1L, 2L),
        dimnames = list("g1", c("a", "b"))
    )
    metadata <- data.frame(grna_id = "g1", grna_target = "non-targeting")
    expect_error(
        import_data(response, guides, metadata, "low"),
        "integer.*UMI|UMI.*integer"
    )
    response@x <- 2
    guides@x <- 1.5
    expect_error(
        import_data(response, guides, metadata, "low"),
        "integer.*UMI|UMI.*integer"
    )
})

test_that("canonical coordinate reuse remains read-only and validates every entry", {
    construct <- refactor_private("create_csc_matrix")
    for (canonical in c(TRUE, FALSE)) {
        dt <- data.table::data.table(
            cell_idx = c(0L, 0L, 2L),
            feature_idx = c(0L, 2L, 1L), x = c(0, 3, 7)
        )
        if (!canonical) dt <- dt[c(3L, 1L, 2L), ]
        before <- data.table::copy(dt)
        out <- construct(dt, 4L, 3L)
        expect_identical(dt, before)
        expect_identical(out@p, c(0L, 2L, 2L, 3L, 3L))
        expect_identical(out@i, c(0L, 2L, 1L))
        expect_identical(out@x, c(0, 3, 7))
        # Public caller mutation after construction must retain R copy semantics.
        data.table::set(dt, i = 1L, j = "x", value = 99)
        expect_identical(out@x, c(0, 3, 7))
        invalid <- data.table::copy(before)
        invalid$feature_idx[3L] <- NA_integer_
        expect_error(construct(invalid, 4L, 3L), "outside the matrix dimensions")
        duplicate <- rbind(before, before[1L, ])
        expect_error(construct(duplicate, 4L, 3L), "Repeated (cell, feature)", fixed = TRUE)
    }
})

test_that("owned reader remapping does not modify the full coordinate table", {
    full <- data.table::data.table(cell_idx = c(1L, 2L, 1L),
        feature_idx = c(1L, 2L, 3L), x = c(0, 4, 7))
    before <- data.table::copy(full)
    rows <- c(1L, 3L)
    owned <- full[full$feature_idx %in% rows, ]
    refactor_private("remap_import_coordinates_cpp")(
        owned$cell_idx, owned$feature_idx, rows, 3L)
    expect_identical(full, before)
    expect_identical(owned$cell_idx, c(0L, 0L))
    expect_identical(owned$feature_idx, c(0L, 1L))
    expect_identical(owned$x, c(0, 7))
})

test_that("reader-owned column subsets preserve source counts and detached output", {
    directory <- refactor_write_cellranger_coordinates(
        file.path(withr::local_tempdir(), "owned-columns"),
        c("5 2 3", "2 1 8", "1 2 0", "4 2 4", "3 1 2",
          "1 1 5", "2 2 2", "4 1 6", "3 2 7")
    )
    matrix_file <- normalizePath(file.path(directory, "matrix.mtx"))
    original_fread <- data.table::fread
    retained <- original_fread(matrix_file, skip = 3L,
        col.names = c("feature_idx", "cell_idx", "x"),
        colClasses = c("integer", "integer", "double"))
    before <- data.table::copy(retained)
    testthat::local_mocked_bindings(fread = function(file, ...) {
        if (identical(normalizePath(file), matrix_file)) retained else
            original_fread(file = file, ...)
    }, .package = "data.table")
    object <- suppressMessages(import_data_from_cellranger(directory, "low",
        data.frame(grna_id = c("guide-a", "guide-b"),
                   grna_target = c("target-a", "non-targeting"))))
    expect_identical(retained, before)
    expect_identical(vapply(retained, typeof, character(1)),
        c(feature_idx = "integer", cell_idx = "integer", x = "double"))
    response <- DelayedArray::seed(get_response_matrix(object))
    guide <- DelayedArray::seed(get_grna_matrix(object))
    expect_identical(response@p, c(0L, 2L, 4L, 5L))
    expect_identical(response@j, c(0L, 1L, 0L, 1L, 1L))
    expect_identical(response@x, c(5, 0, 2, 7, 3))
    expect_identical(guide@x, c(8, 2, 6, 4))
    expect_identical(rownames(response), c("gene-z", "gene-a", "gene-m"))
    expect_identical(colnames(response), c("cell-z", "cell-a"))
    # Mutating the parser's table after import cannot change saved counts.
    data.table::set(retained, i = 1L, j = "x", value = 999)
    expect_identical(response@x, c(5, 0, 2, 7, 3))
    expect_identical(guide@x, c(8, 2, 6, 4))
})
