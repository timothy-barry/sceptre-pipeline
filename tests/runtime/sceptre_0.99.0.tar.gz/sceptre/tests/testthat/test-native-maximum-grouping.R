test_that("maximum assignment grouping matches independent per-guide scans", {
    for (maxima in list(character(), c("g2", NA, "g1", "g2", "other"),
                        stats::setNames(c("g1", "g2", "g1"), c("c", "b", "a")))) {
        for (ids in list(character(), c("g2", "empty", "g1", "g2", NA_character_))) {
            actual <- assign_grnas_to_cells_maximum(maxima, rep(NaN, length(maxima)),
                0.8, rep(5, length(maxima)), 5L, ids)
            reference <- stats::setNames(lapply(ids, function(id) which(maxima == id)), ids)
            expect_identical(actual$initial_assignment_list, reference)
        }
    }
})
