test_that("in-memory sparse library totals retain double precision", {
    counts <- Matrix::sparseMatrix(
        i = c(1L, 2L, 1L, 2L, 3L),
        j = c(1L, 1L, 2L, 2L, 2L),
        x = c(3e9, 4e9, 1e16, .75, .75),
        dims = c(3L, 2L),
        repr = "C"
    )
    actual <- storage_cell_covariates(counts, integer(), FALSE, TRUE)
    expect_identical(actual$n_umi, c(7e9, 1e16))
    expect_identical(actual$n_nonzero, c(2L, 3L))
    expect_identical(actual$max_feature, c(1L, 0L))
    expect_identical(actual$frac_umis_max_feature, c(4e9 / 7e9, 1))
})

test_that("legacy sparse covariates preserve large totals and double accumulation", {
    counts <- Matrix::sparseMatrix(
        i = c(1L, 2L, 1L, 2L, 3L, 1L, 2L, 3L, 1L, 2L, 3L),
        j = c(1L, 1L, 2L, 2L, 2L, 3L, 3L, 3L, 4L, 4L, 4L),
        x = c(3e9, 4e9, 1e16, .75, .75, .25, .5, .75, 2, 2, 0),
        dims = c(25000L, 5L),
        repr = "C"
    )
    rownames(counts) <- paste0("feature", seq_len(nrow(counts)))
    colnames(counts) <- paste0("cell", seq_len(ncol(counts)))
    mito <- c(3L, 1L, 1L)
    expected <- list(
        n_nonzero = c(2L, 3L, 1L, 2L, 0L),
        # Add features in double precision, rather than using a dense colSums
        # accumulator that can retain extra precision on some platforms.
        n_umi = c(7e9, 1e16, 1.5, 4, 0),
        p_mito = c(6e9 / 7e9, 2, 1.25 / 1.5, 1, NaN),
        max_feature = c(1L, 0L, 2L, 0L, 0L),
        frac_umis_max_feature = c(4e9, 1e16, .75, 2, 0) /
            c(7e9, 1e16, 1.5, 4, 0)
    )
    snapshot <- serialize(counts, NULL)
    expect_identical(
        storage_cell_covariates(counts, mito, TRUE, TRUE),
        expected
    )
    expect_identical(mito, c(3L, 1L, 1L))
    expect_identical(serialize(counts, NULL), snapshot)
})

test_that("legacy sparse covariates retain unusual numeric input behavior", {
    counts <- Matrix::sparseMatrix(
        i = rep(seq_len(4L), 4L),
        j = rep(seq_len(4L), each = 4L),
        x = c(0, -2, -1, 0, NA_real_, 0, 1, 0, NaN, 0, 1, 0, 0, Inf, 2, 0),
        dims = c(4L, 4L),
        repr = "C"
    )
    expected <- list(
        n_nonzero = c(0L, 1L, 1L, 2L),
        n_umi = c(-3, NA_real_, NaN, Inf),
        p_mito = c(1 / 3, NA_real_, NaN, 0),
        max_feature = c(0L, 2L, 2L, 1L),
        frac_umis_max_feature = c(0, NA_real_, NaN, NaN)
    )
    snapshot <- serialize(counts, NULL)
    expect_identical(
        storage_cell_covariates(
            counts,
            c(3L, 1L, 1L),
            TRUE,
            TRUE
        ),
        expected
    )
    expect_identical(serialize(counts, NULL), snapshot)
    without_optional <- expected
    without_optional$p_mito <- numeric(4L)
    without_optional$max_feature <- integer(4L)
    without_optional$frac_umis_max_feature <- numeric(4L)
    expect_identical(
        storage_cell_covariates(
            counts,
            integer(),
            FALSE,
            FALSE
        ),
        without_optional
    )
})

test_that("standard integer covariates retain large totals and optional summaries", {
    standard_matrix_require()
    counts <- Matrix::sparseMatrix(
        i = c(1L, 2L, 1L, 2L, 3L, 1L, 2L, 3L),
        j = c(1L, 1L, 2L, 2L, 2L, 3L, 3L, 3L),
        x = c(3e9, 4e9, 2, 2, 0, 1, 2, 3),
        dims = c(4L, 4L),
        repr = "C",
        dimnames = list(paste0("feature", 1:4), paste0("cell", 1:4))
    )
    expected <- list(
        n_nonzero = c(2L, 2L, 3L, 0L),
        n_umi = c(7e9, 4, 6, 0),
        p_mito = c(6e9 / 7e9, 1, 5 / 6, NaN),
        max_feature = c(1L, 0L, 2L, 0L),
        frac_umis_max_feature = c(4e9 / 7e9, .5, .5, NaN)
    )
    directory <- tempfile("standard-integer-covariates-")
    on.exit(unlink(directory, recursive = TRUE), add = TRUE)
    for (layout in c("row", "column")) {
        backed <- standard_matrix_fixture(
            counts,
            directory,
            layout,
            layout,
            TRUE
        )
        for (with_mito in c(FALSE, TRUE)) {
            for (with_maximum in c(FALSE, TRUE)) {
                target <- expected
                if (!with_mito) {
                    target$p_mito <- numeric(4L)
                }
                if (!with_maximum) {
                    target$max_feature <- integer(4L)
                    target$frac_umis_max_feature <- numeric(4L)
                }
                expect_identical(
                    storage_cell_covariates(
                        backed,
                        c(3L, 1L, 1L),
                        with_mito,
                        with_maximum
                    ),
                    target
                )
            }
        }
    }
})

test_that("new standard covariates reject noninteger or invalid UMI counts", {
    standard_matrix_require()
    for (value in c(.25, .5, 1.5, -1, NA_real_, NaN, Inf, -Inf)) {
        counts <- DelayedArray::DelayedArray(matrix(c(0, value, 1, 2), 2L))
        expect_error(
            storage_standard_cell_covariates(
                counts,
                1L,
                TRUE,
                TRUE
            ),
            "integer|finite|nonnegative"
        )
    }
})

test_that("standard covariate validation rejects noncanonical sparse coordinates", {
    standard_matrix_require()
    counts <- Matrix::sparseMatrix(
        i = c(1L, 2L, 1L),
        j = c(1L, 1L, 2L),
        x = c(2, 3, 4),
        dims = c(3L, 4L)
    )
    directory <- tempfile("standard-covariate-coordinates-")
    on.exit(unlink(directory, recursive = TRUE), add = TRUE)
    for (layout in c("row", "column")) {
        minor <- if (layout == "row") ncol(counts) else nrow(counts)
        invalid <- list(
            unsorted = c(1L, 0L),
            duplicate = c(0L, 0L),
            negative = c(-1L, 1L),
            outside = c(0L, minor)
        )
        for (name in names(invalid)) {
            label <- paste(layout, name, sep = "-")
            backed <- standard_matrix_fixture(
                counts,
                directory,
                label,
                layout,
                TRUE
            )
            path <- file.path(directory, paste0(label, ".h5"))
            indices <- as.integer(rhdf5::h5read(path, "counts/indices"))
            indices[1:2] <- invalid[[name]]
            rhdf5::h5write(indices, path, "counts/indices")
            expect_error(
                storage_standard_cell_covariates(
                    backed,
                    integer(),
                    FALSE,
                    FALSE
                ),
                "noncanonical sparse coordinates"
            )
        }
    }
})

test_that("covariates reject prepared response readers before pointer conversion", {
    standard_matrix_require()
    handle <- storage_standard_handle(DelayedArray::DelayedArray(
        matrix(c(1, 0, 0, 2), 2L)
    ))
    reader <- standard_matrix_open_response_reader_cpp(handle)
    on.exit(standard_matrix_close_response_reader_cpp(reader), add = TRUE)
    standard_matrix_release_cpp(handle)
    expect_error(
        standard_matrix_cell_covariates_cpp(reader, integer(), FALSE, FALSE),
        "prepared response reader"
    )
    expect_identical(standard_matrix_read_response_cpp(reader, 1L), c(1, 0))
})
