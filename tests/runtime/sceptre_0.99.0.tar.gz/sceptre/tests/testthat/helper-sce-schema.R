# Historical fixture construction requires old field names. Keep this test-only
# bridge separate from the native production API; no old row/attribute codec.
screen_test_field <- function(x, name) {
    readers <- list(response_matrix = screen_response_counts,
        grna_matrix = screen_guide_counts,
        covariate_data_frame = function(x) as.data.frame(screen_cell_covariates(x)),
        grna_target_data_frame = function(x) as.data.frame(screen_guide_annotations(x)),
        response_names = screen_response_names, low_moi = screen_low_moi,
        identity = screen_identity, import_grna_assignment_info = screen_guide_summary)
    readers[[name]](x)
}
