qc_inverse_fixture <- function(cells, groups, nt, complement = TRUE) {
  object <- methods::new("sceptre_object")
  object@data <- new_screen_experiment(response_matrix =
    Matrix::sparseMatrix(i = integer(), j = integer(), x = numeric(), dims = c(1L, 31L)))
  object@spec@multiple_testing_alpha <- 0.1
  object@spec@multiple_testing_method <- "BH"
  object@preparation@analysis_cells <- cells
  object@preparation@source_groups <- list(
    grna_group_idxs = groups,
    indiv_nt_grna_idxs = nt
  )
  object@spec@control_group_complement <- complement
  object
}

qc_inverse_expected <- function(object) {
  cells <- object@preparation@analysis_cells
  raw <- object@preparation@source_groups
  # This is the established membership contract, independently expressed
  # without relying on the optimized remapper or its private fallback.
  groups <- lapply(raw$grna_group_idxs, function(x) which(cells %in% x))
  nt <- lapply(raw$indiv_nt_grna_idxs, function(x) which(cells %in% x))
  nt <- nt[lengths(nt) > 0L]
  out <- list(grna_group_idxs = groups, indiv_nt_grna_idxs = nt)
  if (!object@spec@control_group_complement) {
    combined <- as.integer(unique(unlist(nt, use.names = FALSE)))
    out$indiv_nt_grna_idxs <- lapply(nt, match, table = combined)
    out$all_nt_idxs <- combined
  }
  out
}

test_that("QC remapping preserves analysis order, uniqueness and NT coordinates", {
  groups <- list(
    A = c(5L, 4L, 4L, 2L),
    none = 1L,
    mixed = c(8L, 11L, 2L, 8L),
    empty = integer()
  )
  nt <- list(ntB = c(2L, 11L), ntA = 8L, removed = 3L)
  for (complement in c(TRUE, FALSE)) {
    object <- qc_inverse_fixture(c(8L, 2L, 11L, 4L, 5L), groups, nt, complement)
    before <- serialize(object, NULL)
    set.seed(817L)
    rng <- .Random.seed
    result <- refactor_private("update_grna_assignments_given_qc")(object)
    expect_identical(
      result@preparation@analysis_groups,
      qc_inverse_expected(object)
    )
    expect_identical(
      result@preparation@analysis_groups$grna_group_idxs$A,
      c(2L, 4L, 5L)
    )
    expect_identical(serialize(object, NULL), before)
    expect_identical(.Random.seed, rng)
  }
})

test_that("QC remapping retains established behavior for unusual memberships", {
  groups <- list(
    named = c(a = 2L, b = 4L),
    factor = factor(c("1", "4")),
    fractional = c(1, 2.5, 3),
    missing = c(NA_integer_, 2L),
    invalid = c(-1L, 0L, 2L, 40L),
    character = c("1", "2"),
    classed = structure(c(2L, 5L), class = "unusual"),
    matrix = matrix(1:4, 2L),
    empty = integer()
  )
  for (cells in list(c(4L, 2L, 8L, 1L, 5L), integer())) {
    for (complement in c(TRUE, FALSE)) {
      object <- qc_inverse_fixture(cells, groups, groups, complement)
      result <- refactor_private("update_grna_assignments_given_qc")(object)
      expect_identical(
        result@preparation@analysis_groups,
        qc_inverse_expected(object)
      )
    }
  }
})

test_that("QC integer memberships do not rescan the retained-cell vector per guide", {
  original <- refactor_private("source_membership_to_analysis")
  scans <- 0L
  testthat::local_mocked_bindings(
    source_membership_to_analysis = function(
      source_members,
      analysis_to_source
    ) {
      scans <<- scans + 1L
      original(source_members, analysis_to_source)
    },
    .package = "sceptre"
  )
  groups <- setNames(
    rep(list(c(21L, 4L, 21L, 2L)), 100L),
    paste0("g", seq_len(100L))
  )
  object <- qc_inverse_fixture(c(21L, 2L, 4L, 31L), groups, groups)
  result <- refactor_private("update_grna_assignments_given_qc")(object)
  expect_identical(
    result@preparation@analysis_groups,
    qc_inverse_expected(object)
  )
  expect_identical(scans, 0L)
})

test_that("QC remapping agrees with membership semantics for random reordered views", {
  set.seed(271828L)
  for (iteration in seq_len(50L)) {
    cells <- sample.int(31L, sample.int(32L, 1L) - 1L)
    groups <- list(
      A = sample.int(31L, 15L, replace = TRUE),
      B = sample.int(31L, 1L),
      empty = integer()
    )
    for (complement in c(TRUE, FALSE)) {
      object <- qc_inverse_fixture(cells, groups, groups, complement)
      rng <- .Random.seed
      result <- refactor_private("update_grna_assignments_given_qc")(object)
      expect_identical(
        result@preparation@analysis_groups,
        qc_inverse_expected(object)
      )
      expect_identical(.Random.seed, rng)
    }
  }
})
