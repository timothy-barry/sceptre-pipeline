test_that("shared first-stage prefixes retain exact inference, tails and RNG", {
    native <- refactor_private("run_association_test")
    shared <- refactor_private("permutation_prefix_scores_cpp")
    sampler <- refactor_private("fisher_yates_sampler")
    set.seed(719L)
    for (p in c(0L, 1L, 2L, 3L, 5L, 21L, 32L)) {
        n <- 48L
        a <- sin(seq_len(n))
        w <- rep(2, n)
        D <- matrix(cos(seq_len(p * n)) / 100, p, n)
        sizes <- c(0L, 1L, 7L, 20L)
        bank <- sampler(n, max(sizes), 320L)
        state <- .Random.seed
        scores <- shared(a, w, D, bank, sizes, 100L)
        expect_identical(.Random.seed, state)
        for (k in seq_along(sizes)) {
            for (side in -1:1) {
                args <- list(y = rep(2, n), mu = rep(2, n), a = a,
                    w = w, D = D, trt_idxs = seq_len(sizes[k]),
                    n_trt = sizes[k], use_all_cells = FALSE,
                    synthetic_idxs = bank, B1 = 100L, B2 = 100L,
                    B3 = 120L, fit_parametric_curve = FALSE,
                    return_resampling_dist = TRUE, side_code = side)
                original <- do.call(native, args)
                actual <- do.call(native, c(args, list(first_stage_scores = scores[[k]])))
                expect_identical(actual, original)
            }
        }
        expect_identical(.Random.seed, state)
    }
    bank <- sampler(4L, 2L, 3L)
    expect_error(shared(rep(1, 4), rep(1, 4), matrix(0, 0, 4),
                        bank, c(2L, 1L), 3L), "increasing")
    expect_error(shared(rep(1, 4), rep(1, 4), matrix(0, 0, 4),
                        bank, 3L, 3L), "shorter")
    expect_error(shared(rep(1, 4), rep(1, 4), matrix(0, 0, 4),
                        bank, 2L, 4L), "bank length")
})

test_that("shared worker falls back for small demand and preserves group order", {
    n <- 80L
    score <- list(mu = rep(3, n), a = sin(seq_len(n)), w = rep(2, n),
                  D = matrix(cos(seq_len(3L * n)) / 100, 3L, n))
    groups <- rep(c("a", "b", "c"), 8L)
    treatment <- function(group) {
        size <- switch(group, a = 7L, b = 12L, c = 20L)
        list(trt_idxs = seq_len(size), n_trt = size)
    }
    options <- list(B1 = 100L, B2 = 100L, B3 = 120L,
                    fit_parametric_curve = TRUE, side_code = 3L)
    bank <- refactor_private("fisher_yates_sampler")(n, 20L, 320L)
    worker <- refactor_private("test_permutation_shared_fit")
    for (requested in list(groups, groups[1:2], character())) {
        state <- .Random.seed
        actual <- worker(rep(3, n), score, treatment, requested, bank, options, 3L)
        expected <- lapply(requested, function(group) {
            trt <- treatment(group)
            refactor_private("run_association_test")(rep(3, n), score$mu,
                score$a, score$w, score$D, trt$trt_idxs, trt$n_trt,
                FALSE, bank, 100L, 100L, 120L, TRUE, TRUE, 3L)
        })
        expect_identical(actual, expected)
        expect_identical(.Random.seed, state)
    }
})

test_that("shared stage one preserves prepared staged-tail and tie contracts", {
    fixture <- test_path("fixtures", "refactor")
    bridge <- refactor_native_bridge(file.path(fixture, "native-bridge.cpp"))
    cases <- readRDS(file.path(fixture, "native-inputs.rds"))$cases
    for (name in names(cases)) {
        case <- cases[[name]]
        if (case$use_all_cells) next
        bank <- bridge$refactor_native_pointer(case$draws, length(case$a))
        args <- case[setdiff(names(case), c("draws", "expected_stage", "expected_sn"))]
        args$synthetic_idxs <- bank
        original <- do.call(refactor_private("run_association_test"), args)
        prefix <- refactor_private("permutation_prefix_scores_cpp")(
            case$a, case$w, case$D, bank, case$n_trt, case$B1)[[1L]]
        actual <- do.call(refactor_private("run_association_test"),
                          c(args, list(first_stage_scores = prefix)))
        expect_identical(actual, original, info = name)
        expect_identical(actual$stage, case$expected_stage, info = name)
    }
})

test_that("prefix policy requires useful demand and a bounded score allocation", {
    testthat::local_mocked_bindings(
        permutation_prefix_scores_cpp = function(...) stop("prefix selected"),
        run_association_test = function(...) list(), .package = "sceptre")
    worker <- refactor_private("test_permutation_shared_fit")
    score <- list(mu = 1, a = 1, w = 1, D = matrix(0, 1, 1))
    lookup <- function(group) list(n_trt = as.integer(group), trt_idxs = integer())
    options <- list(B1 = 100L, B2 = 100L, B3 = 0L,
                    fit_parametric_curve = FALSE, side_code = 0L)
    expect_error(worker(1, score, lookup, rep(10L, 8L), NULL, options, 1L),
                 "prefix selected", fixed = TRUE)
    expect_no_error(worker(1, score, lookup, c(10L, 10L), NULL, options, 1L))
    options$B1 <- 100000000L
    expect_no_error(worker(1, score, lookup, rep(10L, 8L), NULL, options, 1L))
})
