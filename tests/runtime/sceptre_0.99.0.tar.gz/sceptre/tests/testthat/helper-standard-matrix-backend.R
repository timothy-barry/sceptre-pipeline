# Standard sparse fixture encoding is kept separate from the public writer:
# writeTENxMatrix canonicalizes stored zeros away, while reader compatibility
# must also handle valid files which retain those stored positions.
standard_matrix_require <- function() {
    for (package in c("HDF5Array", "beachmat", "beachmat.hdf5", "rhdf5")) {
        testthat::skip_if_not_installed(package)
    }
}

standard_matrix_integer_input <- function() {
    Matrix::sparseMatrix(
        i = c(1L, 1L, 1L, 1L, 2L, 2L, 2L, 2L),
        j = c(1L, 4L, 8L, 11L, 2L, 5L, 8L, 12L),
        x = c(0, 2, 3, 4, 2, 1, 0, 8),
        dims = c(2L, 12L),
        repr = "R",
        dimnames = list(c("r1", "r2"), NULL)
    )
}

standard_matrix_fixture <- function(
    matrix,
    directory,
    label = "counts",
    layout = c("row", "column"),
    preserve_stored_zeros = FALSE
) {
    layout <- match.arg(layout)
    dir.create(directory, recursive = TRUE, showWarnings = FALSE)
    path <- file.path(directory, paste0(label, ".h5"))
    encoded <- methods::as(
        if (layout == "row") t(matrix) else matrix,
        "CsparseMatrix"
    )
    if (preserve_stored_zeros) {
        rhdf5::h5createFile(path)
        rhdf5::h5createGroup(path, "counts")
        rhdf5::h5write(encoded@x, path, "counts/data")
        rhdf5::h5write(encoded@i, path, "counts/indices")
        rhdf5::h5write(encoded@p, path, "counts/indptr")
        rhdf5::h5write(dim(encoded), path, "counts/shape")
        out <- HDF5Array::TENxMatrix(path, "counts")
    } else {
        out <- HDF5Array::writeTENxMatrix(
            encoded,
            filepath = path,
            group = "counts",
            verbose = FALSE
        )
    }
    if (layout == "row") {
        out <- t(out)
    }
    dimnames(out) <- dimnames(matrix)
    out
}

standard_matrix_covariate_input <- function() {
    out <- Matrix::sparseMatrix(
        i = c(1L, 2L, 4L, 1L, 2L, 3L, 4L, 2L, 4L),
        j = c(1L, 1L, 1L, 2L, 2L, 2L, 2L, 4L, 4L),
        x = c(0, 1, 3, 2, 2, 0, 1, 3, 3),
        dims = c(4L, 5L),
        repr = "C",
        dimnames = list(
            c("MT-first", "second", "third", "fourth"),
            paste0("cell", seq_len(5L))
        )
    )
    out
}

standard_matrix_prepare_workflow <- function(
    inputs,
    case,
    directory,
    layout = "row"
) {
    response <- standard_matrix_fixture(
        inputs$response_matrix,
        directory,
        "response",
        layout
    )
    guides <- standard_matrix_fixture(
        inputs[[paste0(case$moi, "_grna_matrix")]],
        directory,
        "guides",
        layout
    )
    object <- sceptre::import_data(
        response,
        guides,
        inputs$grna_target_data_frame,
        case$moi,
        extra_covariates = inputs$extra_covariates
    )
    object <- sceptre::set_analysis_parameters(
        object,
        discovery_pairs = inputs$discovery_pairs,
        positive_control_pairs = inputs$positive_control_pairs,
        formula_object = stats::as.formula("~ batch + z", env = baseenv()),
        side = case$side,
        grna_integration_strategy = case$integration,
        control_group = case$control,
        resampling_mechanism = case$mechanism,
        resampling_approximation = case$approximation
    )
    object <- sceptre::assign_grnas(
        object,
        method = "thresholding",
        threshold = 40,
        print_progress = FALSE
    )
    sceptre::run_qc(
        object,
        response_n_umis_range = c(0, 1),
        response_n_nonzero_range = c(0, 1),
        n_nonzero_trt_thresh = 7L,
        n_nonzero_cntrl_thresh = 7L,
        additional_cells_to_remove = inputs$remove_cells
    )
}

standard_matrix_run_case <- function(
    inputs,
    case,
    directory,
    layout = "row",
    parallel = FALSE
) {
    withr::with_seed(
        271828,
        refactor_capture({
            object <- standard_matrix_prepare_workflow(
                inputs,
                case,
                directory,
                layout
            )
            prepared <- refactor_observe(object)
            object <- sceptre::run_calibration_check(
                object,
                n_calibration_pairs = 4L,
                calibration_group_size = 2L,
                print_progress = FALSE,
                parallel = parallel,
                n_processors = 2L,
                output_amount = case$output
            )
            calibrated <- refactor_observe(object)
            object <- sceptre::run_power_check(
                object,
                print_progress = FALSE,
                parallel = parallel,
                n_processors = 2L,
                output_amount = case$output
            )
            object <- sceptre::run_discovery_analysis(
                object,
                print_progress = FALSE,
                parallel = parallel,
                n_processors = 2L,
                output_amount = case$output
            )
            list(
                prepared = prepared,
                calibrated = calibrated,
                final = refactor_observe(object),
                rng_after = get(".Random.seed", envir = .GlobalEnv)
            )
        })
    )
}

standard_matrix_sort_fit_cache <- function(run) {
    for (stage in c("calibrated", "final")) {
        fits <- run$value[[stage]]$response_precomputations
        run$value[[stage]]$response_precomputations <- fits[sort(names(fits))]
    }
    run
}
