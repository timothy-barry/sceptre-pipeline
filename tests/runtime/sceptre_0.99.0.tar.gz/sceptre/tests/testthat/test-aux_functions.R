# `auto_compute_cell_covariates` is used by `import_data` to
# create `sceptre:::screen_cell_covariates(sceptre_object@data)`
test_that("auto_compute_cell_covariates", {
    set.seed(11123)
    num_cells <- 43
    num_responses <- 21

    # only needed to make grna_matrix
    grna_target_data_frame <- make_mock_grna_target_data(c(1, 2, 4), 1, 1, 5)
    fixed_response_matrix <- make_mock_response_matrices(
        num_responses,
        num_cells,
        patterns = "column"
    )
    fixed_grna_matrix <- make_mock_grna_matrices(
        grna_target_data_frame,
        num_cells,
        non_nt_patterns = "column",
        nt_pattern = "row"
    ) |>
        `rownames<-`(grna_target_data_frame$grna_id)
    extra_covariates_big <- make_mock_extra_covariates_data_frames(
        num_cells,
        patterns = "many_columns"
    )
    extra_covariates_empty <- data.frame()

    ## testing response_matrix
    # only `response_n_nonzero` and `response_n_umis` are tested for this part
    for (response_matrix in make_mock_response_matrices(
        num_responses,
        num_cells,
        patterns = "all"
    )) {
        results <- auto_compute_cell_covariates(
            response_matrix = response_matrix,
            grna_matrix = fixed_grna_matrix,
            extra_covariates = extra_covariates_big,
            response_names = NA_character_ # this is what it is by default in `import_data`
        )

        expect_equal(
            results$response_n_nonzero,
            response_matrix |> apply(2, function(cell) sum(cell > 0))
        )
        expect_equal(
            results$response_n_umis,
            response_matrix |> colSums()
        )
    }

    ## testing grna_matrix
    # only `response_n_nonzero` and `response_n_umis` are tested for this part
    for (grna_matrix in make_mock_grna_matrices(
        grna_target_data_frame,
        num_cells,
        non_nt_patterns = "all",
        nt_patterns = "column"
    )) {
        results <- auto_compute_cell_covariates(
            response_matrix = fixed_response_matrix,
            grna_matrix = grna_matrix,
            extra_covariates = extra_covariates_big,
            response_names = NA_character_
        )

        expect_equal(
            results$grna_n_nonzero,
            grna_matrix |> apply(2, function(cell) sum(cell > 0))
        )
        expect_equal(
            results$grna_n_umis,
            grna_matrix |> colSums()
        )
    }

    ## testing extra_covariates
    results_big <- auto_compute_cell_covariates(
        response_matrix = fixed_response_matrix,
        grna_matrix = fixed_grna_matrix,
        extra_covariates = extra_covariates_big,
        response_names = NA_character_
    )
    expect_equal(
        results_big[, names(extra_covariates_big)],
        extra_covariates_big
    )

    results_empty <- auto_compute_cell_covariates(
        response_matrix = fixed_response_matrix,
        grna_matrix = fixed_grna_matrix,
        extra_covariates = extra_covariates_empty,
        response_names = NA_character_
    )
    expect_equal(
        colnames(results_empty),
        c(
            "response_n_nonzero",
            "response_n_umis",
            "grna_n_nonzero",
            "grna_n_umis",
            "grna_frac_umis_max_feature",
            "grna_feature_w_max_expression"
        )
    )

    ## testing cell IDs
    cell_ids <- paste0("cell_", seq_len(num_cells))
    response_matrix_with_cell_ids <- fixed_response_matrix
    colnames(response_matrix_with_cell_ids) <- cell_ids
    results_with_cell_ids <- auto_compute_cell_covariates(
        response_matrix = response_matrix_with_cell_ids,
        grna_matrix = fixed_grna_matrix,
        extra_covariates = extra_covariates_big,
        response_names = NA_character_
    )
    expect_identical(rownames(results_with_cell_ids), cell_ids)

    ## testing response_names
    results_no_names <- auto_compute_cell_covariates(
        response_matrix = fixed_response_matrix,
        grna_matrix = fixed_grna_matrix,
        extra_covariates = extra_covariates_big,
        response_names = paste0("aaa", 1:num_responses)
    )

    expect_equal(
        results_no_names$response_n_nonzero,
        fixed_response_matrix |> apply(2, function(cell) sum(cell > 0))
    )
    expect_equal(
        results_no_names$response_n_umis,
        fixed_response_matrix |> colSums()
    )
    expect_equal(
        results_no_names$grna_n_nonzero,
        fixed_grna_matrix |> apply(2, function(cell) sum(cell > 0))
    )
    expect_equal(
        results_no_names$grna_n_umis,
        fixed_grna_matrix |> colSums()
    )
})

test_that("seeded internal helpers preserve the caller's RNG state", {
    response_ids <- paste0("response_", seq_len(12))
    set.seed(101)
    seed_before <- .Random.seed
    partitioned_response_ids <- partition_response_ids(
        response_ids = response_ids,
        parallel = TRUE,
        n_processors = 3
    )
    expect_equal(.Random.seed, seed_before)
    expect_length(partitioned_response_ids, 3)
    expect_setequal(unlist(partitioned_response_ids), response_ids)

    set.seed(102)
    seed_before <- .Random.seed
    starting_guesses <- get_random_starting_guesses(n_em_rep = 3)
    expect_equal(.Random.seed, seed_before)
    expect_length(starting_guesses$pi_guesses, 3)
    expect_length(starting_guesses$g_pert_guesses, 3)

    grna_target_data_frame <- data.frame(
        grna_id = c(paste0("grna_", seq_len(35)), "nt_1"),
        grna_target = c(paste0("target_", seq_len(35)), "non-targeting")
    )
    sceptre_object <- methods::new("sceptre_object")
    sceptre_object@data <- new_screen_experiment(
        grna_matrix = as_count_matrix(matrix(0, nrow(grna_target_data_frame), 0L, dimnames=list(grna_target_data_frame$grna_id,NULL))),
        grna_target_data_frame = grna_target_data_frame)
    sceptre_object@preparation@guide_groups <- grna_target_data_frame$grna_target

    sceptre_object@spec@discovery_pairs <- data.frame(
        grna_target = paste0("target_", seq_len(30L)), response_id = "r")
    set.seed(103)
    seed_before <- .Random.seed
    grnas_in_use <- determine_grnas_in_use(
        sceptre_object = sceptre_object
    )
    expect_equal(.Random.seed, seed_before)
    expect_identical(grnas_in_use, grna_target_data_frame$grna_id)
    expect_true("nt_1" %in% grnas_in_use)
})

# `auto_construct_formula_object` is used by `set_analysis_parameters` when
# `formula_object = "default"` is used. This then becomes
# `sceptre_object@spec@formula_object` and is used to make
# `sceptre_object@preparation@design_matrix` via `convert_covariate_df_to_design_matrix`.
# Note that this function is never called directly; rather, it is only used on
# a `sceptre_object` that was returned by `import_data`. This limits the possible
# `covariate_data_frame` inputs as they are guaranteed to have been produced by
# `auto_compute_cell_covariates` in `import_data` along with whatever `extra_covariates`
# is.
test_that("auto_construct_formula_object", {
    covariate_data_frame <- data.frame(
        aaa_n_umis = 0:5,
        n_nonzero_aaa = 1:6,
        x = rnorm(6),
        response_p_mito = 1.23,
        grna_n_umis = 999
    )

    fmla_with_grna <- auto_construct_formula_object(
        covariate_data_frame,
        include_grna_covariates = TRUE
    )
    fmla_without_grna <- auto_construct_formula_object(
        covariate_data_frame,
        include_grna_covariates = FALSE
    )

    expect_equal(
        as.character(fmla_with_grna)[2],
        "log(aaa_n_umis + 1) + log(n_nonzero_aaa) + x + log(grna_n_umis)"
    )
    expect_equal(
        as.character(fmla_without_grna)[2],
        "log(aaa_n_umis + 1) + log(n_nonzero_aaa) + x"
    )
})
