test_that("threshold contexts retain descriptors and never alter stored indices", {
    standard_matrix_require()
    matrix <- standard_matrix_integer_input()
    expected <- lapply(c(2L, 1L, 2L), function(row) {
        storage_threshold_row(matrix, row, 0)
    })
    handle <- storage_standard_handle(DelayedArray::DelayedArray(standard_matrix_integer_input()))
    reader <- standard_matrix_open_threshold_reader_cpp(handle)
    on.exit(standard_matrix_close_threshold_reader_cpp(reader), add = TRUE)
    standard_matrix_release_cpp(handle)
    invisible(gc())
    for (threshold in c(-1, 0, 0.5, 2.8, Inf, NA_real_, 0)) {
        expect_identical(
            standard_matrix_threshold_rows_cpp(
                reader,
                c(2L, 1L, 2L),
                threshold
            ),
            lapply(c(2L, 1L, 2L), function(row) {
                storage_threshold_row(matrix, row, threshold)
            })
        )
    }
    expect_identical(
        standard_matrix_threshold_rows_cpp(reader, integer(), 0),
        list()
    )
    expect_identical(
        standard_matrix_threshold_rows_cpp(reader, c(2L, 1L, 2L), 0),
        expected
    )
    standard_matrix_close_threshold_reader_cpp(reader)
    expect_error(standard_matrix_threshold_rows_cpp(reader, 1L, 0), "closed")
    expect_silent(standard_matrix_close_threshold_reader_cpp(reader))
})

test_that("prepared threshold and response pointers reject every other pointer kind", {
    standard_matrix_require()
    handle <- storage_standard_handle(DelayedArray::DelayedArray(standard_matrix_integer_input()))
    on.exit(standard_matrix_release_cpp(handle), add = TRUE)
    threshold <- standard_matrix_open_threshold_reader_cpp(handle)
    on.exit(standard_matrix_close_threshold_reader_cpp(threshold), add = TRUE)
    response <- standard_matrix_open_response_reader_cpp(handle)
    on.exit(standard_matrix_close_response_reader_cpp(response), add = TRUE)
    for (other in list(handle, response)) {
        expect_error(
            standard_matrix_threshold_rows_cpp(other, 1L, 0),
            "not a standard native threshold reader"
        )
        expect_error(
            standard_matrix_close_threshold_reader_cpp(other),
            "not a standard native threshold reader"
        )
    }
    expect_error(
        standard_matrix_read_response_cpp(threshold, 1L),
        "not a standard native reader"
    )
    expect_error(
        standard_matrix_close_response_reader_cpp(threshold),
        "not a standard native reader"
    )
    expect_error(
        standard_matrix_release_cpp(threshold),
        "prepared threshold reader"
    )
    expect_error(
        standard_matrix_validate_cpp(threshold),
        "prepared threshold reader"
    )
    expect_error(
        standard_matrix_open_response_reader_cpp(threshold),
        "prepared threshold reader"
    )
    expect_error(
        standard_matrix_open_threshold_reader_cpp(response),
        "prepared response reader"
    )
    expect_error(
        standard_matrix_cell_covariates_cpp(threshold, integer(), FALSE, FALSE),
        "prepared threshold reader"
    )
    expect_identical(
        standard_matrix_read_response_cpp(response, 1L),
        c(0, 0, 0, 2, 0, 0, 0, 3, 0, 0, 4, 0)
    )
    expect_identical(
        standard_matrix_threshold_rows_cpp(threshold, 1L, 0),
        list(c(1L, 4L, 8L, 11L))
    )
})

test_that("storage threshold contexts close on success, R failure and native failure", {
    standard_matrix_require()
    store <- DelayedArray::DelayedArray(standard_matrix_integer_input())
    initialize <- storage_standard_handle
    open <- standard_matrix_open_threshold_reader_cpp
    consume <- standard_matrix_threshold_rows_cpp
    handles <- readers <- list()
    fail <- FALSE
    testthat::local_mocked_bindings(
        storage_standard_handle = function(matrix_in) {
            handle <- initialize(matrix_in)
            handles[[length(handles) + 1L]] <<- handle
            handle
        },
        standard_matrix_open_threshold_reader_cpp = function(handle) {
            reader <- open(handle)
            readers[[length(readers) + 1L]] <<- reader
            reader
        },
        standard_matrix_threshold_rows_cpp = function(
            handle,
            responses,
            threshold
        ) {
            out <- consume(handle, responses, threshold)
            if (fail) {
                stop("deliberate R failure after threshold result allocation")
            }
            out
        },
        .package = "sceptre"
    )
    expect_identical(
        storage_threshold_rows(store, c(2L, 1L), 3),
        list(12L, c(8L, 11L))
    )
    fail <- TRUE
    expect_error(storage_threshold_rows(store, 1L, 0), "deliberate R failure")
    fail <- FALSE
    expect_error(storage_threshold_rows(store, 0L, 0), "Requested response")
    expect_length(readers, 3L)
    for (reader in readers) {
        expect_error(consume(reader, 1L, 0), "closed")
    }
    for (handle in handles) {
        expect_error(standard_matrix_validate_cpp(handle), "closed")
    }
})

test_that("threshold context construction failures release the base matrix handle", {
    standard_matrix_require()
    initialize <- storage_standard_handle
    handle <- NULL
    testthat::local_mocked_bindings(
        storage_standard_handle = function(matrix_in) {
            handle <<- initialize(matrix_in)
            handle
        },
        standard_matrix_open_threshold_reader_cpp = function(handle) {
            stop("deliberate threshold context construction failure")
        },
        .package = "sceptre"
    )
    expect_error(
        storage_threshold_rows(
            DelayedArray::DelayedArray(standard_matrix_integer_input()),
            1L,
            0
        ),
        "deliberate threshold context construction failure"
    )
    expect_error(standard_matrix_validate_cpp(handle), "closed")
})
