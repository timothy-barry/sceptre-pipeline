# Frozen schema-four SCE input

Imported, prepared, and fitted with the exact selected RC11d installation from
archive SHA256 11d20a2a3297ca697e2e6e19b36a61c8f30cf9df7500d491e288982d8fe5c698,
source 83e1961a6085c1421e26fa290a57b4a88b4f1773. The original archive helper's
refactor_make_inputs()/high_complement_crt case, seed 44012, then public discovery
with output_amount=2 and print_progress=FALSE produced this input. It is a small
RAM object containing preparation, compact fits and a completed result. This is
an old-format migration input, not regenerated expected science. Do not rebuild
it with the package under test.

SHA256: 0cec0bf78e5ce20ab042cd554021932df382f3e5bed1928b2620c1cfd557b057
