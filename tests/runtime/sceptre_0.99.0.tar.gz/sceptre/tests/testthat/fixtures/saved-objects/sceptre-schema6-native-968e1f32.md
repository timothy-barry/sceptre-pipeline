# Frozen native schema-six input

Produced October22,2026 by the unchanged private installation qualified for source
968e1f32d0814fb57f24d975921a5337f480c7f8, archive SHA256
bc26554bc4f22bc647e90c786d17163e9d3ce9a6c1c93e2a4499acb1187de314.
The recipe uses exact-source helper-refactor.R refactor_make_inputs(), selecting
annotation rows c(7,2,5,1), and a factor annotation column, then refactor_import()
with high_perm. The fixture is a real imported native schema-six object with
parent-colData summaries, an ordered metadata annotation relation, and old
ResultRecord. Its role is input/migration authority, not a regenerated expected
scientific output. Existing historical fixtures were not modified.
