test_that("schema-six data migrates rowData and cell summaries without losing input order", {
    old <- readRDS(test_path("fixtures", "saved-objects", "sceptre-schema6-native-968e1f32.rds"))
    expect_identical(old@schema_version, 6L)
    original <- serialize(old, NULL)
    meta <- screen_meta(old@data)
    guide <- screen_guides(old@data)
    annotation <- S4Vectors::metadata(guide)$sceptre_annotations
    covariates <- SummarizedExperiment::colData(old@data)[, meta$covariate_names, drop = FALSE]
    summaries <- setNames(lapply(meta$guide_summary_columns,
        function(name) SummarizedExperiment::colData(old@data)[[name]]),
        names(meta$guide_summary_columns))
    withr::local_seed(381)
    rng <- .Random.seed
    migrated <- migrate_sceptre_object(old)
    expect_identical(migrated@schema_version, 7L)
    expect_identical(screen_cell_covariates(migrated@data), covariates)
    expect_identical(screen_guide_annotations(migrated@data), annotation)
    expect_identical(screen_guide_summary(migrated@data), summaries)
    expect_identical(screen_identity(migrated@data), meta$identity)
    expect_identical(screen_response_counts(migrated@data), screen_response_counts(old@data))
    expect_identical(screen_guide_counts(migrated@data), screen_guide_counts(old@data))
    expect_identical(.Random.seed, rng)
    expect_identical(migrate_sceptre_object(migrated), migrated)
    expect_identical(serialize(old, NULL), original)
    expect_true(validObject(migrated))
    path <- withr::local_tempfile(fileext = ".rds")
    write_sceptre_object(migrated, path)
    expect_identical(read_sceptre_object(path), migrated)
})

test_that("unsupported saved repeated guide mappings fail without rewriting the RDS", {
    old <- readRDS(test_path("fixtures", "saved-objects", "sceptre-schema6-native-968e1f32.rds"))
    guide <- screen_guides(old@data)
    annotation <- S4Vectors::metadata(guide)$sceptre_annotations
    for (conflict in c(FALSE, TRUE)) {
        invalid <- old
        repeated <- annotation[c(seq_len(nrow(annotation)), 1L), , drop = FALSE]
        if (conflict) repeated$grna_target[nrow(repeated)] <- "another-target"
        S4Vectors::metadata(guide)$sceptre_annotations <- repeated
        SingleCellExperiment::altExp(invalid@data, "gRNA") <- guide
        path <- withr::local_tempfile(fileext = ".rds")
        saveRDS(invalid, path)
        before <- readBin(path, "raw", n = file.info(path)$size)
        value <- serialize(invalid, NULL)
        expect_error(read_sceptre_object(path), "one row per grna_id")
        expect_identical(readBin(path, "raw", n = file.info(path)$size), before)
        expect_identical(serialize(invalid, NULL), value)
    }
})

test_that("vector optional annotations must resolve to one stored guide row", {
    metadata <- data.frame(grna_id = c("g1", "g2"), vector_id = c("v1", "v1"),
        grna_target = c("target", "target"), label = c("first", "second"))
    before <- serialize(metadata, NULL)
    expect_error(collapse_grna_target_data_frame(metadata),
        "one row per vector")
    expect_identical(serialize(metadata, NULL), before)
    metadata$label[] <- "same"
    expect_identical(collapse_grna_target_data_frame(metadata),
        data.frame(grna_id = "v1", grna_target = "target", label = "same"))
})


test_that("explicit unknown native layouts reject without rewriting saved work", {
    old <- readRDS(test_path("fixtures", "saved-objects", "sceptre-schema4-sce-rc11d.rds"))
    current <- migrate_sceptre_object(old)
    expect_null(screen_meta(old@data)$layout)
    expect_identical(screen_meta(current@data)$layout, 2L)
    withr::local_seed(946)
    rng <- .Random.seed
    for (legacy_codec in c(TRUE, FALSE)) {
        invalid <- current
        if (legacy_codec) invalid@data <- old@data
        meta <- screen_meta(invalid@data)
        meta$layout <- 99L
        screen_meta(invalid@data) <- meta
        SummarizedExperiment::colData(invalid@data)$unknown_layout_covariate <-
            seq_len(ncol(invalid@data))
        path <- withr::local_tempfile(fileext = ".rds")
        saveRDS(invalid, path)
        before <- readBin(path, "raw", n = file.info(path)$size)
        value <- serialize(invalid, NULL)
        expect_error(read_sceptre_object(path), "Unsupported native screen data layout")
        expect_identical(readBin(path, "raw", n = file.info(path)$size), before)
        expect_identical(serialize(invalid, NULL), value)
        expect_identical(.Random.seed, rng)
    }
})
