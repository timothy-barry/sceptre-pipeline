results_list_old_fixture <- function() {
    readRDS(test_path("fixtures", "saved-objects", "sceptre-schema4-sce-rc11d.rds"))
}

test_that("current results have exactly three direct ordinary-list entries", {
    empty <- new("sceptre_object")
    expect_type(empty@results, "list")
    expect_false(isS4(empty@results))
    expect_identical(names(empty@results),
        c("calibration_check", "power_check", "discovery_analysis"))
    expect_true(all(vapply(empty@results, is.null, logical(1))))
    object <- migrate_sceptre_object(results_list_old_fixture())
    record <- object@results$discovery_analysis
    expect_named(record, c("table", "identity", "provenance", "history"))
    expect_false(any(c("scope", "records", "import_metadata") %in% names(object@results)))
    expect_null(object@results$calibration_check)
    expect_null(object@results$power_check)
    expect_true(validate_analysis_results(object@results))
    expect_identical(saved_result_record(object, "discovery_analysis"),
        saved_result_record(object, "run_discovery_analysis"))
    expect_error(get_result(object, "discovery_analysis"), "analysis.*must be")
    expect_identical(record$provenance$plan@analysis, "run_discovery_analysis")
})

test_that("legacy completed results migrate only after genuine family validation", {
    old <- results_list_old_fixture()
    previous <- old@results@records$run_discovery_analysis
    before <- serialize(old, NULL)
    withr::local_seed(8317L)
    seed <- .Random.seed
    object <- migrate_sceptre_object(old)
    expect_true(result_record_is_current(object, "run_discovery_analysis"))
    expect_identical(object@results$discovery_analysis$table, previous$table)
    expect_identical(object@results$discovery_analysis$identity, previous$identity)
    expect_identical(.Random.seed, seed)
    expect_identical(serialize(old, NULL), before)
    path <- withr::local_tempfile(fileext = ".rds")
    write_sceptre_object(object, path)
    reopened <- read_sceptre_object(path)
    expect_identical(reopened, object)
    expect_true(result_record_is_current(reopened, "run_discovery_analysis"))
    expect_identical(migrate_sceptre_object(object), object)
})

test_that("unknown or partial old results stay historical when scope is removed", {
    for (scope in list(NULL, "unknown", "raw_shard")) {
        old <- results_list_old_fixture()
        old <- test_update_legacy_records(old, function(records) {
            records$run_discovery_analysis$scope <- scope
            records
        })
        previous <- old@results@records$run_discovery_analysis
        object <- migrate_sceptre_object(old)
        record <- object@results$discovery_analysis
        expect_false("scope" %in% names(record))
        expect_identical(record$table, previous$table)
        expect_identical(record$identity, previous$identity)
        expect_match(record$invalidated_by, "completeness unknown")
        expect_false(result_record_is_current(object, "run_discovery_analysis"))
        expect_error(get_result(object, "run_discovery_analysis"), "No completed current")
        expect_warning(historical <- get_result(object, "run_discovery_analysis", historical = TRUE), "historical")
        attr(historical, "sceptre_result_record") <- NULL
        expect_identical(historical, previous$table)
    }
    old <- results_list_old_fixture()
    old <- test_update_legacy_records(old, function(records) {
        records$run_discovery_analysis$table <- records$run_discovery_analysis$table[1L, , drop = FALSE]
        records
    })
    object <- migrate_sceptre_object(old)
    expect_false(result_record_is_current(object, "run_discovery_analysis"))
    expect_match(object@results$discovery_analysis$invalidated_by, "complete-family validation")
    expect_false("scope" %in% names(object@results$discovery_analysis))
})

test_that("history and stale reasons survive without a scope field or outer metadata", {
    old <- results_list_old_fixture()
    record <- old@results@records$run_discovery_analysis
    record$invalidated_by <- "saved upstream change"
    record$history <- list(record[setdiff(names(record), "history")])
    old <- test_update_legacy_records(old, function(records) {
        records$run_discovery_analysis <- record
        records
    })
    previous <- attr(old, "results")
    previous@import_metadata$compatibility_note <- "not scientific result state"
    attr(old, "results") <- previous
    object <- migrate_sceptre_object(old)
    result <- object@results$discovery_analysis
    expect_identical(result$invalidated_by, "saved upstream change")
    expect_identical(result$history[[1L]]$invalidated_by, "saved upstream change")
    expect_identical(result$history[[1L]]$table, record$table)
    expect_false("scope" %in% names(result))
    expect_false("scope" %in% names(result$history[[1L]]))
    expect_false("import_metadata" %in% names(object@results))
    expect_true(validate_analysis_results(object@results))
    expect_false(result_record_is_current(object, "run_discovery_analysis"))
})

test_that("unrecognized old result keys and current container fields cannot be discarded", {
    old <- results_list_old_fixture()
    old <- test_update_legacy_records(old, function(records) {
        records$unexpected_analysis <- records$run_discovery_analysis
        records
    })
    before <- serialize(old, NULL)
    expect_error(migrate_sceptre_object(old), "Unrecognized historical result-container")
    expect_identical(serialize(old, NULL), before)
    unnamed <- test_update_legacy_records(results_list_old_fixture(), unname)
    expect_error(migrate_sceptre_object(unnamed), "Unrecognized historical result-container")
    unexpected <- results_list_old_fixture()
    physical <- attr(unexpected, "results")
    attr(physical, "unexpected_payload") <- list(table = data.frame(x = 1L))
    attr(unexpected, "results") <- physical
    expect_error(migrate_sceptre_object(unexpected), "Unrecognized historical result-container")
    object <- migrate_sceptre_object(results_list_old_fixture())
    object@results$import_metadata <- list(legacy = TRUE)
    expect_error(migrate_sceptre_object(object), "ordinary list")
    object <- migrate_sceptre_object(results_list_old_fixture())
    object@results$discovery_analysis$scope <- "complete_family"
    expect_false(result_record_is_current(object, "run_discovery_analysis"))
    expect_error(migrate_sceptre_object(object), "unsupported fields")
})

test_that("removing the scope label leaves complete-family publication mandatory", {
    object <- migrate_sceptre_object(results_list_old_fixture())
    table <- object@results$discovery_analysis$table
    before <- serialize(object, NULL)
    plan <- make_run_plan(object, "run_discovery_analysis")
    expect_error(commit_result_record(object, "run_discovery_analysis",
        table[1L, , drop = FALSE], plan@pairs, 1L, plan), "complete run-plan")
    expect_identical(serialize(object, NULL), before)
    complete <- commit_result_record(object, "run_discovery_analysis", table,
        plan@pairs, 1L, plan)
    expect_true(result_record_is_current(complete, "run_discovery_analysis"))
    expect_false("scope" %in% names(complete@results$discovery_analysis))
    expect_identical(complete@results$discovery_analysis$history[[1L]]$table, table)
    expect_identical(names(complete@results), names(new_analysis_results()))
})
