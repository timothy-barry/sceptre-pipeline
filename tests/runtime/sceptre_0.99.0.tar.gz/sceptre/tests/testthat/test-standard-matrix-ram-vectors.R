ram_vector_fixture <- function() {
    counts <- standard_matrix_integer_input()
    colnames(counts) <- paste0("cell", seq_len(ncol(counts)))
    metadata <- data.frame(
        grna_id = c("r2", "r1"),
        grna_target = c("non-targeting", "A"),
        vector_id = c("vZ", "vA")
    )
    expected <- rbind(
        vZ = as.numeric(counts["r2", ]),
        vA = as.numeric(counts["r1", ])
    )
    colnames(expected) <- colnames(counts)
    list(counts = counts, metadata = metadata, expected = expected)
}

test_that("native RAM vector import preserves Matrix results without creating files", {
    standard_matrix_require()
    fixture <- ram_vector_fixture()
    reference <- suppressMessages(import_data(
        fixture$counts,
        fixture$counts,
        fixture$metadata,
        "low"
    ))
    native <- DelayedArray::DelayedArray(fixture$counts)
    variants <- list(
        native,
        DelayedArray::DelayedArray(methods::as(
            fixture$counts,
            "CsparseMatrix"
        )),
        DelayedArray::DelayedArray(methods::as(
            as.matrix(fixture$counts),
            "SVT_SparseMatrix"
        )),
        native[2:1, , drop = FALSE]
    )
    testthat::local_mocked_bindings(
        prepare_directory_to_write = function(...) {
            stop("RAM aggregation attempted file output")
        },
        .package = "sceptre"
    )
    for (guides in variants) {
        before <- serialize(list(native, guides, fixture$metadata), NULL)
        withr::local_seed(871)
        rng <- .Random.seed
        actual <- suppressMessages(import_data(
            native,
            guides,
            fixture$metadata,
            "low"
        ))
        expect_identical(.Random.seed, rng)
        expect_identical(as.matrix(get_grna_matrix(actual)), fixture$expected)
        expect_identical(
            get_cell_covariates(actual),
            get_cell_covariates(reference)
        )
        expect_identical(
            sceptre:::screen_guide_summary(actual@data),
            sceptre:::screen_guide_summary(reference@data)
        )
        expect_identical(
            sceptre:::screen_guide_annotations(actual@data),
            sceptre:::screen_guide_annotations(reference@data)
        )
        expect_false(count_matrix_is_backed(get_grna_matrix(actual)))
        expect_null(count_backing_descriptor(get_grna_matrix(actual)))
        for (row in 1:2) {
            expect_identical(
                storage_threshold_row(get_grna_matrix(actual), row, 0),
                which(fixture$expected[row, ] != 0) |> unname()
            )
        }
        expect_identical(
            serialize(list(native, guides, fixture$metadata), NULL),
            before
        )
    }
})

test_that("RAM vector output keeps feature and cell axes for small or empty dimensions", {
    standard_matrix_require()
    fixture <- ram_vector_fixture()
    for (columns in list(4L, integer(), c(12L, 4L, 12L))) {
        guides <- DelayedArray::DelayedArray(fixture$counts[,
            columns,
            drop = FALSE
        ])
        expected <- fixture$expected[, columns, drop = FALSE]
        actual <- collapse_standard_ram_grna_matrix(guides, fixture$metadata)
        expect_identical(dim(actual), dim(expected))
        expect_identical(dimnames(actual), dimnames(expected))
        expect_identical(as.matrix(actual), expected)
        expect_false(count_matrix_is_backed(actual))
    }
    empty <- collapse_standard_ram_grna_matrix(
        DelayedArray::DelayedArray(fixture$counts),
        fixture$metadata[integer(), ]
    )
    expect_identical(dim(empty), c(0L, ncol(fixture$counts)))
    expect_identical(colnames(empty), colnames(fixture$counts))
})

test_that("raw invalid RAM guide counts are rejected before vector sums can hide them", {
    standard_matrix_require()
    fixture <- ram_vector_fixture()
    for (value in c(0.5, -1, NA_real_, Inf)) {
        invalid <- fixture$counts
        invalid@x[1L] <- value
        expect_error(
            import_data(
                fixture$counts,
                DelayedArray::DelayedArray(invalid),
                fixture$metadata,
                "low"
            ),
            "integer.*UMI|UMI.*integer"
        )
    }
})

test_that("public RAM vector sums retain the platform's large-integer accumulator", {
    standard_matrix_require()
    guides <- matrix(
        rep(c(2^53, 1, 1), 2L),
        3L,
        dimnames = list(c("large", "one", "another"), c("a", "b"))
    )
    response <- matrix(1, 1L, 2L, dimnames = list("response", colnames(guides)))
    metadata <- data.frame(
        grna_id = rownames(guides),
        grna_target = "non-targeting",
        vector_id = "v"
    )
    expected <- matrix(
        base::colSums(guides),
        1L,
        dimnames = list("v", colnames(guides))
    )
    ordinary <- suppressMessages(import_data(response, guides, metadata, "low"))
    native <- suppressMessages(import_data(
        response,
        DelayedArray::DelayedArray(guides),
        metadata,
        "low"
    ))
    expect_identical(as.matrix(get_grna_matrix(native)), expected)
    expect_identical(as.matrix(get_grna_matrix(ordinary)), expected)
    expect_identical(get_cell_covariates(native), get_cell_covariates(ordinary))
})

test_that("RAM vector column blocks retain repeated metadata rows in each cell sum", {
    standard_matrix_require()
    n_cells <- 1025L
    counts <- Matrix::sparseMatrix(
        i = rep(1:3, n_cells),
        j = rep(seq_len(n_cells), each = 3L),
        x = rep(c(2^53, 1, 1), n_cells),
        dims = c(3L, n_cells),
        dimnames = list(
            c("large", "one", "another"),
            paste0("c", seq_len(n_cells))
        )
    )
    metadata <- data.frame(
        grna_id = c(rownames(counts), rep("one", 1022L)),
        grna_target = "non-targeting",
        vector_id = "v"
    )
    selected <- as.matrix(counts[metadata$grna_id, , drop = FALSE])
    expected <- matrix(
        base::colSums(selected),
        1L,
        dimnames = list("v", colnames(counts))
    )
    response <- matrix(
        1,
        1L,
        n_cells,
        dimnames = list("response", colnames(counts))
    )
    before <- serialize(list(counts, metadata), NULL)
    observed <- list()
    block_sum <- sum_sparse_vector_rows
    as_matrix <- get(
        "as.matrix",
        envir = environment(block_sum),
        inherits = TRUE
    )
    scope <- new.env(parent = environment(block_sum))
    scope$as.matrix <- function(x, ...) {
        observed[[length(observed) + 1L]] <<- dim(x)
        as_matrix(x, ...)
    }
    environment(block_sum) <- scope
    testthat::local_mocked_bindings(
        sum_sparse_vector_rows = block_sum,
        .package = "sceptre"
    )
    expect_error(import_data(response, DelayedArray::DelayedArray(counts),
        metadata, "low"), "one row per grna_id")
    actual <- collapse_standard_grna_matrix(
        DelayedArray::DelayedArray(counts), metadata, NULL)
    expect_identical(as.matrix(actual), expected)
    expect_identical(observed, list(c(1025L, 1023L), c(1025L, 2L)))
    expect_true(all(vapply(observed, prod, numeric(1)) <= 2^20))
    expect_identical(serialize(list(counts, metadata), NULL), before)
    expect_false(count_matrix_is_backed(actual))
})

test_that("SCE assays with RAM seeds aggregate vectors without a directory", {
    standard_matrix_require()
    skip_if_not_installed("SingleCellExperiment")
    fixture <- ram_vector_fixture()
    counts <- DelayedArray::DelayedArray(fixture$counts)
    sce <- SingleCellExperiment::SingleCellExperiment(
        assays = list(counts = counts)
    )
    SingleCellExperiment::altExp(sce, "gRNA", withDimnames = FALSE) <-
        SummarizedExperiment::SummarizedExperiment(
            assays = list(counts = counts)
        )
    metadata <- fixture$metadata[c(2L, 1L), ]
    before <- serialize(sce, NULL)
    actual <- suppressMessages(import_from_sce(sce, metadata, "low"))
    reference <- suppressMessages(import_data(
        fixture$counts,
        fixture$counts,
        metadata,
        "low"
    ))
    expect_identical(
        as.matrix(get_grna_matrix(actual)),
        as.matrix(get_grna_matrix(reference))
    )
    expect_identical(
        get_cell_covariates(actual),
        get_cell_covariates(reference)
    )
    expect_false(count_matrix_is_backed(get_grna_matrix(actual)))
    expect_identical(serialize(sce, NULL), before)
})
