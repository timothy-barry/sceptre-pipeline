test_that("scoped response readers preserve fixed cell views and release native state", {
    standard_matrix_require()
    directory <- tempfile("standard-scoped-reader-")
    on.exit(unlink(directory, recursive = TRUE), add = TRUE)
    matrix <- standard_matrix_integer_input()
    backed <- standard_matrix_fixture(
        matrix,
        directory,
        preserve_stored_zeros = TRUE
    )
    stores <- list(
        matrix,
        DelayedArray::DelayedArray(matrix),
        backed,
        DelayedArray::DelayedArray(as.matrix(matrix)),
        # Dense row-major native extraction can return a pointer to backing
        # storage instead of filling the supplied R output buffer.
        t(DelayedArray::DelayedArray(t(as.matrix(matrix))))
    )
    for (store in stores) {
        before <- suppressWarnings(serialize(store, NULL))
        for (cells in list(
            NULL,
            integer(),
            c(11L, 4L, 11L, 8L, 1L),
            c(1L, 4L, 8L),
            2:8,
            1L
        )) {
            reader <- storage_open_response_reader(store, cells)
            for (row in c(2L, 1L, 2L)) {
                expect_identical(
                    reader$read(row),
                    storage_read_response(matrix, row, cells)
                )
            }
            if (storage_is_standard_matrix(store)) {
                expect_error(reader$read(0L), "feature range")
            }
            expect_silent(reader$close())
            expect_silent(reader$close())
            expect_error(reader$read(1L), "closed")
        }
        expect_identical(suppressWarnings(serialize(store, NULL)), before)
    }
})

test_that("native response readers retain RAM descriptors after base release and GC", {
    standard_matrix_require()
    expected <- storage_read_response(
        standard_matrix_integer_input(),
        1L,
        c(11L, 4L, 11L)
    )
    handle <- storage_standard_handle(DelayedArray::DelayedArray(standard_matrix_integer_input()))
    reader <- standard_matrix_open_response_reader_cpp(handle, c(11L, 4L, 11L))
    on.exit(standard_matrix_close_response_reader_cpp(reader), add = TRUE)
    standard_matrix_release_cpp(handle)
    invisible(gc())
    expect_identical(standard_matrix_read_response_cpp(reader, 1L), expected)
    expect_error(
        standard_matrix_release_cpp(reader),
        "prepared response reader"
    )
    expect_error(
        standard_matrix_validate_cpp(reader),
        "prepared response reader"
    )
    expect_identical(standard_matrix_read_response_cpp(reader, 1L), expected)
    standard_matrix_close_response_reader_cpp(reader)
    expect_error(standard_matrix_read_response_cpp(reader, 1L), "closed")
    expect_silent(standard_matrix_close_response_reader_cpp(reader))
    expect_error(
        standard_matrix_read_response_cpp(handle, 1L),
        "not a standard native reader"
    )
})

test_that("prepared readers initialize once and close base handles on construction errors", {
    standard_matrix_require()
    store <- DelayedArray::DelayedArray(standard_matrix_integer_input())
    initialize <- storage_standard_handle
    handles <- list()
    testthat::local_mocked_bindings(
        storage_standard_handle = function(matrix_in) {
            handle <- initialize(matrix_in)
            handles[[length(handles) + 1L]] <<- handle
            handle
        },
        .package = "sceptre"
    )
    reader <- storage_open_response_reader(store, c(4L, 1L, 4L))
    on.exit(reader$close(), add = TRUE)
    reader$read(1L)
    reader$read(2L)
    expect_length(handles, 1L)
    expect_error(standard_matrix_read_row_cpp(handles[[1L]], 1L), "closed")
    expect_error(storage_open_response_reader(store, 0L), "Source cells")
    expect_error(standard_matrix_read_row_cpp(handles[[2L]], 1L), "closed")
    failed_reader <- NULL
    expect_error(
        (function() {
            scoped <- storage_open_response_reader(store)
            failed_reader <<- scoped
            on.exit(scoped$close())
            stop("deliberate worker failure")
        })(),
        "deliberate worker failure"
    )
    expect_error(failed_reader$read(1L), "closed")
})

test_that("batched thresholds preserve sparse structure, requested order and repeats", {
    standard_matrix_require()
    directory <- tempfile("standard-batch-threshold-")
    on.exit(unlink(directory, recursive = TRUE), add = TRUE)
    matrix <- standard_matrix_integer_input()
    sparse <- standard_matrix_fixture(
        matrix,
        directory,
        preserve_stored_zeros = TRUE
    )
    dense <- DelayedArray::DelayedArray(as.matrix(matrix))
    for (store in list(
        matrix,
        DelayedArray::DelayedArray(matrix),
        sparse,
        dense
    )) {
        reference <- if (identical(store, dense)) {
            as(
                Matrix::Matrix(as.matrix(matrix), sparse = TRUE),
                "RsparseMatrix"
            )
        } else {
            matrix
        }
        for (rows in list(c(2L, 1L, 2L), 1L, integer())) {
            for (threshold in c(-1, 0, 0.5, 2.8, Inf, NA_real_)) {
                expect_identical(
                    storage_threshold_rows(store, rows, threshold),
                    lapply(rows, function(row) {
                        storage_threshold_row(reference, row, threshold)
                    })
                )
            }
        }
    }
    expect_error(storage_threshold_rows(sparse, 0L, 1), "Requested response")
})

test_that("batched sparse thresholds need one initialization and no full-width R buffer", {
    standard_matrix_require()
    width <- 100000L
    counts <- Matrix::sparseMatrix(
        i = c(1L, 1L, 2L),
        j = c(1L, 99991L, 50L),
        x = c(0, 7, 1),
        dims = c(2L, width)
    )
    store <- DelayedArray::DelayedArray(counts)
    initialize <- storage_standard_handle
    ninit <- 0L
    testthat::local_mocked_bindings(
        storage_standard_handle = function(matrix_in) {
            ninit <<- ninit + 1L
            initialize(matrix_in)
        },
        .package = "sceptre"
    )
    expect_identical(
        storage_threshold_rows(store, c(2L, 1L, 2L), 0),
        list(50L, c(1L, 99991L), 50L)
    )
    expect_identical(ninit, 1L)
    skip_if_not(capabilities("profmem"))
    storage_threshold_rows(store, c(1L, 2L), 1)
    path <- tempfile("standard-batched-rprofmem-")
    on.exit(unlink(path), add = TRUE)
    utils::Rprofmem(path)
    on.exit(utils::Rprofmem(NULL), add = TRUE)
    storage_threshold_rows(store, c(1L, 2L, 1L), 1)
    utils::Rprofmem(NULL)
    sizes <- suppressWarnings(as.double(sub(
        " .*",
        "",
        readLines(path, warn = FALSE)
    )))
    expect_lt(max(c(0, sizes[is.finite(sizes)])), 4 * width)
})

test_that("closing one sparse response reader leaves sibling readers open", {
    matrix <- standard_matrix_integer_input()
    first <- storage_open_response_reader(matrix, c(4L, 1L, 4L))
    second <- storage_open_response_reader(matrix, integer())
    on.exit(first$close(), add = TRUE)
    on.exit(second$close(), add = TRUE)
    expected <- first$read(1L)
    first$close()
    expect_error(first$read(1L), "closed")
    expect_identical(second$read(1L), numeric())
    expect_silent(first$close())
    third <- storage_open_response_reader(matrix, c(4L, 1L, 4L))
    on.exit(third$close(), add = TRUE)
    expect_identical(third$read(1L), expected)
})
