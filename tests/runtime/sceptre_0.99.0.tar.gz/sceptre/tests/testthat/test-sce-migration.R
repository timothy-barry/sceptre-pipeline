test_that("schema seven owns native aligned SCE data", {
    object <- refactor_import(refactor_make_inputs(), refactor_case_definitions()$high_perm)
    sce <- get_screen_experiment(object)
    expect_s4_class(sce, "SingleCellExperiment")
    expect_identical(object@schema_version, 7L)
    expect_identical(screen_response_counts(sce), get_response_matrix(object))
    expect_identical(screen_guide_counts(sce), get_grna_matrix(object))
    expect_s4_class(screen_cell_covariates(sce), "DataFrame")
    expect_s3_class(get_cell_covariates(object), "data.frame")
    expect_identical(rownames(screen_cell_covariates(sce)), colnames(sce))
    expect_identical(screen_meta(sce)$layout, 2L)
    expect_true(validObject(object))
})

test_that("physical ScreenData migration preserves values and identifiers once", {
    object <- refactor_import(refactor_make_inputs(), refactor_case_definitions()$high_perm)
    fields <- names(formals(new_screen_experiment))
    values <- setNames(lapply(fields, function(n) screen_test_field(object@data, n)), fields)
    legacy <- do.call(methods::new, c(list(Class = "ScreenData"), values))
    attr(object, "data") <- legacy
    attr(object, "results") <- methods::new("ResultRecord")
    attr(object, "schema_version") <- 3L
    before <- serialize(object, NULL)
    result <- migrate_sceptre_object(object)
    expect_identical(result@schema_version, 7L)
    for (name in setdiff(fields, c("covariate_data_frame", "grna_target_data_frame"))) {
        expect_identical(screen_test_field(result@data, name), values[[name]], info = name)
    }
    for (name in names(values$covariate_data_frame)) {
        expect_identical(screen_cell_covariates(result@data)[[name]], values$covariate_data_frame[[name]])
    }
    for (name in names(values$grna_target_data_frame)) {
        expect_identical(screen_guide_annotations(result@data)[[name]], values$grna_target_data_frame[[name]])
    }
    expect_identical(serialize(object, NULL), before)
    expect_identical(migrate_sceptre_object(result), result)
    expect_true(validObject(result))
})

test_that("the independent experimental schema-five format is rejected", {
    object <- new("sceptre_object")
    attr(object, "schema_version") <- 5L
    expect_error(migrate_sceptre_object(object), "Unsupported.*schema version")
})

test_that("native screen metadata validates its mapping contract", {
    object <- refactor_import(refactor_make_inputs(), refactor_case_definitions()$high_perm)
    sce <- object@data
    meta <- screen_meta(sce)
    meta$covariate_names <- c(meta$covariate_names, "missing")
    screen_meta(sce) <- meta
    expect_match(validate_screen_experiment(sce), "native screen metadata")
    sce <- object@data
    guide <- screen_guides(sce)
    SummarizedExperiment::colData(guide)$unexpected <- seq_len(ncol(sce))
    SingleCellExperiment::altExp(sce, "gRNA") <- guide
    expect_match(validate_screen_experiment(sce), "guide cell-summary")
})


test_that("frozen populated RC11d SCE migration preserves science, RNG and currentness", {
    old <- readRDS(test_path("fixtures", "saved-objects", "sceptre-schema4-sce-rc11d.rds"))
    expect_identical(old@schema_version, 4L)
    original <- serialize(old, NULL)
    withr::local_seed(718)
    rng <- .Random.seed
    object <- migrate_sceptre_object(old)
    expect_identical(object@schema_version, 7L)
    expect_identical(.Random.seed, rng)
    expect_identical(screen_identity(object@data), legacy_screen_field(old@data, "identity"))
    expect_identical(screen_response_counts(object@data), legacy_screen_field(old@data, "response_matrix"))
    expect_identical(screen_guide_counts(object@data), legacy_screen_field(old@data, "grna_matrix"))
    for (name in names(legacy_screen_field(old@data, "covariate_data_frame"))) {
        expect_identical(screen_cell_covariates(object@data)[[name]], legacy_screen_field(old@data, "covariate_data_frame")[[name]])
    }
    expect_identical(object@spec, old@spec)
    expect_identical(object@preparation, old@preparation)
    expect_identical(object@fits, old@fits)
    for (method in analysis_names()) {
        expected <- old@results@records[[method]]
        if (!is.null(expected)) expected$scope <- NULL
        expect_identical(object@results[[sub("^run_", "", method)]], expected)
    }
    expect_identical(screen_backing_anchors(object@data), old@results@import_metadata$backing_stores)
    expect_true(workflow_status(object)[["run_discovery_analysis"]])
    expect_identical(get_result(object, "run_discovery_analysis"), object@results$discovery_analysis$table)
    expect_identical(serialize(old, NULL), original)
    expect_identical(migrate_sceptre_object(object), object)
    expect_true(validObject(object))
    path <- withr::local_tempfile(fileext = ".rds")
    write_sceptre_object(object, path)
    expect_identical(read_sceptre_object(path), object)
})
