test_that("SVT leaves are validated before native reader initialization", {
    standard_matrix_require()
    skip_if_not_installed("SparseArray")
    seed <- methods::as(
        matrix(c(2L, 0L, 4L, 1L, 0L, 1L), 3L),
        "SVT_SparseMatrix"
    )
    malformed <- list()
    add <- function(change) {
        value <- seed
        value@SVT <- change(value@SVT)
        malformed[[length(malformed) + 1L]] <<- value
    }
    for (indices in list(
        c(0L, 0L),
        c(2L, 1L),
        c(-1L, 1L),
        c(0L, 3L),
        c(0L, NA_integer_)
    )) {
        add(function(tree) {
            tree[[1L]][[2L]] <- indices
            tree
        })
    }
    add(function(tree) {
        tree[[1L]] <- list(1:4, c(0L, 0L, 1L, 2L))
        tree
    })
    add(function(tree) {
        tree[[1L]][[1L]] <- 2L
        tree
    })
    add(function(tree) {
        tree[[1L]][[1L]] <- c(2, 4)
        tree
    })
    add(function(tree) {
        tree[[1L]][[2L]] <- c(0, 2)
        tree
    })
    add(function(tree) {
        tree[[1L]] <- list(1L, 0L, NULL)
        tree
    })
    add(function(tree) tree[1L])
    # SparseArray's own validity accepts duplicate leaves: this guard must run
    # before the adapter copies their payload into dimension-sized buffers.
    expect_true(methods::validObject(malformed[[1L]], complete = TRUE))
    testthat::local_mocked_bindings(
        initializeCpp = function(...) stop("native initializer reached"),
        .package = "beachmat"
    )
    for (invalid in malformed) {
        expect_error(
            storage_standard_handle(DelayedArray::DelayedArray(invalid)),
            "SVT sparse matrix"
        )
    }
})

test_that("valid SVT numeric and lacunar leaves retain delayed view semantics", {
    standard_matrix_require()
    skip_if_not_installed("SparseArray")
    for (values in list(
        c(2L, 0L, 4L, 1L, 0L, 1L),
        c(2, 0, 4, 1, 0, 1),
        rep(0L, 6L)
    )) {
        dense <- matrix(values, 3L)
        matrix <- DelayedArray::DelayedArray(methods::as(
            dense,
            "SVT_SparseMatrix"
        ))
        expect_silent(storage_prepare_standard_matrix(matrix))
        view <- matrix[c(3L, 1L, 1L), c(2L, 1L, 2L), drop = FALSE]
        expected <- dense[c(3L, 1L, 1L), c(2L, 1L, 2L), drop = FALSE]
        for (row in 1:3) {
            expect_identical(
                storage_read_response(view, row),
                as.numeric(expected[row, ])
            )
        }
    }
})

test_that("raw sparse Matrix validity is checked before native initialization", {
    standard_matrix_require()
    invalid <- methods::as(standard_matrix_integer_input(), "CsparseMatrix")
    invalid@i[2L] <- invalid@i[1L]
    invalid@p[2L] <- 2L
    testthat::local_mocked_bindings(
        initializeCpp = function(...) stop("native initializer reached"),
        .package = "beachmat"
    )
    expect_error(
        storage_standard_handle(DelayedArray::DelayedArray(invalid)),
        "invalid class|not.*increasing|sorted"
    )
})

test_that("HDF5 sparse pointer extents are rejected before native extraction", {
    standard_matrix_require()
    path <- file.path(withr::local_tempdir(), "oversized-column.h5")
    rhdf5::h5createFile(path)
    rhdf5::h5createGroup(path, "counts")
    rhdf5::h5write(c(2L, 3L, 5L), path, "counts/data")
    rhdf5::h5write(c(0L, 0L, 1L), path, "counts/indices")
    rhdf5::h5write(c(0L, 3L, 3L), path, "counts/indptr")
    rhdf5::h5write(c(2L, 2L), path, "counts/shape")
    bad <- HDF5Array::TENxMatrix(path, "counts")
    testthat::local_mocked_bindings(
        initializeCpp = function(...) stop("native initializer reached"),
        .package = "beachmat"
    )
    expect_error(
        storage_standard_handle(bad),
        "pointer ranges.*noncanonical|exceed"
    )
    for (ranges in list(
        data.frame(start = c(1, 2), width = c(-1, 0)),
        data.frame(start = c(1, 2), width = c(0.5, 0)),
        data.frame(start = c(1, 5), width = c(1, 0)),
        data.frame(start = c(1, NA_real_), width = c(1, 0))
    )) {
        seed <- DelayedArray::seed(bad)
        seed@indptr_ranges <- ranges
        expect_error(
            storage_standard_handle(DelayedArray::DelayedArray(seed)),
            "pointer ranges.*noncanonical|exceed"
        )
    }
})
