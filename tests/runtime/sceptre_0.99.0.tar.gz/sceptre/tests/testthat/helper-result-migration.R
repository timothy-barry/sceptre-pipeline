# Historical fixtures physically contain the former ResultRecord slot value.
# The current coordinator declares a list slot, so test mutation must replace
# the serialized attribute rather than invoking today's nested slot setter.
# This helper changes only test inputs; package migration still reads old bytes.
test_update_legacy_records <- function(object, update) {
    previous <- attr(object, "results")
    previous@records <- update(previous@records)
    attr(object, "results") <- previous
    object
}
