test_that("native standard handles close after successful operations", {
    standard_matrix_require()
    directory <- tempfile("standard-handle-success-")
    on.exit(unlink(directory, recursive = TRUE), add = TRUE)
    matrix <- standard_matrix_integer_input()
    store <- standard_matrix_fixture(
        matrix,
        directory,
        preserve_stored_zeros = TRUE
    )
    before <- suppressWarnings(serialize(store, NULL))
    handle <- NULL
    result <- storage_standard_call(store, function(initialized) {
        handle <<- initialized
        standard_matrix_read_row_cpp(initialized, 1L, c(11L, 4L, 11L, 8L, 1L))
    })
    expect_identical(
        result,
        storage_read_response(matrix, 1L, c(11L, 4L, 11L, 8L, 1L))
    )
    expect_error(standard_matrix_read_row_cpp(handle, 1L, NULL), "closed")
    expect_error(standard_matrix_validate_cpp(handle), "closed")
    expect_error(
        standard_matrix_cell_covariates_cpp(handle, integer(), FALSE, FALSE),
        "closed"
    )
    expect_silent(standard_matrix_release_cpp(handle))
    expect_silent(standard_matrix_release_cpp(handle))
    expect_identical(suppressWarnings(serialize(store, NULL)), before)
})

test_that("native standard handles close on R and native consumer errors", {
    standard_matrix_require()
    store <- DelayedArray::DelayedArray(standard_matrix_covariate_input())
    handle <- NULL
    expect_error(
        storage_standard_call(store, function(initialized) {
            handle <<- initialized
            stop("deliberate R consumer failure")
        }),
        "deliberate R consumer failure",
        fixed = TRUE
    )
    expect_error(standard_matrix_read_row_cpp(handle, 1L, NULL), "closed")
    expect_error(
        storage_standard_call(store, function(initialized) {
            handle <<- initialized
            standard_matrix_read_row_cpp(initialized, -1L, NULL)
        }),
        "one-based feature range"
    )
    expect_error(standard_matrix_read_row_cpp(handle, 1L, NULL), "closed")
})

test_that("every standard storage operation releases transient readers", {
    standard_matrix_require()
    directory <- tempfile("standard-handle-operations-")
    on.exit(unlink(directory, recursive = TRUE), add = TRUE)
    store <- standard_matrix_fixture(
        standard_matrix_integer_input(),
        directory,
        preserve_stored_zeros = TRUE
    )
    initialize <- storage_standard_handle
    handles <- list()
    testthat::local_mocked_bindings(
        storage_standard_handle = function(matrix_in) {
            handle <- initialize(matrix_in)
            handles[[length(handles) + 1L]] <<- handle
            handle
        },
        .package = "sceptre"
    )
    storage_prepare_standard_matrix(store)
    storage_read_response(store, 1L, c(11L, 4L, 11L))
    storage_threshold_row(store, 1L, 2.8)
    storage_group_counts(store, c(2L, 1L), list(c(1L, 2L)), c(4L, 8L, 11L))
    storage_pair_counts(
        store,
        data.frame(response_idx = c(2L, 1L), group_idx = c(1L, 1L)),
        list(c(1L, 2L)),
        c(4L, 8L, 11L),
        "complement",
        list(3L)
    )
    storage_cell_covariates(store, 1L, TRUE, TRUE)
    expect_gte(length(handles), 6L)
    for (handle in handles) {
        expect_error(standard_matrix_read_row_cpp(handle, 1L, NULL), "closed")
    }
})

test_that("sparse guide threshold results do not allocate dense R scratch space", {
    standard_matrix_require()
    skip_if_not(capabilities("profmem"), "R memory profiling is unavailable")
    width <- 100000L
    counts <- Matrix::sparseMatrix(
        i = c(1L, 1L, 2L),
        j = c(1L, 99991L, 50L),
        x = c(2, 7, 1),
        dims = c(2L, width)
    )
    store <- DelayedArray::DelayedArray(counts)
    path <- tempfile("standard-threshold-rprofmem-")
    on.exit(unlink(path), add = TRUE)
    sizes <- storage_standard_call(store, function(handle) {
        standard_matrix_threshold_row_cpp(handle, 1L, 5)
        utils::Rprofmem(path)
        on.exit(utils::Rprofmem(NULL), add = TRUE)
        result <- standard_matrix_threshold_row_cpp(handle, 1L, 5)
        utils::Rprofmem(NULL)
        expect_identical(result, 99991L)
        allocation_lines <- readLines(path, warn = FALSE)
        sizes <- suppressWarnings(as.double(sub(" .*", "", allocation_lines)))
        sizes[is.finite(sizes)]
    })
    expect_lt(if (length(sizes)) max(sizes) else 0, 4 * width)
})
