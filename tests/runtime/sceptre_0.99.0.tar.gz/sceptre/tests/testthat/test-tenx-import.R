# Physical integer HDF5 storage is part of the ordinary Bioconductor matrix
# contract. Compare exact numeric values and names, without coercion tolerance.
tenx_expect_same_counts <- function(actual, expected) {
    expect_identical(dim(actual), dim(expected))
    expect_identical(dimnames(actual), dimnames(expected))
    for (row in seq_len(nrow(expected))) {
        expect_identical(storage_read_response(actual, row),
                         as.double(expected[row, ]))
    }
}

tenx_test_fixture <- function(directory, hdf5 = FALSE) {
    inputs <- refactor_make_inputs()
    x <- rbind(
        inputs$response_matrix,
        inputs$low_grna_matrix,
        antibody = rep(2, ncol(inputs$response_matrix))
    )
    # Interleave modalities while retaining the order within each modality.
    order <- c(as.vector(rbind(seq_len(8L), 8L + seq_len(8L))), 17L)
    x <- methods::as(Matrix::Matrix(x[order, ], sparse = TRUE), "CsparseMatrix")
    types <- c(
        rep("Gene Expression", 8L),
        rep("CRISPR Guide Capture", 8L),
        "Antibody Capture"
    )[order]
    symbols <- c(
        "MT-first",
        paste0("symbol", 2:8),
        rownames(inputs$low_grna_matrix),
        "antibody"
    )[order]
    path <- if (hdf5) {
        file.path(directory, "counts.h5")
    } else {
        file.path(directory, "counts")
    }
    DropletUtils::write10xCounts(
        path,
        x,
        gene.id = rownames(x),
        gene.symbol = symbols,
        gene.type = types,
        version = "3",
        type = if (hdf5) "hdf5" else "mtx"
    )
    list(
        path = path,
        inputs = inputs,
        symbols = symbols[types == "Gene Expression"]
    )
}

test_that("10x MTX and HDF5 imports preserve complete-library counts and covariates", {
    standard_matrix_require()
    skip_if_not_installed("DropletUtils", "1.32.0")
    directory <- withr::local_tempdir()
    for (hdf5 in c(FALSE, TRUE)) {
        fixture <- tenx_test_fixture(directory, hdf5)
        input <- fixture$inputs
        expected <- import_data(
            input$response_matrix,
            input$low_grna_matrix,
            input$grna_target_data_frame,
            "low",
            response_names = fixture$symbols
        )
        actual <- suppressMessages(import_data_from_10x(
            fixture$path,
            "low",
            input$grna_target_data_frame,
            file.path(directory, "output"),
            block_rows = 3L
        ))
        expect_s4_class(get_response_matrix(actual), "DelayedMatrix")
        tenx_expect_same_counts(get_response_matrix(actual), input$response_matrix)
        tenx_expect_same_counts(get_grna_matrix(actual), input$low_grna_matrix)
        expect_identical(
            get_cell_covariates(actual),
            get_cell_covariates(expected)
        )
        expect_false("batch" %in% names(get_cell_covariates(actual)))
        handle <- storage_standard_handle(get_response_matrix(actual))
        expect_true(beachmat::tatami.prefer.rows(handle))
        standard_matrix_release_cpp(handle)
    }
})

test_that("single-sample compatibility and native imports preserve caller batch covariates", {
    standard_matrix_require()
    skip_if_not_installed("DropletUtils", "1.32.0")
    fixture <- tenx_test_fixture(withr::local_tempdir())
    input <- fixture$inputs
    n <- ncol(input$response_matrix)
    for (batch in list(factor(rep("user_batch", n)), factor(rep(c("a", "b"), length.out = n)))) {
        extra <- data.frame(batch = batch, z = sin(seq_len(n)),
            row.names = colnames(input$response_matrix))
        before <- serialize(extra, NULL)
        ram <- suppressMessages(import_data_from_cellranger(fixture$path, "low",
            input$grna_target_data_frame, extra_covariates = extra))
        native <- suppressMessages(import_data_from_10x(fixture$path, "low",
            input$grna_target_data_frame, withr::local_tempdir(), extra_covariates = extra))
        expect_identical(get_cell_covariates(ram)$batch, batch)
        expect_identical(get_cell_covariates(native), get_cell_covariates(ram))
        ram <- suppressMessages(set_analysis_parameters(ram, discovery_pairs = input$discovery_pairs))
        native <- suppressMessages(set_analysis_parameters(native, discovery_pairs = input$discovery_pairs))
        expect_identical(native@spec@formula_object, ram@spec@formula_object)
        expect_identical(native@preparation@design_matrix, ram@preparation@design_matrix)
        expect_identical("batch" %in% all.vars(ram@spec@formula_object), nlevels(batch) > 1L)
        expect_identical(serialize(extra, NULL), before)
    }
})

test_that("10x concatenation and vector aggregation preserve cell order and definitions", {
    standard_matrix_require()
    skip_if_not_installed("DropletUtils", "1.32.0")
    fixture <- tenx_test_fixture(withr::local_tempdir())
    input <- fixture$inputs
    metadata <- input$grna_target_data_frame
    metadata$vector_id <- c("va", "va", "vb", "vb", paste0("vn", 1:4))
    response <- cbind(input$response_matrix, input$response_matrix)
    guides <- cbind(input$low_grna_matrix, input$low_grna_matrix)
    cells <- paste0(
        rep(c("b1_", "b2_"), each = ncol(input$response_matrix)),
        rep(colnames(input$response_matrix), 2L)
    )
    colnames(response) <- colnames(guides) <- cells
    extra <- data.frame(
        z = seq_along(cells),
        batch = factor(rep(c("b1", "b2"), each = ncol(input$response_matrix))),
        row.names = cells
    )
    expected <- import_data(
        response,
        guides,
        metadata,
        "low",
        extra_covariates = extra,
        response_names = fixture$symbols
    )
    actual <- suppressMessages(import_data_from_10x(
        rep(fixture$path, 2L),
        "low",
        metadata,
        file.path(withr::local_tempdir(), "output"),
        extra_covariates = extra,
        block_rows = 3L
    ))
    tenx_expect_same_counts(get_response_matrix(actual), get_response_matrix(expected))
    tenx_expect_same_counts(get_grna_matrix(actual), get_grna_matrix(expected))
    expect_identical(get_cell_covariates(actual), get_cell_covariates(expected))
    expect_identical(colnames(get_response_matrix(actual)), cells)
})

test_that("standard 10x writing preserves stored zeros and source inputs", {
    standard_matrix_require()
    x <- standard_matrix_integer_input()
    before <- serialize(x, NULL)
    output <- tenx_write_feature_major(
        list(DelayedArray::DelayedArray(x)),
        file.path(withr::local_tempdir(), "zeros.h5"),
        1L
    )
    for (row in seq_len(nrow(x))) {
        expect_identical(
            storage_read_response(output, row),
            storage_read_response(x, row)
        )
        expect_identical(
            storage_threshold_row(output, row, 0),
            storage_threshold_row(x, row, 0)
        )
    }
    expect_identical(serialize(x, NULL), before)
})

test_that("10x failures remove only owned output and reject fractional counts", {
    standard_matrix_require()
    skip_if_not_installed("DropletUtils", "1.32.0")
    directory <- withr::local_tempdir()
    fixture <- tenx_test_fixture(directory)
    output <- file.path(directory, "output")
    dir.create(output)
    marker <- file.path(output, "keep.txt")
    writeLines("existing", marker)
    metadata <- fixture$inputs$grna_target_data_frame
    expect_error(
        suppressMessages(import_data_from_10x(
            fixture$path,
            "low",
            metadata,
            output,
            extra_covariates = data.frame(z = 1:2)
        )),
        "one row per cell"
    )
    expect_identical(list.files(output), "keep.txt")
    expect_identical(readLines(marker), "existing")
    x <- Matrix::sparseMatrix(
        i = c(1L, 2L),
        j = c(1L, 2L),
        x = c(1, .5),
        dims = c(2L, 2L),
        dimnames = list(c("g", "guide"), c("a", "b"))
    )
    bad <- file.path(directory, "fractional")
    DropletUtils::write10xCounts(
        bad,
        x,
        gene.type = c("Gene Expression", "CRISPR Guide Capture"),
        version = "3",
        type = "mtx"
    )
    expect_error(
        suppressMessages(import_data_from_10x(
            bad,
            "low",
            data.frame(grna_id = "guide", grna_target = "non-targeting"),
            output
        )),
        "integer UMI"
    )
    expect_identical(list.files(output), "keep.txt")
})

test_that("10x barcode-free batches retain unnamed cell axes", {
    standard_matrix_require()
    skip_if_not_installed("DropletUtils", "1.32.0")
    fixture <- tenx_test_fixture(withr::local_tempdir())
    unlink(list.files(fixture$path, pattern = "^barcodes", full.names = TRUE))
    metadata <- fixture$inputs$grna_target_data_frame
    actual <- suppressMessages(import_data_from_10x(
        rep(fixture$path, 2L),
        "low",
        metadata,
        withr::local_tempdir()
    ))
    expected <- suppressMessages(import_data_from_cellranger(
        rep(fixture$path, 2L),
        "low",
        metadata
    ))
    expect_null(colnames(get_response_matrix(actual)))
    tenx_expect_same_counts(get_response_matrix(actual), get_response_matrix(expected))
    expect_identical(get_cell_covariates(actual), get_cell_covariates(expected))
    expect_length(list.files(fixture$path, pattern = "^barcodes"), 0L)
})

test_that("MTX parsing retains stored zeros through the complete import", {
    standard_matrix_require()
    skip_if_not_installed("DropletUtils", "1.32.0")
    directory <- withr::local_tempdir()
    writeLines(
        c("g\tG\tGene Expression", "guide\tGuide\tCRISPR Guide Capture"),
        file.path(directory, "features.tsv")
    )
    writeLines(c("a", "b"), file.path(directory, "barcodes.tsv"))
    writeLines(
        c(
            "%%MatrixMarket matrix coordinate integer general",
            "2 2 3",
            "1 1 2",
            "2 1 5",
            "1 2 0"
        ),
        file.path(directory, "matrix.mtx")
    )
    metadata <- data.frame(grna_id = "guide", grna_target = "non-targeting")
    object <- suppressMessages(import_data_from_10x(
        directory,
        "low",
        metadata,
        withr::local_tempdir()
    ))
    expect_identical(
        storage_threshold_row(get_response_matrix(object), 1L, 0),
        1:2
    )
    expect_identical(
        storage_read_response(get_response_matrix(object), 1L),
        c(2, 0)
    )
})

test_that("10x-backed discovery exactly matches imported in-memory discovery", {
    standard_matrix_require()
    skip_if_not_installed("DropletUtils", "1.32.0")
    fixture <- tenx_test_fixture(withr::local_tempdir(), TRUE)
    input <- fixture$inputs
    expected <- import_data(
        input$response_matrix,
        input$low_grna_matrix,
        input$grna_target_data_frame,
        "low",
        response_names = fixture$symbols
    )
    actual <- suppressMessages(import_data_from_10x(
        fixture$path,
        "low",
        input$grna_target_data_frame,
        withr::local_tempdir()
    ))
    run <- function(object) {
        object <- set_analysis_parameters(
            object,
            discovery_pairs = input$discovery_pairs,
            formula_object = ~1,
            control_group = "complement",
            resampling_mechanism = "permutations"
        )
        object <- assign_grnas(
            object,
            method = "thresholding",
            threshold = 40,
            print_progress = FALSE
        )
        object <- run_qc(
            object,
            response_n_umis_range = c(0, 1),
            response_n_nonzero_range = c(0, 1),
            p_mito_threshold = 1,
            n_nonzero_trt_thresh = 7L,
            n_nonzero_cntrl_thresh = 7L
        )
        withr::with_seed(
            271828,
            run_discovery_analysis(
                object,
                parallel = FALSE,
                print_progress = FALSE
            )
        )
    }
    memory <- suppressMessages(run(expected))
    disk <- suppressMessages(run(actual))
    expect_identical(refactor_observe(disk), refactor_observe(memory))
})
