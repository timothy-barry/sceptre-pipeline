version_id_field <- function(object, name = "identity") {
    if (methods::is(object@data, "SingleCellExperiment")) {
        screen_test_field(object@data, name)
    } else methods::slot(object@data, name)
}
version_id_import <- function(inputs, cells = seq_len(ncol(inputs$response_matrix))) {
    suppressMessages(import_data(
        response_matrix = inputs$response_matrix[, cells, drop = FALSE],
        grna_matrix = inputs$high_grna_matrix[, cells, drop = FALSE],
        grna_target_data_frame = inputs$grna_target_data_frame,
        extra_covariates = inputs$extra_covariates[cells, , drop = FALSE], moi = "high"
    ))
}

test_that("new imports create independent opaque versions without scientific RNG", {
    inputs <- refactor_make_inputs()
    withr::local_seed(104)
    before <- .Random.seed; kind <- RNGkind()
    a <- version_id_import(inputs); b <- version_id_import(inputs)
    expect_match(version_id_field(a), "^dataset-v1-[a-f0-9]{32}$")
    expect_false(identical(version_id_field(a), version_id_field(b)))
    expect_identical(.Random.seed, before)
    expect_identical(RNGkind(), kind)
    expect_identical(get_response_matrix(a), get_response_matrix(b))
    expect_identical(get_cell_covariates(a), get_cell_covariates(b))
    rm(".Random.seed", envir = .GlobalEnv)
    # Existing covariate .Call wrappers can initialize an absent R seed.
    # The ID factory itself must not initialize or draw from it.
    c <- new_screen_version_id()
    expect_false(exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
    expect_match(c, "^dataset-v1-[a-f0-9]{32}$")
    assign(".Random.seed", before, envir = .GlobalEnv)
})

test_that("queries copies and populated persistence preserve version and fit reuse", {
    inputs <- refactor_make_inputs(); case <- refactor_case_definitions()$high_perm
    withr::local_seed(117)
    object <- refactor_capture(refactor_prepare(inputs, case))$value
    object <- refactor_capture(run_discovery_analysis(object, print_progress = FALSE, output_amount = 2L))$value
    id <- version_id_field(object); fits <- object@fits; rng <- .Random.seed
    status <- workflow_status(object)
    expect_true(status[["run_discovery_analysis"]])
    copy <- object
    get_cell_covariates(copy); workflow_status(copy)
    expect_identical(version_id_field(copy), id)
    path <- withr::local_tempfile(fileext = ".rds")
    write_sceptre_object(object, path)
    reopened <- read_sceptre_object(path)
    expect_identical(version_id_field(reopened), id)
    expect_identical(reopened@fits, fits)
    expect_identical(workflow_status(reopened), status)
    expect_identical(refactor_plain(get_result(reopened, "run_discovery_analysis")),
                     refactor_plain(get_result(object, "run_discovery_analysis")))
    expect_identical(.Random.seed, rng)
})

test_that("supported replacements renew and invalidate while failed or no-op replacements preserve", {
    inputs <- refactor_make_inputs(); case <- refactor_case_definitions()$high_perm
    withr::local_seed(118)
    object <- refactor_capture(refactor_prepare(inputs, case))$value
    object <- refactor_capture(run_discovery_analysis(object, print_progress = FALSE, output_amount = 2L))$value
    id <- version_id_field(object); fits <- object@fits; rng <- .Random.seed
    same <- set_response_matrix(object, get_response_matrix(object))
    expect_identical(version_id_field(same), id)
    expect_identical(same@fits, fits)
    expect_error(set_response_matrix(object, get_response_matrix(object)[, ncol(inputs$response_matrix):1L, drop = FALSE]), "preserve aligned")
    expect_identical(version_id_field(object), id)
    expect_identical(object@fits, fits)
    response <- as.matrix(get_response_matrix(object)); response[1L, 1L] <- response[1L, 1L] + 1
    changed <- set_response_matrix(object, response)
    expect_false(identical(version_id_field(changed), id))
    expect_identical(unname(get_cell_covariates(changed)$response_n_umis), unname(colSums(response)))
    expect_length(changed@fits@response_fits, 0L)
    expect_length(changed@fits@perturbation_fits, 0L)
    expect_true(workflow_status(changed)[["import_data"]])
    expect_false(any(workflow_status(changed)[setdiff(names(workflow_status(changed)), "import_data")]))
    expect_error(get_result(changed, "run_discovery_analysis"))
    guide <- as.matrix(get_grna_matrix(object)); guide[1L, 1L] <- guide[1L, 1L] + 1
    changed_guide <- set_grna_matrix(object, guide)
    expect_false(identical(version_id_field(changed_guide), id))
    expect_identical(unname(get_cell_covariates(changed_guide)$grna_n_umis), unname(colSums(guide)))
    expect_true(workflow_status(changed_guide)[["import_data"]])
    expect_false(any(workflow_status(changed_guide)[setdiff(names(workflow_status(changed_guide)), "import_data")]))
    expect_identical(.Random.seed, rng)
    # Cell/feature identity changes require a fresh public import, not setter surgery.
    subset <- version_id_import(inputs, seq_len(80L))
    expect_false(identical(version_id_field(subset), id))
    expect_identical(ncol(get_response_matrix(subset)), 80L)
    expect_identical(.Random.seed, rng)
})

test_that("valid old schema-three IDs remain stable and oldest conversion gets a persisted version", {
    path <- test_path("fixtures", "saved-objects", "sceptre-schema3-list-plans-2a0938e.rds")
    physical <- readRDS(path)
    old_id <- attributes(attributes(physical)$data)$identity
    expect_true(length(old_id) == 1L && nzchar(old_id))
    old_bytes <- serialize(physical, NULL)
    restored <- read_sceptre_object(path)
    expect_identical(version_id_field(restored), old_id)
    expect_identical(serialize(physical, NULL), old_bytes)
    saved <- withr::local_tempfile(fileext = ".rds")
    write_sceptre_object(restored, saved)
    expect_identical(version_id_field(read_sceptre_object(saved)), old_id)
    for (name in c("sceptre-0.99.0-21f9ea0.rds", "sceptre-schema2-4aad80b.rds")) {
        legacy <- readRDS(test_path("fixtures", "saved-objects", name))
        a <- migrate_sceptre_object(legacy); b <- migrate_sceptre_object(legacy)
        expect_false(identical(version_id_field(a), version_id_field(b)))
        expect_identical(version_id_field(migrate_sceptre_object(a)), version_id_field(a))
        write_sceptre_object(a, saved)
        expect_identical(version_id_field(read_sceptre_object(saved)), version_id_field(a))
    }
})

test_that("version renewal makes no large RAM-count serialization allocation", {
    skip_if_not(capabilities("profmem"))
    cells <- paste0("c", seq_len(200L)); ids <- paste0("f", seq_len(1000L))
    counts <- Matrix::sparseMatrix(i = rep(seq_len(1000L), 200L),
        j = rep(seq_len(200L), each = 1000L), x = 1, dims = c(1000L, 200L),
        dimnames = list(ids, cells), repr = "R")
    meta <- data.frame(grna_id = ids, grna_target = c(rep("T", 996L), rep("non-targeting", 4L)))
    object <- suppressMessages(import_data(DelayedArray::DelayedArray(counts),
        DelayedArray::DelayedArray(counts), meta, "high"))
    rng <- if (exists(".Random.seed", envir = .GlobalEnv)) .Random.seed else NULL
    path <- withr::local_tempfile(); gc()
    Rprofmem(path, threshold = 1000000)
    renewed <- initialize_screen_identity(object)
    Rprofmem(NULL)
    expect_length(readLines(path)[grepl("^[0-9]+ ", readLines(path))], 0L)
    expect_false(identical(version_id_field(renewed), version_id_field(object)))
    expect_identical(get_response_matrix(renewed), get_response_matrix(object))
    expect_identical(if (exists(".Random.seed", envir = .GlobalEnv)) .Random.seed else NULL, rng)
})
