test_that("standard sparse rows retain values, order, repeats and stored zeros", {
    standard_matrix_require()
    directory <- tempfile("standard-rows-")
    on.exit(unlink(directory, recursive = TRUE), add = TRUE)
    matrix <- standard_matrix_integer_input()
    for (layout in c("row", "column")) {
        backed <- standard_matrix_fixture(
            matrix,
            directory,
            layout,
            layout,
            TRUE
        )
        expect_true(storage_is_standard_matrix(backed))
        expect_identical(storage_response_index(backed, "r2"), 2L)
        for (row in seq_len(nrow(matrix))) {
            for (cells in list(NULL, c(11L, 4L, 11L, 8L, 1L), 8L, integer())) {
                expect_identical(
                    storage_read_response(backed, row, cells),
                    storage_read_response(matrix, row, cells),
                    info = layout
                )
            }
            for (threshold in c(-1, 0, 1, 2.8, Inf)) {
                expect_identical(
                    storage_threshold_row(backed, row, threshold),
                    storage_threshold_row(matrix, row, threshold),
                    info = paste(layout, threshold)
                )
            }
        }
    }
})

test_that("dense standard counts sparsify zeros consistently at every boundary", {
    standard_matrix_require()
    directory <- tempfile("standard-dense-")
    dir.create(directory)
    on.exit(unlink(directory, recursive = TRUE), add = TRUE)
    dense <- as.matrix(standard_matrix_integer_input())
    memory <- set_matrix_accessibility(dense, TRUE)
    disk <- HDF5Array::writeHDF5Array(
        dense,
        filepath = file.path(directory, "dense.h5"),
        name = "counts"
    )
    dimnames(disk) <- dimnames(dense)
    wrapped <- DelayedArray::DelayedArray(dense)
    cells <- c(1L, 2L, 4L, 5L, 8L, 11L, 12L)
    groups <- list(c(1L, 3L, 5L), c(2L, 4L, 7L))
    nt <- list(c(1L, 4L, 5L), c(2L, 3L, 6L, 7L))
    pairs <- data.frame(
        response_idx = c(2L, 1L, 1L, 2L),
        group_idx = c(2L, 1L, 2L, 1L)
    )
    metadata <- data.frame(
        grna_id = rownames(dense),
        grna_target = c("A", "non-targeting")
    )
    reference <- sceptre::import_data(dense, dense, metadata, "high")
    for (store in list(wrapped, disk)) {
        for (row in seq_len(nrow(memory))) {
            expect_identical(
                storage_read_response(store, row, rev(cells)),
                storage_read_response(memory, row, rev(cells))
            )
            for (threshold in c(-1, 0, 2.8, Inf)) {
                expect_identical(
                    storage_threshold_row(store, row, threshold),
                    storage_threshold_row(memory, row, threshold)
                )
            }
        }
        expect_identical(
            storage_group_counts(store, c(2L, 1L, 2L), groups, cells),
            storage_group_counts(memory, c(2L, 1L, 2L), groups, cells)
        )
        for (controls in list("complement", seq_along(cells))) {
            expect_identical(
                storage_pair_counts(store, pairs, groups, cells, controls, nt),
                storage_pair_counts(memory, pairs, groups, cells, controls, nt)
            )
        }
        imported <- sceptre::import_data(store, store, metadata, "high")
        expect_identical(
            sceptre:::screen_cell_covariates(imported@data),
            sceptre:::screen_cell_covariates(reference@data)
        )
        expect_true(storage_is_standard_matrix(get_response_matrix(imported)))
    }
})

test_that("standard native support rejects delayed count arithmetic explicitly", {
    standard_matrix_require()
    matrix <- Matrix::sparseMatrix(
        i = c(1L, 2L),
        j = c(1L, 2L),
        x = c(1, 2),
        dims = c(2L, 3L)
    )
    wrapped <- DelayedArray::DelayedArray(matrix)
    expect_error(
        storage_prepare_standard_matrix(log1p(wrapped)),
        "raw-count|unsupported|native"
    )
    expect_error(
        storage_prepare_standard_matrix(wrapped + 1),
        "raw-count|unsupported|native"
    )
})

test_that("standard imports require finite nonnegative integer UMI counts", {
    standard_matrix_require()
    directory <- tempfile("standard-count-policy-")
    on.exit(unlink(directory, recursive = TRUE), add = TRUE)
    valid <- methods::as(standard_matrix_integer_input(), "CsparseMatrix")
    guides <- standard_matrix_fixture(valid, directory, "valid-guides")
    metadata <- data.frame(
        grna_id = rownames(valid),
        grna_target = c("A", "non-targeting")
    )
    invalid_values <- c(.25, -1, NA_real_, NaN, Inf, -Inf)
    for (i in seq_along(invalid_values)) {
        invalid <- valid
        invalid@x[1L] <- invalid_values[[i]]
        wrapped <- DelayedArray::DelayedArray(invalid)
        disk <- standard_matrix_fixture(
            invalid,
            directory,
            paste0("invalid-", i),
            preserve_stored_zeros = TRUE
        )
        for (store in list(wrapped, disk)) {
            expect_error(
                storage_prepare_standard_matrix(store),
                "finite|integer|UMI"
            )
            expect_error(
                sceptre::import_data(store, guides, metadata, "high"),
                "finite|integer|UMI"
            )
        }
    }
})

test_that("standard sparse QC preserves pair/group identities and borrowed indices", {
    standard_matrix_require()
    directory <- tempfile("standard-qc-")
    on.exit(unlink(directory, recursive = TRUE), add = TRUE)
    matrix <- standard_matrix_integer_input()
    cells <- c(2L, 4L, 5L, 8L, 11L)
    groups <- list(A = c(2L, 3L), B = c(4L, 1L, 5L), empty = integer())
    nt <- list(nt1 = 4L, nt2 = c(1L, 5L), overlap = c(4L, 5L))
    pairs <- data.frame(
        response_idx = c(2L, 1L, 2L, 1L),
        group_idx = c(2L, 1L, 1L, 1L)
    )
    before <- serialize(list(cells, groups, nt, pairs), NULL)
    for (layout in c("row", "column")) {
        backed <- standard_matrix_fixture(
            matrix,
            directory,
            layout,
            layout,
            TRUE
        )
        for (controls in list("complement", c(4L, 1L, 5L))) {
            for (summary in list(NULL, nt)) {
                for (nuclear in c(FALSE, TRUE)) {
                    expect_identical(
                        storage_pair_counts(
                            backed,
                            pairs,
                            groups,
                            cells,
                            controls,
                            summary,
                            nuclear
                        ),
                        storage_pair_counts(
                            matrix,
                            pairs,
                            groups,
                            cells,
                            controls,
                            summary,
                            nuclear
                        ),
                        info = paste(layout, nuclear)
                    )
                }
                expect_identical(
                    storage_pair_counts(
                        backed,
                        pairs[integer(), ],
                        groups,
                        cells,
                        controls,
                        summary
                    ),
                    storage_pair_counts(
                        matrix,
                        pairs[integer(), ],
                        groups,
                        cells,
                        controls,
                        summary
                    )
                )
            }
        }
        for (features in list(c(2L, 1L, 2L), 1L, integer())) {
            for (memberships in list(groups, groups[1L], list())) {
                expect_identical(
                    storage_group_counts(backed, features, memberships, cells),
                    storage_group_counts(matrix, features, memberships, cells)
                )
            }
        }
        reordered <- cells[c(4L, 1L, 5L, 2L, 3L)]
        remapped <- lapply(groups, function(x) match(cells[x], reordered))
        expect_identical(
            storage_pair_counts(
                backed,
                pairs,
                remapped,
                reordered,
                "complement"
            ),
            storage_pair_counts(matrix, pairs, groups, cells, "complement")
        )
        repeated_cells <- c(cells, 4L)
        repeated_groups <- list(c(2L, 3L, 6L), c(6L, 4L))
        repeated_nt <- list(c(2L, 6L), c(4L, 6L))
        for (controls in list("complement", c(2L, 4L, 6L))) {
            expect_identical(
                storage_pair_counts(
                    backed,
                    pairs,
                    repeated_groups,
                    repeated_cells,
                    controls,
                    repeated_nt
                ),
                storage_pair_counts(
                    matrix,
                    pairs,
                    repeated_groups,
                    repeated_cells,
                    controls,
                    repeated_nt
                )
            )
        }
        expect_identical(
            storage_group_counts(
                backed,
                c(2L, 1L, 2L),
                repeated_groups,
                repeated_cells
            ),
            storage_group_counts(
                matrix,
                c(2L, 1L, 2L),
                repeated_groups,
                repeated_cells
            )
        )
    }
    expect_identical(serialize(list(cells, groups, nt, pairs), NULL), before)
})

test_that("standard column summaries preserve full-library definitions exactly", {
    standard_matrix_require()
    directory <- tempfile("standard-covariates-")
    on.exit(unlink(directory, recursive = TRUE), add = TRUE)
    matrix <- standard_matrix_covariate_input()
    before <- serialize(matrix, NULL)
    for (layout in c("row", "column")) {
        backed <- standard_matrix_fixture(
            matrix,
            directory,
            layout,
            layout,
            TRUE
        )
        for (mito in c(FALSE, TRUE)) {
            for (maximum in c(FALSE, TRUE)) {
                expect_identical(
                    storage_cell_covariates(backed, c(1L, 3L), mito, maximum),
                    storage_cell_covariates(matrix, c(1L, 3L), mito, maximum)
                )
            }
        }
        # Mitochondrial row order/repeats affect the legacy sum; it is not a set.
        expect_identical(
            storage_cell_covariates(backed, c(3L, 1L, 1L), TRUE, TRUE),
            storage_cell_covariates(matrix, c(3L, 1L, 1L), TRUE, TRUE)
        )
    }
    expect_identical(serialize(matrix, NULL), before)
})

test_that("standard backed import retains counts and aligns cell covariates", {
    standard_matrix_require()
    directory <- tempfile("standard-import-")
    on.exit(unlink(directory, recursive = TRUE), add = TRUE)
    inputs <- refactor_make_inputs()
    response <- standard_matrix_fixture(
        inputs$response_matrix,
        directory,
        "response"
    )
    guides <- standard_matrix_fixture(
        inputs$low_grna_matrix,
        directory,
        "guides"
    )
    object <- sceptre::import_data(
        response,
        guides,
        inputs$grna_target_data_frame,
        "low",
        extra_covariates = inputs$extra_covariates
    )
    memory <- refactor_import(
        inputs,
        refactor_case_definitions()$low_complement_perm
    )
    expect_true(storage_is_standard_matrix(get_response_matrix(object)))
    expect_true(storage_is_standard_matrix(get_grna_matrix(object)))
    expect_identical(sceptre:::screen_cell_covariates(object@data), sceptre:::screen_cell_covariates(memory@data))
    expect_identical(rownames(sceptre:::screen_cell_covariates(object@data)), colnames(response))
    wrong <- guides[, rev(seq_len(ncol(guides))), drop = FALSE]
    expect_error(
        sceptre::import_data(
            response,
            wrong,
            inputs$grna_target_data_frame,
            "low",
            extra_covariates = inputs$extra_covariates
        ),
        "identical|same|order|match"
    )
})

test_that("standard vector aggregation precedes guide covariates and preserves integer counts", {
    standard_matrix_require()
    inputs <- refactor_make_inputs()
    inputs$grna_target_data_frame$vector_id <- c(
        "avec",
        "avec",
        "avec",
        "bvec",
        "nt1v",
        "nt2v",
        "nt3v",
        "nt4v"
    )
    inputs$grna_target_data_frame$grna_target[3L] <- "A"
    directory <- tempfile("standard-vectors-")
    on.exit(unlink(directory, recursive = TRUE), add = TRUE)
    guides <- inputs$high_grna_matrix
    response <- standard_matrix_fixture(
        inputs$response_matrix,
        directory,
        "response"
    )
    backed <- standard_matrix_fixture(guides, directory, "guides")
    expect_error(
        sceptre::import_data(
            response,
            backed,
            inputs$grna_target_data_frame,
            "high",
            extra_covariates = inputs$extra_covariates
        ),
        "directory_to_write"
    )
    actual <- sceptre::import_data(
        response,
        backed,
        inputs$grna_target_data_frame,
        "high",
        extra_covariates = inputs$extra_covariates,
        directory_to_write = file.path(directory, "aggregated")
    )
    expected <- sceptre::import_data(
        inputs$response_matrix,
        guides,
        inputs$grna_target_data_frame,
        "high",
        extra_covariates = inputs$extra_covariates
    )
    expect_true(storage_is_standard_matrix(get_grna_matrix(actual)))
    expect_identical(
        sceptre:::screen_guide_annotations(actual@data),
        sceptre:::screen_guide_annotations(expected@data)
    )
    expect_identical(sceptre:::screen_cell_covariates(actual@data), sceptre:::screen_cell_covariates(expected@data))
    for (row in seq_len(nrow(get_grna_matrix(expected)))) {
        expect_identical(
            storage_read_response(get_grna_matrix(actual), row),
            storage_read_response(get_grna_matrix(expected), row)
        )
    }
    fractional <- guides
    fractional[1L, 1L] <- .25
    invalid <- standard_matrix_fixture(
        fractional,
        directory,
        "fractional-guides"
    )
    expect_error(
        sceptre::import_data(
            response,
            invalid,
            inputs$grna_target_data_frame,
            "high",
            extra_covariates = inputs$extra_covariates,
            directory_to_write = file.path(directory, "invalid-aggregate")
        ),
        "integer|UMI"
    )
})

test_that("failed backed vector aggregation removes only its partial new file", {
    standard_matrix_require()
    directory <- tempfile("standard-vector-failure-")
    on.exit(unlink(directory, recursive = TRUE), add = TRUE)
    inputs <- refactor_make_inputs()
    metadata <- inputs$grna_target_data_frame
    metadata$vector_id <- rep(paste0("v", seq_len(4L)), each = 2L)
    guides <- standard_matrix_fixture(
        inputs$high_grna_matrix,
        directory,
        "guides"
    )
    source_path <- DelayedArray::seed(guides)@filepath
    original_bytes <- readBin(
        source_path,
        "raw",
        n = file.info(source_path)$size
    )
    output <- file.path(directory, "aggregated")
    dir.create(output)
    preserved <- file.path(output, "keep.txt")
    writeLines("preserve unrelated work", preserved)
    call <- storage_standard_call
    calls <- 0L
    testthat::local_mocked_bindings(
        storage_standard_call = function(matrix_in, FUN, ...) {
            calls <<- calls + 1L
            if (calls == 2L) {
                stop("injected second-vector failure")
            }
            call(matrix_in, FUN, ...)
        },
        .package = "sceptre"
    )
    expect_error(
        collapse_standard_grna_matrix(guides, metadata, output),
        "injected second-vector failure",
        fixed = TRUE
    )
    expect_identical(calls, 2L)
    expect_identical(list.files(output), "keep.txt")
    expect_identical(readLines(preserved), "preserve unrelated work")
    expect_identical(
        readBin(source_path, "raw", n = file.info(source_path)$size),
        original_bytes
    )
})

test_that("all existing guide assignment methods preserve standard-backend outputs", {
    standard_matrix_require()
    directory <- tempfile("standard-assignment-")
    on.exit(unlink(directory, recursive = TRUE), add = TRUE)
    inputs <- refactor_make_inputs()
    response <- standard_matrix_fixture(
        inputs$response_matrix,
        directory,
        "response"
    )
    guides <- standard_matrix_fixture(
        inputs$low_grna_matrix,
        directory,
        "guides"
    )
    prepare <- function(response, guides) {
        object <- sceptre::import_data(
            response,
            guides,
            inputs$grna_target_data_frame,
            "low",
            extra_covariates = inputs$extra_covariates
        )
        sceptre::set_analysis_parameters(
            object,
            discovery_pairs = inputs$discovery_pairs,
            positive_control_pairs = inputs$positive_control_pairs,
            formula_object = stats::as.formula("~ batch + z", env = baseenv()),
            resampling_mechanism = "permutations"
        )
    }
    backed <- prepare(response, guides)
    memory <- prepare(inputs$response_matrix, inputs$low_grna_matrix)
    run <- function(object, method) {
        withr::with_seed(
            713L,
            refactor_capture({
                arguments <- list(
                    sceptre_object = object,
                    method = method,
                    print_progress = FALSE
                )
                if (method == "mixture") {
                    arguments$n_em_rep <- 1L
                    arguments$n_nonzero_cells_cutoff <- 1L
                    arguments$formula_object <- stats::as.formula(
                        "~ 1",
                        env = baseenv()
                    )
                }
                object <- do.call(sceptre::assign_grnas, arguments)
                list(
                    fields = list(
                        object@preparation@guide_assignments,
                        object@preparation@source_groups,
                        object@spec@grna_assignment_method,
                        object@spec@grna_assignment_hyperparameters,
                        object@preparation@guide_counts_per_cell,
                        object@preparation@assignment_exclusions
                    ),
                    rng_after = get(".Random.seed", envir = .GlobalEnv)
                )
            })
        )
    }
    for (method in c("thresholding", "maximum", "mixture")) {
        expect_identical(
            run(backed, method),
            run(memory, method),
            info = method
        )
    }
})

test_that("standard backend complete workflows exactly match in-memory inference", {
    standard_matrix_require()
    inputs <- refactor_make_inputs()
    cases <- refactor_case_definitions()
    selected <- c("low_nt_perm", "low_complement_perm", "high_complement_crt")
    for (name in selected) {
        directory <- tempfile(paste0("standard-workflow-", name, "-"))
        on.exit(unlink(directory, recursive = TRUE), add = TRUE)
        actual <- standard_matrix_run_case(inputs, cases[[name]], directory)
        expected <- refactor_run_case(inputs, cases[[name]])
        expect_identical(actual, expected, info = name)
        expect_workflow_results(actual, inputs, cases[[name]])
    }
})

test_that("standard file-backed reads reopen after serialization in another process", {
    standard_matrix_require()
    directory <- tempfile("standard-reopen-")
    dir.create(directory)
    on.exit(unlink(directory, recursive = TRUE), add = TRUE)
    matrix <- standard_matrix_integer_input()
    backed <- standard_matrix_fixture(matrix, directory, "counts", "row", TRUE)
    descriptor <- file.path(directory, "matrix.rds")
    suppressWarnings(saveRDS(backed, descriptor))
    object <- sceptre::import_data(
        backed,
        backed,
        data.frame(
            grna_id = rownames(backed),
            grna_target = c("A", "non-targeting")
        ),
        "high"
    )
    object_path <- file.path(directory, "object.rds")
    suppressWarnings(saveRDS(object, object_path))
    result <- file.path(directory, "result.rds")
    script <- file.path(directory, "child.R")
    writeLines(
        c(
            paste0(
                ".libPaths(",
                paste(deparse(.libPaths()), collapse = ""),
                ")"
            ),
            "suppressPackageStartupMessages(library(sceptre))",
            paste0("x <- readRDS(", deparse(descriptor), ")"),
            paste0("object <- readRDS(", deparse(object_path), ")"),
            "read <- getFromNamespace('storage_read_response', 'sceptre')",
            "get_counts <- getFromNamespace('get_response_matrix', 'sceptre')",
            paste0(
                "saveRDS(list(matrix = read(x, 1L, c(11L,4L,11L,8L,1L)), ",
                "object = read(get_counts(object), 1L, c(11L,4L,11L,8L,1L)), ",
                "covariates = sceptre:::screen_cell_covariates(object@data)), ",
                deparse(result),
                ")"
            )
        ),
        script
    )
    output <- system2(
        file.path(R.home("bin"), "Rscript"),
        shQuote(script),
        stdout = TRUE,
        stderr = TRUE
    )
    status <- attr(output, "status")
    expect_true(
        is.null(status) || identical(status, 0L),
        info = paste(output, collapse = "\n")
    )
    expect_true(file.exists(result))
    if (file.exists(result)) {
        expected <- storage_read_response(matrix, 1L, c(11L, 4L, 11L, 8L, 1L))
        actual <- readRDS(result)
        expect_identical(actual$matrix, expected)
        expect_identical(actual$object, expected)
        expect_identical(actual$covariates, sceptre:::screen_cell_covariates(object@data))
    }
})

test_that("two-worker standard inference preserves results and independent handles", {
    standard_matrix_require()
    skip_on_os("windows")
    inputs <- refactor_make_inputs()
    case <- refactor_case_definitions()$high_complement_crt
    directories <- c(
        tempfile("standard-serial-"),
        tempfile("standard-workers-")
    )
    on.exit(unlink(directories, recursive = TRUE), add = TRUE)
    serial <- standard_matrix_sort_fit_cache(
        standard_matrix_run_case(inputs, case, directories[1L])
    )
    workers <- standard_matrix_sort_fit_cache(
        standard_matrix_run_case(inputs, case, directories[2L], parallel = TRUE)
    )
    expect_identical(workers, serial)
})
