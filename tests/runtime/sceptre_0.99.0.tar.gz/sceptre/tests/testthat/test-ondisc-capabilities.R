test_that("native matrix admission does not load the retired optional backend", {
    standard_matrix_require()
    was_loaded <- "ondisc" %in% loadedNamespaces()
    counts <- Matrix::sparseMatrix(
        i = 1L,
        j = 1L,
        x = 2,
        dims = c(1L, 2L),
        repr = "R"
    )
    native <- as_count_matrix(counts)
    expect_s4_class(native, "DelayedMatrix")
    expect_identical(DelayedArray::seed(native), counts)
    expect_identical(require_count_matrix(native), native)
    expect_identical(storage_read_response(native, 1L), c(2, 0))
    expect_identical("ondisc" %in% loadedNamespaces(), was_loaded)
    expect_false(exists(
        "require_ondisc_capabilities",
        envir = asNamespace("sceptre"),
        inherits = FALSE
    ))
})

test_that("unsupported native views fail before counts are evaluated", {
    standard_matrix_require()
    counts <- as_count_matrix(standard_matrix_integer_input())
    expect_error(storage_prepare_standard_matrix(counts + 1))
    expect_error(as_count_matrix(list()), "Count matrices must be")
    expect_error(
        as_count_matrix(NULL, list(path = "retired.odm")),
        "explicit conversion or reimport"
    )
    expect_identical(
        storage_read_response(counts, 2L),
        c(0, 2, 0, 0, 1, 0, 0, 0, 0, 0, 0, 8)
    )
})
