test_that("native 10x blocks preserve canonical coordinates and stored zeros", {
    standard_matrix_require()
    counts <- standard_matrix_integer_input()
    before <- serialize(counts, NULL)
    for (store in list(
        DelayedArray::DelayedArray(counts),
        DelayedArray::DelayedArray(methods::as(counts, "CsparseMatrix"))
    )) {
        handle <- storage_standard_handle(store)
        for (selection in list(c(1L, 2L), c(2L, 1L))) {
            rows <- seq.int(selection[1L], length.out = selection[2L])
            reference <- as.data.frame(summary(t(counts[rows, , drop = FALSE])))
            reference <- reference[
                order(reference$j, reference$i),
                ,
                drop = FALSE
            ]
            expect_identical(
                tenx_import_block_cpp(handle, selection[1L], selection[2L]),
                list(
                    value = as.numeric(reference$x),
                    cell = as.integer(reference$i),
                    feature = as.integer(reference$j)
                )
            )
        }
        standard_matrix_release_cpp(handle)
        expect_error(tenx_import_block_cpp(handle, 1L, 1L), "closed")
    }
    expect_identical(serialize(counts, NULL), before)
})

test_that("10x block conversion rejects other pointer kinds and unwinds native errors", {
    standard_matrix_require()
    counts <- standard_matrix_integer_input()
    handle <- storage_standard_handle(DelayedArray::DelayedArray(counts))
    on.exit(standard_matrix_release_cpp(handle), add = TRUE)
    response <- standard_matrix_open_response_reader_cpp(handle)
    on.exit(standard_matrix_close_response_reader_cpp(response), add = TRUE)
    threshold <- standard_matrix_open_threshold_reader_cpp(handle)
    on.exit(standard_matrix_close_threshold_reader_cpp(threshold), add = TRUE)
    expect_error(
        tenx_import_block_cpp(response, 1L, 1L),
        "prepared response reader"
    )
    expect_error(
        tenx_import_block_cpp(threshold, 1L, 1L),
        "prepared threshold reader"
    )
    expect_error(tenx_import_block_cpp(1L, 1L, 1L), "not an external pointer")
    expect_error(tenx_import_block_cpp(new("externalptr"), 1L, 1L), "closed")
    for (block in list(c(0L, 1L), c(1L, 0L), c(2L, 2L))) {
        expect_error(
            tenx_import_block_cpp(handle, block[1L], block[2L]),
            "Invalid 10x"
        )
    }
    counts@x[2L] <- 0.5
    invalid <- storage_standard_handle(DelayedArray::DelayedArray(counts))
    on.exit(standard_matrix_release_cpp(invalid), add = TRUE)
    for (i in seq_len(10L)) {
        expect_error(tenx_import_block_cpp(invalid, 1L, 2L), "integer UMI")
    }
    expect_identical(tenx_import_block_cpp(handle, 2L, 1L)$value, c(2, 1, 0, 8))
})

test_that("single and multiple part writers preserve exact axes and memberships", {
    standard_matrix_require()
    counts <- standard_matrix_integer_input()
    colnames(counts) <- paste0("cell", seq_len(ncol(counts)))
    parts <- list(
        counts[, c(1L, 4L, 8L), drop = FALSE],
        counts[, c(2L, 5L, 12L, 11L), drop = FALSE]
    )
    for (input in list(list(counts), parts)) {
        expected <- methods::as(do.call(cbind, input), "RsparseMatrix")
        snapshot <- lapply(input, serialize, connection = NULL)
        for (block_rows in c(1L, 3L)) {
            for (level in list(NULL, 3L)) {
                actual <- tenx_write_feature_major(
                    lapply(input, DelayedArray::DelayedArray),
                    file.path(withr::local_tempdir(), "counts.h5"),
                    block_rows,
                    level = level
                )
                expect_identical(dimnames(actual), dimnames(expected))
                expect_identical(as.matrix(actual), as.matrix(expected))
                for (row in seq_len(nrow(expected))) {
                    expect_identical(
                        storage_threshold_row(actual, row, 0),
                        storage_threshold_row(expected, row, 0)
                    )
                }
            }
        }
        expect_identical(lapply(input, serialize, connection = NULL), snapshot)
    }
})

test_that("failed 10x block writes release inputs before removing only owned output", {
    standard_matrix_require()
    skip_if_not_installed("DropletUtils", "1.32.0")
    source <- withr::local_tempdir()
    writeLines(
        c(
            "r1\tMT-first\tGene Expression",
            "r2\tsecond\tGene Expression",
            "g1\tguide1\tCRISPR Guide Capture",
            "g2\tguide2\tCRISPR Guide Capture"
        ),
        file.path(source, "features.tsv")
    )
    writeLines(c("a", "b", "c"), file.path(source, "barcodes.tsv"))
    writeLines(
        c(
            "%%MatrixMarket matrix coordinate integer general",
            "4 3 4",
            "1 1 2",
            "2 2 3",
            "3 1 4",
            "4 3 5"
        ),
        file.path(source, "matrix.mtx")
    )
    metadata <- data.frame(
        grna_id = c("g1", "g2"),
        grna_target = c("A", "non-targeting")
    )
    original_files <- list.files(source, full.names = TRUE)
    original_hashes <- tools::md5sum(original_files)
    output <- withr::local_tempdir()
    writeLines("preserve", file.path(output, "keep.txt"))
    consume <- tenx_import_block_cpp
    seen <- list()
    testthat::local_mocked_bindings(
        # Force the bounded path: this regression specifically exercises a
        # native handle that is already live when a later block write fails.
        tenx_whole_writer_supported = function(...) FALSE,
        tenx_import_block_cpp = function(handle, start, length) {
            seen[[length(seen) + 1L]] <<- handle
            if (length(seen) == 2L) {
                stop("injected second-block failure")
            }
            consume(handle, start, length)
        },
        .package = "sceptre"
    )
    expect_error(
        suppressMessages(import_data_from_10x(
            source,
            "low",
            metadata,
            output,
            block_rows = 1L
        )),
        "injected second-block failure"
    )
    expect_identical(list.files(output), "keep.txt")
    expect_identical(readLines(file.path(output, "keep.txt")), "preserve")
    expect_identical(tools::md5sum(original_files), original_hashes)
    expect_length(seen, 2L)
    for (handle in seen) {
        expect_error(consume(handle, 1L, 1L), "closed")
    }
})


test_that("maintained 10x writer failures remove only newly owned files", {
    standard_matrix_require()
    skip_if_not_installed("DropletUtils", "1.32.0")
    source <- withr::local_tempdir()
    writeLines(c("r\tMT-first\tGene Expression", "g\tGuide\tCRISPR Guide Capture"),
               file.path(source, "features.tsv"))
    writeLines(c("a", "b"), file.path(source, "barcodes.tsv"))
    writeLines(c("%%MatrixMarket matrix coordinate integer general", "2 2 3",
                 "1 1 2", "1 2 0", "2 1 5"), file.path(source, "matrix.mtx"))
    source_files <- list.files(source, full.names = TRUE)
    source_hashes <- tools::md5sum(source_files)
    output <- withr::local_tempdir()
    writeLines("preserve", file.path(output, "keep.txt"))
    testthat::local_mocked_bindings(writeTENxMatrix = function(x, filepath, ...) {
        writeLines("partial newly owned output", filepath)
        stop("injected maintained writer failure")
    }, .package = "HDF5Array")
    expect_error(suppressMessages(import_data_from_10x(source, "low",
        data.frame(grna_id = "g", grna_target = "non-targeting"), output)),
        "injected maintained writer failure")
    expect_identical(list.files(output), "keep.txt")
    expect_identical(readLines(file.path(output, "keep.txt")), "preserve")
    expect_identical(tools::md5sum(source_files), source_hashes)
})
