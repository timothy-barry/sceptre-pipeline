sce_collision_inputs <- function() {
    inputs <- refactor_make_inputs()
    n <- ncol(inputs$response_matrix)
    extra <- data.frame(
        first = seq_len(n),
        second = seq_len(n) + 0.25,
        third = seq_len(n) + 0.5,
        fourth = rep(c(1L, 2L), length.out = n),
        row.names = colnames(inputs$response_matrix),
        check.names = FALSE
    )
    names(extra) <- c(
        '.sceptre_max_grna',
        '.sceptre_max_grna_frac_umis',
        '.sceptre_covariate_rowname',
        '.sceptre_max_grna.1'
    )
    metadata <- inputs$grna_target_data_frame[c(7L, 2L, 5L, 1L), , drop = FALSE]
    metadata[['.sceptre_annotation_order']] <- seq_len(nrow(metadata)) + 100L
    metadata[['.sceptre_legacy_rowname']] <- factor(
        c('b', 'a', 'b', 'a'),
        levels = c('b', 'a')
    )
    metadata[['.sceptre_annotation_order.1']] <- letters[seq_len(nrow(
        metadata
    ))]
    metadata[['.sceptre_legacy_rowname.1']] <- seq_len(nrow(metadata)) + 200L
    rownames(metadata) <- paste0('annotation-', seq_len(nrow(metadata)))
    list(inputs = inputs, extra = extra, metadata = metadata)
}

sce_collision_import <- function(x) {
    suppressMessages(import_data(
        x$inputs$response_matrix,
        x$inputs$high_grna_matrix,
        x$metadata,
        'high',
        extra_covariates = x$extra
    ))
}


test_that("native metadata retains user fields without reserving legacy names", {
    x <- sce_collision_inputs()
    before <- serialize(x, NULL)
    object <- sce_collision_import(x)
    covariates <- get_cell_covariates(object)
    expect_identical(covariates[, names(x$extra), drop = FALSE], x$extra)
    annotation <- screen_guide_annotations(object@data)
    expect_s4_class(annotation, "DataFrame")
    for (name in names(x$metadata)) expect_identical(annotation[[name]], x$metadata[[name]])
    expect_null(screen_meta(object@data)$guide_summary_columns)
    expect_identical(names(SummarizedExperiment::colData(screen_guides(object@data))),
        c("max_grna", "max_grna_frac_umis"))
    expect_false(any(c("covariate_column_templates", "guide_column_templates",
        "guide_list_rows", "covariate_rowname_type") %in% names(screen_meta(object@data))))
    path <- withr::local_tempfile(fileext = ".rds")
    write_sceptre_object(object, path)
    reopened <- read_sceptre_object(path)
    expect_identical(get_cell_covariates(reopened), covariates)
    expect_identical(screen_guide_annotations(reopened@data), annotation)
    expect_identical(screen_guide_summary(reopened@data), screen_guide_summary(object@data))
    expect_identical(serialize(x, NULL), before)
})

test_that("cell views and guide subsets preserve aligned values and relation order", {
    x <- sce_collision_inputs()
    x$metadata <- x$metadata[c(3L, 2L, 1L, 4L), , drop = FALSE]
    object <- sce_collision_import(x)
    cells <- c(9L, 2L, 7L)
    sce <- get_screen_experiment(object)[, cells]
    expected <- screen_cell_covariates(object@data)[cells, , drop = FALSE]
    expect_identical(screen_cell_covariates(sce), expected)
    expect_identical(screen_guide_summary(sce), lapply(screen_guide_summary(object@data), function(v) v[cells]))
    guides <- screen_guides(sce)[c(2L, 7L), ]
    SingleCellExperiment::altExp(sce, "gRNA") <- guides
    rows <- x$metadata$grna_id %in% rownames(guides)
    annotations <- screen_guide_annotations(sce)
    expect_identical(annotations$grna_id, x$metadata$grna_id[rows])
    expect_identical(annotations$grna_target, x$metadata$grna_target[rows])
    expect_identical(annotations$.sceptre_legacy_rowname, x$metadata$.sceptre_legacy_rowname[rows])
    expect_true(validObject(sce))
    SingleCellExperiment::altExp(sce, "gRNA") <- guides[integer(), ]
    empty <- screen_guide_annotations(sce)
    expect_identical(nrow(empty), 0L)
    expect_identical(names(empty), names(annotations))
    expect_identical(levels(empty$.sceptre_legacy_rowname), levels(annotations$.sceptre_legacy_rowname))
})

test_that("guide annotations retain matrix/list payloads with one target per guide", {
    x <- sce_collision_inputs()
    x$metadata <- x$metadata[c(3L, 2L, 1L), , drop = FALSE]
    x$metadata$matrix_payload <- I(matrix(seq_len(6L), nrow = 3L))
    x$metadata$list_payload <- I(list(c("a", "b"), "c", c("d", "e")))
    attr(x$metadata$matrix_payload, "annotation_label") <- "matrix payload"
    attr(x$metadata$list_payload, "annotation_label") <- "list payload"
    object <- sce_collision_import(x)
    annotation <- screen_guide_annotations(object@data)
    # Native rowData row operations preserve payload values/classes/shapes;
    # ad hoc S3 labels follow native extraction behavior rather than a codec.
    matrix_expected <- x$metadata$matrix_payload
    list_expected <- x$metadata$list_payload
    attr(matrix_expected, "annotation_label") <- NULL
    attr(list_expected, "annotation_label") <- NULL
    expect_identical(annotation$matrix_payload, matrix_expected)
    expect_identical(annotation$list_payload, list_expected)
    expect_identical(annotation$grna_id, x$metadata$grna_id)
    expect_identical(annotation$grna_target, x$metadata$grna_target)
    path <- withr::local_tempfile(fileext = ".rds")
    write_sceptre_object(object, path)
    expect_identical(screen_guide_annotations(read_sceptre_object(path)@data), annotation)
})
