native_compat_import <- function(directory, samples = 1L) {
    input <- file.path(directory, "input")
    dir.create(input)
    writeLines(
        c(
            "g1\tMT-one\tGene Expression",
            "guide1\tGuide1\tCRISPR Guide Capture",
            "g2\tGene2\tGene Expression",
            "guide2\tGuide2\tCRISPR Guide Capture"
        ),
        file.path(input, "features.tsv")
    )
    writeLines(c("a", "b", "c"), file.path(input, "barcodes.tsv"))
    writeLines(
        c(
            "%%MatrixMarket matrix coordinate integer general",
            "4 3 7",
            "1 1 2",
            "1 2 0",
            "2 1 5",
            "2 3 1",
            "3 2 4",
            "4 1 1",
            "4 2 3"
        ),
        file.path(input, "matrix.mtx")
    )
    suppressMessages(import_data_from_10x(
        rep(input, samples),
        "low",
        data.frame(
            grna_id = c("guide1", "guide2"),
            grna_target = c("non-targeting", "target")
        ),
        file.path(directory, "output")
    ))
}

test_that("compatibility reopening preserves shared 10x modality views", {
    standard_matrix_require()
    skip_if_not_installed("DropletUtils", "1.32.0")
    directory <- withr::local_tempdir()
    object <- native_compat_import(directory)
    saved <- file.path(directory, "screen.rds")
    write_sceptre_object(object, saved)
    before <- serialize(object, NULL)
    saved_bytes <- readBin(saved, "raw", n = file.info(saved)$size)
    response <- get_response_matrix(object)
    grna <- get_grna_matrix(object)
    expected_response <- as.matrix(response)
    expected_grna <- as.matrix(grna)
    stored_zero <- storage_threshold_row(response, 1L, 0)
    original <- count_backing_paths(response)
    expect_identical(original, count_backing_paths(grna))
    moved <- file.path(directory, "moved.h5")
    expect_true(file.copy(original, moved))
    unlink(original)

    reopened <- read_ondisc_backed_sceptre_object(saved, moved, moved)
    expect_identical(
        as.matrix(get_response_matrix(reopened)),
        expected_response
    )
    expect_identical(as.matrix(get_grna_matrix(reopened)), expected_grna)
    expect_identical(
        storage_threshold_row(get_response_matrix(reopened), 1L, 0),
        stored_zero
    )
    expect_identical(sceptre:::screen_identity(reopened@data), sceptre:::screen_identity(object@data))
    expect_identical(
        reopened@results,
        object@results
    )
    expect_identical(serialize(object, NULL), before)
    expect_identical(
        readBin(saved, "raw", n = length(saved_bytes)),
        saved_bytes
    )

    values <- rhdf5::h5read(moved, "counts/data")
    values[1L] <- values[1L] + 1L
    rhdf5::h5write(values, moved, "counts/data")
    expect_error(
        read_ondisc_backed_sceptre_object(saved, moved, moved),
        "content does not match"
    )
    expect_error(
        read_ondisc_backed_sceptre_object(saved, character(), moved),
        "one path per distinct"
    )
    expect_error(
        read_ondisc_backed_sceptre_object(saved, "missing.h5", moved),
        "does not exist|must already exist|path"
    )
})

test_that("compatibility relocation retains repeated axes and rejects changed views", {
    standard_matrix_require()
    skip_if_not_installed("DropletUtils", "1.32.0")
    directory <- withr::local_tempdir()
    initial <- native_compat_import(directory)
    response <- get_response_matrix(initial)[
        c(2, 1, 2),
        c(3, 1, 3, 2),
        drop = FALSE
    ]
    grna <- get_grna_matrix(initial)[c(2, 1), c(3, 1, 3, 2), drop = FALSE]
    rownames(response) <- c("gene2a", "gene1", "gene2b")
    colnames(response) <- colnames(grna) <- c("ca", "cb", "cc", "cd")
    object <- suppressMessages(import_data(
        response,
        grna,
        data.frame(
            grna_id = rownames(grna),
            grna_target = c("target", "non-targeting")
        ),
        "low"
    ))
    expected <- lapply(list(response, grna), as.matrix)
    original <- count_backing_paths(response)
    saved <- file.path(directory, "views.rds")
    write_sceptre_object(object, saved)
    moved <- file.path(directory, "moved.h5")
    expect_true(file.copy(original, moved))
    unlink(original)
    reopened <- read_ondisc_backed_sceptre_object(saved, moved, moved)
    expect_identical(as.matrix(get_response_matrix(reopened)), expected[[1L]])
    expect_identical(as.matrix(get_grna_matrix(reopened)), expected[[2L]])
    expect_identical(sceptre:::screen_identity(reopened@data), sceptre:::screen_identity(object@data))
    wrong <- get_response_matrix(reopened)[c(2, 1, 3), , drop = FALSE]
    rownames(wrong) <- rownames(response)
    expect_error(
        read_sceptre_object(saved, wrong, get_grna_matrix(reopened)),
        "content does not match"
    )
})

test_that("compatibility relocation retains multisample output and rejects swapped files", {
    standard_matrix_require()
    skip_if_not_installed("DropletUtils", "1.32.0")
    directory <- withr::local_tempdir()
    object <- native_compat_import(directory, samples = 2L)
    response <- get_response_matrix(object)
    grna <- get_grna_matrix(object)
    expected <- lapply(list(response, grna), as.matrix)
    original <- c(count_backing_paths(response), count_backing_paths(grna))
    expect_length(original, 2L)
    expect_false(identical(original[1L], original[2L]))
    moved <- file.path(directory, c("first.h5", "second.h5"))
    expect_true(all(file.copy(original, moved)))
    saved <- file.path(directory, "combined.rds")
    write_sceptre_object(object, saved)
    unlink(original)
    reopened <- read_ondisc_backed_sceptre_object(saved, moved[1L], moved[2L])
    expect_identical(as.matrix(get_response_matrix(reopened)), expected[[1L]])
    expect_identical(as.matrix(get_grna_matrix(reopened)), expected[[2L]])
    expect_identical(sceptre:::screen_identity(reopened@data), sceptre:::screen_identity(object@data))
    expect_error(
        read_ondisc_backed_sceptre_object(saved, moved[2L], moved[1L]),
        "content does not match"
    )
    expect_error(
        read_ondisc_backed_sceptre_object(saved, moved, moved[2L]),
        "one path per distinct"
    )
})

test_that("compatibility relocation retains dense HDF5 dataset and delayed views", {
    standard_matrix_require()
    directory <- withr::local_tempdir()
    counts <- matrix(
        c(2, 5, 0, 1, 0, 0, 4, 3, 1, 1, 2, 0),
        4L,
        3L,
        dimnames = list(c("g1", "guide1", "g2", "guide2"), c("a", "b", "c"))
    )
    original <- file.path(directory, "dense.h5")
    native <- HDF5Array::writeHDF5Array(
        counts,
        original,
        name = "raw_gene_guides",
        with.dimnames = TRUE
    )
    response <- native[c(3, 1), c(3, 1, 2), drop = FALSE]
    grna <- native[c(4, 2), c(3, 1, 2), drop = FALSE]
    object <- suppressMessages(import_data(
        response,
        grna,
        data.frame(
            grna_id = rownames(grna),
            grna_target = c("target", "non-targeting")
        ),
        "low"
    ))
    saved <- file.path(directory, "dense.rds")
    write_sceptre_object(object, saved)
    moved <- file.path(directory, "relocated-dense.h5")
    expect_true(file.copy(original, moved))
    unlink(original)
    reopened <- read_ondisc_backed_sceptre_object(saved, moved, moved)
    actual <- get_response_matrix(reopened)
    expect_s4_class(DelayedArray::seed(actual), "HDF5ArraySeed")
    expect_identical(DelayedArray::seed(actual)@name, "/raw_gene_guides")
    expect_identical(
        as.matrix(actual),
        counts[c(3, 1), c(3, 1, 2), drop = FALSE]
    )
    expect_identical(
        as.matrix(get_grna_matrix(reopened)),
        counts[c(4, 2), c(3, 1, 2), drop = FALSE]
    )
    expect_identical(sceptre:::screen_identity(reopened@data), sceptre:::screen_identity(object@data))
})


test_that("schema-three native wrapper migrates before reading relocated count views", {
    standard_matrix_require()
    skip_if_not_installed("DropletUtils", "1.32.0")
    directory <- withr::local_tempdir()
    object <- native_compat_import(directory)
    expected <- lapply(list(get_response_matrix(object), get_grna_matrix(object)), as.matrix)
    identity <- screen_identity(object@data)
    anchors <- screen_backing_anchors(object@data)
    fields <- names(formals(new_screen_experiment))
    values <- stats::setNames(lapply(fields, function(name) screen_test_field(object@data, name)), fields)
    old_data <- do.call(methods::new, c(list(Class = "ScreenData"), values))
    attr(object, "data") <- old_data
    attr(object, "schema_version") <- 3L
    attr(object, "results") <- new("ResultRecord",
        records = list(), import_metadata = list(backing_stores = anchors))
    path <- file.path(directory, "schema3.rds")
    saveRDS(object, path)
    original_bytes <- readBin(path, "raw", n = file.info(path)$size)
    old <- anchors$response$files$path
    expect_identical(old, anchors$grna$files$path)
    moved <- file.path(directory, "relocated.h5")
    expect_true(file.copy(old, moved))
    unlink(old)
    reopened <- read_ondisc_backed_sceptre_object(path, moved, moved)
    expect_identical(as.matrix(get_response_matrix(reopened)), expected[[1L]])
    expect_identical(as.matrix(get_grna_matrix(reopened)), expected[[2L]])
    expect_identical(screen_identity(reopened@data), identity)
    expect_identical(reopened@schema_version, 7L)
    expect_false("import_metadata" %in% names(reopened@results))
    expect_identical(readBin(path, "raw", n = length(original_bytes)), original_bytes)
    values <- rhdf5::h5read(moved, "counts/data")
    values[1L] <- values[1L] + 1
    rhdf5::h5write(values, moved, "counts/data")
    expect_error(read_ondisc_backed_sceptre_object(path, moved, moved), "content does not match")
})
