test_that("native save anchors content and preserves current caches through relocation", {
    standard_matrix_require()
    inputs <- readRDS(test_path("fixtures", "refactor", "backed-inputs.rds"))
    case <- readRDS(test_path("fixtures", "refactor", "cases.rds"))$high_perm
    directory <- withr::local_tempdir()
    object <- suppressMessages(refactor_prepare(
        inputs,
        case,
        backed = TRUE,
        directory = directory
    ))
    for (modality in c("response", "grna")) {
        store <- screen_test_field(object@data, paste0(modality, "_matrix"))
        expect_s4_class(store, "DelayedMatrix")
        expect_match(
            screen_backing_anchors(object@data)[[
                modality
            ]]$content_md5,
            "^[a-f0-9]{32}$"
        )
    }
    object <- suppressMessages(run_discovery_analysis(
        object,
        print_progress = FALSE
    ))
    expect_gt(length(object@fits@response_fits), 0L)
    expect_true(result_record_is_current(object, "run_discovery_analysis"))
    saved_path <- file.path(directory, "screen.rds")
    write_sceptre_object(object, saved_path)
    original_file <- readBin(saved_path, "raw", n = file.info(saved_path)$size)
    reopened <- read_sceptre_object(saved_path)
    pairs <- dplyr::filter(
        reopened@preparation@discovery_pairs_with_info,
        pass_qc
    )
    expect_gt(
        length(
            prepare_analysis_context(
                reopened,
                "discovery_analysis",
                pairs
            )$response_fits
        ),
        0L
    )
    for (modality in c("response", "grna")) {
        path <- count_backing_paths(screen_test_field(
            object@data,
            paste0(modality, "_matrix")
        ))
        original <- readBin(path, "raw", n = file.info(path)$size)
        counts <- rhdf5::h5read(path, "counts/data")
        counts[1L] <- counts[1L] + 1000
        rhdf5::h5write(counts, path, "counts/data")
        for (candidate in list(object, reopened)) {
            expect_error(
                write_sceptre_object(candidate, saved_path),
                "content does not match"
            )
        }
        expect_error(read_sceptre_object(saved_path), "content does not match")
        expect_identical(
            readBin(saved_path, "raw", n = length(original_file)),
            original_file
        )
        writeBin(original, path)
        expect_true(result_record_is_current(
            reopened,
            "run_discovery_analysis"
        ))
    }
    moved <- withr::local_tempdir()
    matrices <- list()
    for (modality in c("response", "grna")) {
        store <- screen_test_field(object@data, paste0(modality, "_matrix"))
        path <- file.path(moved, paste0(modality, ".h5"))
        expect_true(file.copy(count_backing_paths(store), path))
        matrices[[modality]] <- t(HDF5Array::TENxMatrix(path, "counts"))
        dimnames(matrices[[modality]]) <- dimnames(store)
    }
    relocated <- read_sceptre_object(
        saved_path,
        matrices$response,
        matrices$grna
    )
    expect_identical(sceptre:::screen_identity(relocated@data), sceptre:::screen_identity(reopened@data))
    expect_true(result_record_is_current(relocated, "run_discovery_analysis"))
    expect_identical(relocated@fits@response_fits, reopened@fits@response_fits)
})
