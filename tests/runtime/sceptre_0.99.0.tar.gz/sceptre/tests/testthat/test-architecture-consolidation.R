test_that("semantic certificates ignore table presentation and retain scientific distinctions", {
    df <- data.frame(response_id = c("r1", "r2"), grna_group = c("A", "B"), pass_qc = c(TRUE, FALSE))
    dt <- data.table::as.data.table(df)
    rownames(df) <- c("presentation-a", "presentation-b")
    expect_identical(scientific_digest(df), scientific_digest(dt))
    attrs <- attributes(df)
    attributes(df) <- attrs[rev(names(attrs))]
    expect_identical(scientific_digest(df), scientific_digest(dt))
    expect_false(identical(scientific_digest(df), scientific_digest(df[2:1, ])))
    changed <- df; changed$pass_qc[1L] <- FALSE
    expect_false(identical(scientific_digest(df), scientific_digest(changed)))
    expect_false(identical(scientific_digest(1:3), scientific_digest(as.double(1:3))))
    expect_false(identical(scientific_digest(factor("a", levels = c("a", "b"))), scientific_digest(factor("a", levels = c("b", "a")))))
    ordinary <- integer(1000L); ordinary[] <- seq_len(1000L)
    expect_identical(scientific_digest(seq_len(1000L)), scientific_digest(ordinary))
    expect_false(identical(scientific_digest(matrix(list(1, 2, 3, 4), 2L)),
        scientific_digest(array(list(1, 2, 3, 4), c(2L, 1L, 2L)))))
    withr::local_seed(741)
    rng <- .Random.seed
    scientific_digest(df)
    expect_identical(.Random.seed, rng)
})

test_that("new plans freeze validated CRT policy independently of ambient options", {
    object <- refactor_prepare(refactor_make_inputs(), refactor_case_definitions()$high_complement_crt)
    withr::local_options(sceptre.experimental.crt = list(mode = "cohort", max_guides = 2L, max_draw_bytes = 1024^2))
    plan <- make_run_plan(object, "run_discovery_analysis")
    policy <- run_plan_policy(plan)
    expect_identical(policy, list(mode = "cohort", max_guides = 2L, max_draw_bytes = 1024^2))
    expect_identical(plan@identity$protocol, 2L)
    options(sceptre.experimental.crt = list(mode = "sampler", max_draw_bytes = 0))
    expect_identical(require_run_policy(validate_run_plan(object, plan)), policy)
    changed <- plan; changed@identity$policy$max_guides <- 3L
    expect_error(as_run_plan(changed), "frozen execution payload")
    changed <- plan
    rownames(changed@pairs) <- paste0("display", seq_len(nrow(changed@pairs)))
    changed@pairs <- data.table::as.data.table(changed@pairs)
    expect_s4_class(as_run_plan(changed), "RunPlan")
    changed@pairs$pass_qc[1L] <- !changed@pairs$pass_qc[1L]
    expect_error(as_run_plan(changed), "frozen execution payload")
    for (value in list(list(mode = character()), list(mode = NA_character_), list(mode = c("cohort", "sampler")), list(mode = "cohort", max_guides = 0), list(mode = "cohort", max_draw_bytes = Inf))) {
        expect_error(crt_prototype_policy(value), "Invalid")
    }
    nt <- refactor_prepare(refactor_make_inputs(), refactor_case_definitions()$low_nt_perm)
    nt@spec@run_permutations <- FALSE
    expect_error(resolve_execution_policy(nt, "run_discovery_analysis"), "require shared response fits")
})

test_that("reference sampler and cohort use the same scientific draws and cache policy", {
    inputs <- refactor_make_inputs()
    case <- refactor_case_definitions()$high_complement_crt
    prepared <- refactor_prepare(inputs, case)
    run <- function(mode, draw_bytes = 256 * 1024^2) withr::with_options(list(sceptre.experimental.crt = list(mode = mode, max_guides = 2L, max_draw_bytes = draw_bytes)), {
        withr::with_seed(913, refactor_capture({
            object <- run_discovery_analysis(prepared, print_progress = FALSE, output_amount = 2L)
            list(observation = refactor_observe(object), rng = .Random.seed,
                response_fits = object@fits@response_fits,
                perturbation_fits = object@fits@perturbation_fits,
                policy = object@results$discovery_analysis$provenance$execution_policy)
        }))
    })
    reference <- run("reference")
    for (mode in c("sampler", "cohort")) {
        actual <- run(mode)
        expect_identical(actual$warnings, reference$warnings)
        expect_identical(actual$value[names(actual$value) != "policy"], reference$value[names(reference$value) != "policy"])
        expect_identical(actual$value$policy$mode, mode)
    }
    counters <- new.env(parent = emptyenv()); counters$fits <- 0L; counters$rejected <- 0L
    original_bank <- crt_cohort_bank_cpp
    original_fit <- fit_perturbation_model
    testthat::local_mocked_bindings(
        crt_cohort_bank_cpp = function(...) {
            result <- original_bank(...)
            if (!result$accepted) counters$rejected <- counters$rejected + 1L
            result
        },
        fit_perturbation_model = function(...) {
            counters$fits <- counters$fits + 1L
            original_fit(...)
        }, .package = "sceptre")
    bounded <- run("cohort", 1.5 * 1024^2)
    expect_gt(counters$rejected, 0L)
    expect_identical(counters$fits, length(reference$value$perturbation_fits))
    expect_identical(bounded$warnings, reference$warnings)
    expect_identical(bounded$value[names(bounded$value) != "policy"], reference$value[names(reference$value) != "policy"])
    before <- serialize(prepared, NULL)
    withr::local_options(sceptre.experimental.crt = list(mode = "cohort", max_draw_bytes = 0))
    expect_error(run_discovery_analysis(prepared, print_progress = FALSE), "draw-byte limit")
    expect_identical(serialize(prepared, NULL), before)
})

test_that("backing anchors are owned only by experimental data", {
    object <- refactor_import(refactor_make_inputs(), refactor_case_definitions()$high_perm)
    expect_false("import_metadata" %in% names(object@results))
    expect_named(screen_backing_anchors(object@data), c("response", "grna"))
    path <- withr::local_tempfile(fileext = ".rds")
    write_sceptre_object(object, path)
    reopened <- read_sceptre_object(path)
    expect_identical(screen_backing_anchors(reopened@data), screen_backing_anchors(object@data))
    expect_false("import_metadata" %in% names(reopened@results))
})

test_that("distributed workers execute the manifest's frozen policy", {
    object <- refactor_prepare(refactor_make_inputs(), refactor_case_definitions()$high_complement_crt)
    withr::local_options(sceptre.experimental.crt = list(mode = "reference"))
    manifest <- prepare_execution(object, "run_discovery_analysis", n_work_units = 2L, output_amount = 2L)
    expect_identical(manifest$protocol, 2L)
    expect_identical(run_plan_policy(manifest$plan)$mode, "reference")
    execute <- function(option) withr::with_options(list(sceptre.experimental.crt = option), {
        withr::with_seed(712, {
            proposal <- execute_work_unit(object, manifest, manifest$units[[1L]]$id)
            list(proposal = proposal, rng = .Random.seed)
        })
    })
    reference <- execute(list(mode = "reference"))
    # An invalid current ambient request would fail if a worker reread it.
    expect_identical(execute(list(mode = "invalid-after-freeze")), reference)
    changed <- manifest
    changed$plan@identity$policy$mode <- "cohort"
    expect_error(execute_work_unit(object, changed, changed$units[[1L]]$id), "certificate|payload")
    old <- manifest; old$protocol <- 1L
    expect_error(execute_work_unit(object, old, old$units[[1L]]$id), "protocol")
})
