#include "Rtatami.h"
#include <cmath>
#include <vector>

// [[Rcpp::depends(beachmat, assorthead)]]
// [[Rcpp::plugins(cpp17)]]

// Summarize whole nonnegative UMI counts in one sparse pass in the backend's
// preferred orientation, validating values and canonical sparse coordinates in
// that same pass. Matrix extraction remains owned by beachmat/tatami.
// Optional mitochondrial rows normally come from grep() and are unique; simple
// integer row weights also support repeated private-helper row selections.
// Maxima start at zero and ties keep the first row. Disabled outputs stay zero.
// [[Rcpp::export(rng=false)]]
Rcpp::List standard_matrix_cell_covariates_cpp(
    Rcpp::RObject initialized,
    Rcpp::IntegerVector mt_gene_idxs,
    bool compute_p_mito,
    bool compute_max_feature
) {
    if (TYPEOF(initialized) != EXTPTRSXP)
        Rcpp::stop("Standard matrix handle is not an external pointer.");
    if (R_ExternalPtrTag(initialized) == Rf_install("sceptre_standard_response_reader"))
        Rcpp::stop("Standard matrix handle is a prepared response reader.");
    if (R_ExternalPtrTag(initialized) == Rf_install("sceptre_standard_threshold_reader"))
        Rcpp::stop("Standard matrix handle is a prepared threshold reader.");
    Rtatami::BoundNumericPointer bound(initialized);
    if (!bound.get() || !bound->ptr)
        Rcpp::stop("Standard matrix handle is closed.");
    const auto& mat = bound->ptr;
    const int n_genes = mat->nrow(), n_cells = mat->ncol();
    Rcpp::IntegerVector n_nonzero(n_cells), max_feature(n_cells);
    Rcpp::NumericVector n_umi(n_cells), p_mito(n_cells);
    Rcpp::NumericVector frac_umis_max_feature(n_cells);
    Rcpp::List out = Rcpp::List::create(
        Rcpp::Named("n_nonzero") = n_nonzero,
        Rcpp::Named("n_umi") = n_umi,
        Rcpp::Named("p_mito") = p_mito,
        Rcpp::Named("max_feature") = max_feature,
        Rcpp::Named("frac_umis_max_feature") = frac_umis_max_feature
    );
    if (compute_p_mito) {
        for (int row : mt_gene_idxs) {
            if (row < 1 || row > n_genes)
                Rcpp::stop("Mitochondrial row is outside the one-based feature range.");
        }
    }
    int* detected = INTEGER(n_nonzero);
    int* largest_row = INTEGER(max_feature);
    double* total = REAL(n_umi);
    double* mitochondrial = REAL(p_mito);
    double* fraction = REAL(frac_umis_max_feature);
    {
        std::vector<int> mt_weight(compute_p_mito ? n_genes : 0, 0);
        if (compute_p_mito)
            for (int row : mt_gene_idxs) ++mt_weight[row - 1];
        if (mat->prefer_rows()) {
            auto reader = mat->sparse_row();
            std::vector<double> values(n_cells);
            std::vector<int> indices(n_cells);
            std::vector<double> maximum(compute_max_feature ? n_cells : 0, 0);
            for (int row = 0; row < n_genes; ++row) {
                const auto entries = reader->fetch(row, values.data(), indices.data());
                int previous = -1;
                for (int k = 0; k < entries.number; ++k) {
                    const int cell = entries.index[k];
                    if (cell <= previous || cell >= n_cells)
                        Rcpp::stop("Standard count matrix has noncanonical sparse coordinates.");
                    previous = cell;
                    const double value = entries.value[k];
                    if (!std::isfinite(value) || value < 0 || std::floor(value) != value)
                        Rcpp::stop("Standard-backed UMI counts must be finite nonnegative integers.");
                    total[cell] += value;
                    if (value > 0) ++detected[cell];
                    if (compute_p_mito && mt_weight[row])
                        mitochondrial[cell] += value * mt_weight[row];
                    if (compute_max_feature && value > maximum[cell]) {
                        maximum[cell] = value;
                        largest_row[cell] = row;
                    }
                }
            }
            if (compute_max_feature)
                for (int cell = 0; cell < n_cells; ++cell)
                    fraction[cell] = maximum[cell] / total[cell];
        } else {
            auto reader = mat->sparse_column();
            std::vector<double> values(n_genes);
            std::vector<int> indices(n_genes);
            for (int cell = 0; cell < n_cells; ++cell) {
                const auto entries = reader->fetch(cell, values.data(), indices.data());
                double maximum = 0;
                int previous = -1;
                for (int k = 0; k < entries.number; ++k) {
                    const int row = entries.index[k];
                    if (row <= previous || row >= n_genes)
                        Rcpp::stop("Standard count matrix has noncanonical sparse coordinates.");
                    previous = row;
                    const double value = entries.value[k];
                    if (!std::isfinite(value) || value < 0 || std::floor(value) != value)
                        Rcpp::stop("Standard-backed UMI counts must be finite nonnegative integers.");
                    total[cell] += value;
                    if (value > 0) ++detected[cell];
                    if (compute_p_mito && mt_weight[row])
                        mitochondrial[cell] += value * mt_weight[row];
                    if (compute_max_feature && value > maximum) {
                        maximum = value;
                        largest_row[cell] = row;
                    }
                }
                if (compute_max_feature)
                    fraction[cell] = maximum / total[cell];
            }
        }
        if (compute_p_mito)
            for (int cell = 0; cell < n_cells; ++cell)
                mitochondrial[cell] /= total[cell];
    }
    return out;
}
