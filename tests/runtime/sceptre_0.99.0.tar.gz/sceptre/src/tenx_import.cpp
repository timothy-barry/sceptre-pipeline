#include "Rtatami.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <memory>
#include <stdexcept>
#include <vector>
#include "result_lifetime.h"

// [[Rcpp::depends(beachmat, assorthead)]]
// [[Rcpp::plugins(cpp17)]]

namespace {
struct TenxImportBlock {
    std::vector<double> data;
    std::vector<int> cells, features;
};

// R allocation is isolated in a raw-R leaf under R_UnwindProtect. No Rcpp
// cleanup objects or new C++ buffers may be created in this conversion.
SEXP tenx_import_block_record(void* data) {
    const auto* block = static_cast<const TenxImportBlock*>(data);
    const R_xlen_t size = block->data.size();
    SEXP out = PROTECT(Rf_allocVector(VECSXP, 3));
    SEXP names = PROTECT(Rf_allocVector(STRSXP, 3));
    const char* labels[] = {"value", "cell", "feature"};
    for (int field = 0; field < 3; ++field) {
        SET_STRING_ELT(names, field, Rf_mkChar(labels[field]));
        SET_VECTOR_ELT(out, field, Rf_allocVector(field == 0 ? REALSXP : INTSXP, size));
    }
    std::copy(block->data.begin(), block->data.end(), REAL(VECTOR_ELT(out, 0)));
    std::copy(block->cells.begin(), block->cells.end(), INTEGER(VECTOR_ELT(out, 1)));
    std::copy(block->features.begin(), block->features.end(), INTEGER(VECTOR_ELT(out, 2)));
    Rf_setAttrib(out, R_NamesSymbol, names);
    UNPROTECT(2);
    return out;
}

void delete_tenx_import_block(void* data, Rboolean) noexcept {
    delete static_cast<TenxImportBlock*>(data);
}
}

// Extract a bounded feature block as coordinates of its transpose. Preserve
// stored zeros: coercing through a generic SparseArray can discard them.
// [[Rcpp::export(rng=false)]]
SEXP tenx_import_block_cpp(SEXP handle, int start, int length) {
    if (TYPEOF(handle) != EXTPTRSXP) Rcpp::stop("Standard matrix handle is not an external pointer.");
    if (R_ExternalPtrTag(handle) == Rf_install("sceptre_standard_response_reader")) {
        Rcpp::stop("Standard matrix handle is a prepared response reader.");
    }
    if (R_ExternalPtrTag(handle) == Rf_install("sceptre_standard_threshold_reader")) {
        Rcpp::stop("Standard matrix handle is a prepared threshold reader.");
    }
    const tatami::NumericMatrix* matrix;
    {
        Rtatami::BoundNumericPointer bound(handle);
        if (!bound.get() || !bound->ptr) Rcpp::stop("Standard matrix handle is closed.");
        matrix = bound->ptr.get();
    }
    if (start < 1 || length < 1 || start - 1 > matrix->nrow() - length) {
        Rcpp::stop("Invalid 10x import feature block.");
    }
    SEXP continuation;
    TenxImportBlock* owned;
    {
        sceptre::ResultContinuation token;
        std::unique_ptr<TenxImportBlock> block(new TenxImportBlock);
        auto reader = matrix->sparse_row();
        std::vector<double> values(matrix->ncol());
        std::vector<int> indices(matrix->ncol());
        const bool sparse = matrix->sparse();
        for (int row = 0; row < length; ++row) {
            const auto range = reader->fetch(start - 1 + row, values.data(), indices.data());
            int previous = -1;
            for (int k = 0; k < range.number; ++k) {
                const double value = range.value[k];
                if (!std::isfinite(value) || value < 0 || value != std::floor(value)) {
                    throw std::invalid_argument("10x counts require finite nonnegative integer UMI counts.");
                }
                if (range.index[k] <= previous || range.index[k] >= matrix->ncol()) {
                    throw std::invalid_argument("10x input has noncanonical sparse coordinates.");
                }
                previous = range.index[k];
                if (!sparse && value == 0) continue;
                if (block->data.size() == static_cast<size_t>(std::numeric_limits<int>::max())) {
                    throw std::length_error("10x import block exceeds coordinate capacity; reduce block_rows.");
                }
                block->data.push_back(value);
                block->cells.push_back(range.index[k] + 1);
                block->features.push_back(row + 1);
            }
        }
        owned = block.release();
        continuation = token.release();
    }
    // All other native owners have ended. Transfer directly to protected
    // conversion with no intervening R call that could leak the block payload.
    SEXP out = R_UnwindProtect(tenx_import_block_record, owned,
                               delete_tenx_import_block, owned, continuation);
    UNPROTECT(1);
    return out;
}
