#include <Rcpp.h>
#include <boost/random.hpp>
#include <vector>
#include <memory>
#include <cstdint>
#include <cmath>
#include <limits>
#include <algorithm>
using Bank=std::vector<std::vector<int>>;
namespace {
void draw_crt_rows(boost::random::mt19937& generator,
    boost::random::uniform_real_distribution<double>& uniform,
    const std::vector<double>& positions, std::vector<int>& x,
    std::vector<uint64_t>& stamps, uint64_t& epoch, int B, int M) {
  ++epoch; // <=2*C calls per factory, C<=INT_MAX: cannot wrap uint64.
  const double total = static_cast<double>(B);
  if (M > B / 8) {
    for (int i = 0; i < B; ++i) {
      if ((i & 16383) == 0) Rcpp::checkUserInterrupt();
      x[i] = i;
    }
    for (int i = 0; i < M; ++i) {
      if ((i & 16383) == 0) Rcpp::checkUserInterrupt();
      const double u = uniform(generator);
      const int pos = std::floor((total - positions[i]) * u);
      const double temp = x[pos];
      x[pos] = x[B - i - 1];
      x[B - i - 1] = temp;
    }
    return;
  }
  for (int i = 0; i < M; ++i) {
    if ((i & 16383) == 0) Rcpp::checkUserInterrupt();
    const double u = uniform(generator);
    const int pos = std::floor((total - positions[i]) * u);
    const int last = B - i - 1;
    const int left = stamps[pos] == epoch ? x[pos] : pos;
    const int right = stamps[last] == epoch ? x[last] : last;
    x[pos] = right;
    x[last] = left;
    stamps[pos] = stamps[last] = epoch;
  }
}
}
// Exact full-budget count-before-allocation; byte cap covers bank payload and
// vector capacities, not process RSS. Sampler scratch is separately O(B).
// [[Rcpp::export]]
Rcpp::List crt_cohort_bank_cpp(Rcpp::NumericVector probabilities,int B,double max_bytes){
 if(B<0||!std::isfinite(max_bytes)||max_bytes<0||max_bytes>9007199254740991.0||std::floor(max_bytes)!=max_bytes)
  Rcpp::stop("Invalid CRT draw budget.");
 if(probabilities.size()>std::numeric_limits<int>::max())Rcpp::stop("Too many cells.");
 const double* p=probabilities.begin();const int N=probabilities.size();
 for(int j=0;j<N;++j)if(!std::isfinite(p[j])||p[j]<0||p[j]>1)Rcpp::stop("Invalid probabilities.");
 Rcpp::XPtr<Bank> pointer(static_cast<Bank*>(nullptr),true,Rf_install("sceptre_crt_cohort_bank"));
 Rcpp::List out=Rcpp::List::create(Rcpp::_["accepted"]=false,Rcpp::_["bank"]=pointer,Rcpp::_["bytes"]=0.0,Rcpp::_["entries"]=0.0);
 SEXP accepted=out["accepted"],bytes=out["bytes"],entries=out["entries"];
 std::vector<int> lengths(B,0),x(B);std::vector<uint64_t> stamp(B,0);
 std::vector<double> positions(B);for(int i=0;i<B;++i)positions[i]=i;
 uint64_t epoch=0;boost::random::uniform_real_distribution<double> uni(0,1);
 {boost::random::mt19937 gen(4);
  for(int j=0;j<N;++j){if((j&255)==0)Rcpp::checkUserInterrupt();
   boost::random::binomial_distribution<int> binom(B,p[j]);int M=binom(gen);
   draw_crt_rows(gen,uni,positions,x,stamp,epoch,B,M);
   for(int i=B-M;i<B;++i)++lengths[x[i]];
  }
 }
 uint64_t n=0;for(int k:lengths)n+=k;
 const uint64_t required=sizeof(Bank)+uint64_t(B)*sizeof(std::vector<int>)+4*n;
 REAL(bytes)[0]=double(required);REAL(entries)[0]=double(n);
 if(required>uint64_t(max_bytes))return out;
 std::unique_ptr<Bank> bank(new Bank(B));
 for(int b=0;b<B;++b)(*bank)[b].resize(lengths[b]);
 uint64_t actual=sizeof(Bank)+bank->capacity()*sizeof(std::vector<int>);
 for(const auto& row:*bank)actual+=sizeof(int)*row.capacity();
 if(actual>uint64_t(max_bytes))Rcpp::stop("Allocator exceeded admitted bank capacity.");
 std::fill(lengths.begin(),lengths.end(),0);
 {boost::random::mt19937 gen(4);
  for(int j=0;j<N;++j){if((j&255)==0)Rcpp::checkUserInterrupt();
   boost::random::binomial_distribution<int> binom(B,p[j]);int M=binom(gen);
   draw_crt_rows(gen,uni,positions,x,stamp,epoch,B,M);
   for(int i=B-M;i<B;++i){int b=x[i];(*bank)[b][lengths[b]++]=j;}
  }
 }
 LOGICAL(accepted)[0]=true;REAL(bytes)[0]=double(actual);
 R_SetExternalPtrAddr(pointer,bank.release());return out;
}
// [[Rcpp::export(rng=false)]]
void crt_cohort_close_cpp(SEXP pointer){
 if(TYPEOF(pointer)!=EXTPTRSXP||R_ExternalPtrTag(pointer)!=Rf_install("sceptre_crt_cohort_bank"))Rcpp::stop("Not a prototype CRT bank.");
 delete static_cast<Bank*>(R_ExternalPtrAddr(pointer));R_ClearExternalPtr(pointer);
}
// Diagnostic only. Preallocate R output before native read, no native owner here.
// [[Rcpp::export(rng=false)]]
Rcpp::List crt_cohort_dump_cpp(SEXP pointer){
 if(TYPEOF(pointer)!=EXTPTRSXP||!R_ExternalPtrAddr(pointer))Rcpp::stop("Closed bank.");
 auto* bank=static_cast<Bank*>(R_ExternalPtrAddr(pointer));Rcpp::List out(bank->size());
 for(size_t i=0;i<bank->size();++i)out[i]=Rcpp::wrap((*bank)[i]);return out;
}
