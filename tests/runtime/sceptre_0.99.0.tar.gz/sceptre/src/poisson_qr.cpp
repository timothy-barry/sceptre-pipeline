#include <Rcpp.h>
#include <R_ext/Applic.h>
#include <R_ext/BLAS.h>
#include <algorithm>
#include <cmath>
#include <limits>
#include <numeric>
#include <vector>

// Specialized unweighted, zero-offset Poisson IRLS. Keep glm.fit's starting
// means, weights, QR tolerance and deviance stopping rule. R's public dqrls
// solver supplies the same pivoted QR; only working-buffer allocation is moved
// out of the iteration. Unusual/rank-deficient/nonconvergent cases return NULL
// so the reference fitter retains its warning, step-halving and error behavior.
// [[Rcpp::export(rng=false)]]
SEXP poisson_qr_fit_cpp(Rcpp::NumericMatrix design, Rcpp::NumericVector y) {
    int n = design.nrow(), p = design.ncol();
    if (!n || !p || n < p || y.size() != n) return R_NilValue;
    for (double x : design) if (!std::isfinite(x)) return R_NilValue;
    for (double value : y) {
        if (!std::isfinite(value) || value < 0 || value != std::floor(value))
            return R_NilValue;
    }
    Rcpp::NumericVector coefficients(p), means(n);
    bool converged = false;
    {
        std::vector<double> qr(static_cast<size_t>(n) * p), eta(n), z(n),
            weights(n), residual(n), qty(n), beta(p), qraux(p), work(2 * p);
        std::vector<int> pivot(p);
        const double eps = std::numeric_limits<double>::epsilon();
        auto deviance = [&]() {
            long double sum = 0;
            for (int i = 0; i < n; ++i) {
                double value = means[i];
                if (y[i] > 0) {
                    value = y[i] * std::log(y[i] / means[i]) - (y[i] - means[i]);
                }
                sum += 2 * value;
            }
            return static_cast<double>(sum);
        };
        for (int i = 0; i < n; ++i) {
            eta[i] = std::log(y[i] + 0.1);
            means[i] = std::max(std::exp(eta[i]), eps);
        }
        double old_deviance = deviance();
        for (int iteration = 0; iteration < 25; ++iteration) {
            Rcpp::checkUserInterrupt();
            for (int i = 0; i < n; ++i) {
                // Do not simplify mu^2 / mu: retain glm.fit's arithmetic.
                weights[i] = std::sqrt((means[i] * means[i]) / means[i]);
                z[i] = (eta[i] + (y[i] - means[i]) / means[i]) * weights[i];
                if (!std::isfinite(weights[i]) || !std::isfinite(z[i])) return R_NilValue;
            }
            for (int j = 0; j < p; ++j) {
                const size_t offset = static_cast<size_t>(n) * j;
                for (int i = 0; i < n; ++i) qr[offset + i] = design[offset + i] * weights[i];
            }
            std::iota(pivot.begin(), pivot.end(), 1);
            int one = 1, rank = 0;
            double tolerance = std::min(1e-7, 1e-8 / 1000.0);
            F77_CALL(dqrls)(qr.data(), &n, &p, z.data(), &one, &tolerance,
                beta.data(), residual.data(), qty.data(), &rank,
                pivot.data(), qraux.data(), work.data());
            if (rank != p) return R_NilValue;
            for (int j = 0; j < p; ++j) {
                if (!std::isfinite(beta[j])) return R_NilValue;
                coefficients[pivot[j] - 1] = beta[j];
            }
            double alpha = 1, zero = 0;
            F77_CALL(dgemv)("N", &n, &p, &alpha, design.begin(), &n,
                coefficients.begin(), &one, &zero, eta.data(), &one FCONE);
            for (int i = 0; i < n; ++i) {
                means[i] = std::max(std::exp(eta[i]), eps);
                if (!std::isfinite(means[i])) return R_NilValue;
            }
            const double current = deviance();
            if (!std::isfinite(current)) return R_NilValue;
            if (std::abs(current - old_deviance) / (0.1 + std::abs(current)) < 1e-8) {
                converged = true;
                break;
            }
            old_deviance = current;
        }
        if (!converged) return R_NilValue;
        for (double value : means) if (value < 10 * eps) return R_NilValue;
    }
    // R allocations occur after all native scratch buffers have been released.
    return Rcpp::List::create(Rcpp::Named("coefficients") = coefficients,
        Rcpp::Named("fitted.values") = means, Rcpp::Named("df.residual") = n - p);
}
