#include "Rtatami.h"
#include <algorithm>
#include <cstdint>
#include <cmath>
#include <cstring>
#include <limits>
#include <stdexcept>
#include <vector>

// [[Rcpp::depends(beachmat, assorthead)]]
// [[Rcpp::plugins(cpp17)]]

using namespace Rcpp;

namespace {
SEXP standard_response_reader_tag() {
    return Rf_install("sceptre_standard_response_reader");
}

SEXP standard_threshold_reader_tag() {
    return Rf_install("sceptre_standard_threshold_reader");
}

void standard_check_matrix_handle(SEXP handle) {
    if (TYPEOF(handle) != EXTPTRSXP) stop("Standard matrix handle is not an external pointer.");
    if (R_ExternalPtrTag(handle) == standard_response_reader_tag()) {
        stop("Standard matrix handle is a prepared response reader.");
    }
    if (R_ExternalPtrTag(handle) == standard_threshold_reader_tag()) {
        stop("Standard matrix handle is a prepared threshold reader.");
    }
}

const tatami::NumericMatrix* standard_checked_matrix(SEXP handle) {
    standard_check_matrix_handle(handle);
    Rtatami::BoundNumericPointer bound(handle);
    if (!bound.get() || !bound->ptr) stop("Standard matrix handle is closed.");
    return bound->ptr.get();
}

struct StandardPositions {
    const int* data;
    int size;
};

StandardPositions standard_positions(SEXP input, int limit, const char* label) {
    const R_xlen_t n = Rf_xlength(input);
    if (n > std::numeric_limits<int>::max()) stop("%s exceeds native coordinate capacity.", label);
    const int* values = INTEGER(input);
    for (R_xlen_t k = 0; k < n; ++k) {
        if (values[k] < 1 || values[k] > limit) {
            stop("%s contains a position outside its one-based coordinate view.", label);
        }
    }
    return {values, static_cast<int>(n)};
}

int standard_group_count(const List& groups) {
    if (groups.size() > std::numeric_limits<int>::max()) stop("Group count exceeds native coordinate capacity.");
    return static_cast<int>(groups.size());
}

StandardPositions* standard_groups(const List& groups, int n_cells, SEXP normalized) {
    auto views = reinterpret_cast<StandardPositions*>(R_alloc(groups.size(), sizeof(StandardPositions)));
    for (R_xlen_t g = 0; g < groups.size(); ++g) {
        Shield<SEXP> value(Rf_coerceVector(VECTOR_ELT(groups, g), INTSXP));
        views[g] = standard_positions(value, n_cells, "Analysis group");
        SET_VECTOR_ELT(normalized, g, value);
    }
    return views;
}

std::vector<int> standard_copy_positions(StandardPositions input) {
    std::vector<int> out(input.size);
    for (int k = 0; k < input.size; ++k) out[k] = input.data[k] - 1;
    return out;
}

std::vector<std::vector<int>> standard_copy_groups(const StandardPositions* input, int n) {
    std::vector<std::vector<int>> out(n);
    for (int g = 0; g < n; ++g) out[g] = standard_copy_positions(input[g]);
    return out;
}

// Decode only the selected source columns. The native sparse extractor returns
// original column positions, including explicit zero entries in sparse seeds.
// Mapping back to analysis positions preserves unsorted/repeated selected cells.
// This owner uses C++ only: all R normalization and output allocation precedes it.
class StandardStoredRows {
public:
    StandardStoredRows(const tatami::NumericMatrix* matrix, StandardPositions source_cells) {
        structurally_sparse = matrix->sparse();
        const auto cells = standard_copy_positions(source_cells);
        unique = cells;
        std::sort(unique.begin(), unique.end());
        unique.erase(std::unique(unique.begin(), unique.end()), unique.end());
        mapping.resize(cells.size());
        for (size_t k = 0; k < cells.size(); ++k) {
            mapping[k] = std::lower_bound(unique.begin(), unique.end(), cells[k]) - unique.begin();
        }
        marked.resize(unique.size());
        analysis.resize(cells.size());
        indices.resize(unique.size());
        if (!structurally_sparse) values.resize(unique.size());
        if (!unique.empty()) {
            tatami::Options options;
            options.sparse_extract_value = !structurally_sparse;
            reader = matrix->sparse_row(unique, options);
        }
    }

    void fetch(int row) {
        if (!reader) return;
        std::fill(marked.begin(), marked.end(), false);
        const auto range = reader->fetch(row, structurally_sparse ? nullptr : values.data(), indices.data());
        size_t at = 0;
        for (int k = 0; k < range.number; ++k) {
            // A dense source is sparsified by the legacy importer: numerical
            // zeros are absent. A sparse source retains its explicit zeros.
            if (!structurally_sparse && range.value[k] == 0) continue;
            while (at < unique.size() && unique[at] < range.index[k]) ++at;
            if (at == unique.size() || unique[at] != range.index[k]) {
                throw std::runtime_error("Native sparse extraction returned an unselected column.");
            }
            marked[at] = true;
        }
        for (size_t k = 0; k < analysis.size(); ++k) analysis[k] = marked[mapping[k]];
    }

    int count(const std::vector<int>& group) const {
        int n = 0;
        for (int cell : group) if (analysis[cell]) ++n;
        return n;
    }

    int total() const {
        return std::count(analysis.begin(), analysis.end(), true);
    }

private:
    std::vector<int> unique, mapping, indices;
    std::vector<double> values;
    std::vector<bool> marked, analysis;
    bool structurally_sparse;
    std::unique_ptr<tatami::MyopicSparseExtractor<double, int>> reader;
};

// The external pointer roots the original R descriptor, and this state owns the
// native matrix independently of the short-lived beachmat initialization handle.
// A fixed cell view pays for index normalization and extractor construction once.
class StandardResponseReader {
public:
    StandardResponseReader(std::shared_ptr<tatami::NumericMatrix> matrix_in,
                           const StandardPositions* selected) : matrix(std::move(matrix_in)) {
        if (selected) {
            unique = standard_copy_positions(*selected);
            std::sort(unique.begin(), unique.end());
            unique.erase(std::unique(unique.begin(), unique.end()), unique.end());
            indexed = unique.size() != static_cast<size_t>(selected->size) ||
                !std::is_sorted(selected->data, selected->data + selected->size);
            if (indexed) {
                mapping.resize(selected->size);
                for (int k = 0; k < selected->size; ++k) {
                    mapping[k] = std::lower_bound(unique.begin(), unique.end(), selected->data[k] - 1) - unique.begin();
                }
            }
            output_size = selected->size;
            if (indexed) buffer.resize(unique.size());
            if (!unique.empty()) {
                if (unique.back() - unique.front() + 1 == static_cast<int>(unique.size())) {
                    reader = matrix->dense_row(unique.front(), static_cast<int>(unique.size()));
                } else {
                    reader = matrix->dense_row(unique);
                }
            }
        } else {
            output_size = matrix->ncol();
            if (output_size) reader = matrix->dense_row();
        }
    }

    int size() const { return output_size; }
    int nrow() const { return matrix->nrow(); }

    void read(int row, double* output) {
        if (!reader) return;
        // Tatami may return its own backing pointer instead of filling the
        // supplied buffer. Full/sorted views can use the R result as scratch,
        // avoiding both a native row buffer and a second full-row memory copy.
        const auto* data = reader->fetch(row, indexed ? buffer.data() : output);
        if (indexed) {
            for (int k = 0; k < output_size; ++k) output[k] = data[mapping[k]];
        } else if (data != output) {
            std::copy(data, data + output_size, output);
        }
    }

private:
    std::shared_ptr<tatami::NumericMatrix> matrix;
    std::vector<int> unique, mapping;
    std::vector<double> buffer;
    std::unique_ptr<tatami::MyopicDenseExtractor<double, int>> reader;
    int output_size = 0;
    bool indexed = false;
};

StandardResponseReader* standard_checked_response_reader(SEXP handle, bool allow_closed = false) {
    if (TYPEOF(handle) != EXTPTRSXP || R_ExternalPtrTag(handle) != standard_response_reader_tag()) {
        stop("Response reader is not a standard native reader.");
    }
    auto* ptr = static_cast<StandardResponseReader*>(R_ExternalPtrAddr(handle));
    if (!ptr && !allow_closed) stop("Response reader is closed.");
    return ptr;
}

// Keep every native owner in the R-rooted context while allocating exact R
// results. Count-only extraction sizes scratch to stored row NNZ; the value
// extractor and its HDF5 cache survive across all rows in the batch.
class StandardThresholdReader {
public:
    StandardThresholdReader(std::shared_ptr<tatami::NumericMatrix> matrix_in) : matrix(std::move(matrix_in)) {
        structurally_sparse = matrix->sparse();
        if (matrix->ncol()) {
            if (structurally_sparse) {
                tatami::Options options;
                options.sparse_extract_value = false;
                options.sparse_extract_index = false;
                counter = matrix->sparse_row(options);
            } else {
                values.resize(matrix->ncol());
                indices.resize(matrix->ncol());
            }
            reader = matrix->sparse_row();
        }
    }

    int nrow() const { return matrix->nrow(); }

    int collect(int row, double threshold) {
        if (!reader) return 0;
        if (counter) {
            const int stored = counter->fetch(row, nullptr, nullptr).number;
            if (stored < 0 || stored > matrix->ncol()) {
                throw std::runtime_error("Native sparse extraction returned an invalid stored-entry count.");
            }
            if (stored > static_cast<int>(values.size())) {
                values.resize(stored);
                indices.resize(stored);
            }
            if (!stored) return 0;
        }
        const auto range = reader->fetch(row, values.data(), indices.data());
        int written = 0;
        for (int k = 0; k < range.number; ++k) {
            if ((structurally_sparse || range.value[k] != 0) && range.value[k] >= threshold) {
                if (written == static_cast<int>(indices.size())) {
                    throw std::runtime_error("Count backing changed during threshold extraction.");
                }
                // Compact only into our scratch, never into a returned tatami
                // backing pointer. If range.index already aliases scratch,
                // written <= k ensures later source indices stay untouched.
                indices[written++] = range.index[k] + 1;
            }
        }
        return written;
    }

    const int* data() const { return indices.data(); }

private:
    std::shared_ptr<tatami::NumericMatrix> matrix;
    std::vector<double> values;
    std::vector<int> indices;
    std::unique_ptr<tatami::MyopicSparseExtractor<double, int>> counter, reader;
    bool structurally_sparse;
};

StandardThresholdReader* standard_checked_threshold_reader(SEXP handle, bool allow_closed = false) {
    if (TYPEOF(handle) != EXTPTRSXP || R_ExternalPtrTag(handle) != standard_threshold_reader_tag()) {
        stop("Threshold reader is not a standard native threshold reader.");
    }
    auto* ptr = static_cast<StandardThresholdReader*>(R_ExternalPtrAddr(handle));
    if (!ptr && !allow_closed) stop("Threshold reader is closed.");
    return ptr;
}
}

// Close native backing resources deterministically instead of waiting for R's
// external-pointer finalizer. The original R matrix descriptor is unchanged.
// R calls this after the native consumer has returned or unwound its C++ error.
// [[Rcpp::export(rng=false)]]
void standard_matrix_release_cpp(SEXP handle) {
    standard_check_matrix_handle(handle);
    Rtatami::BoundNumericPointer bound(handle);
    if (!bound.get()) return;
    bound->ptr.reset();
    bound->original = R_NilValue;
}

// Allocate/root the external pointer before constructing native owners. Its
// protected slot keeps any R-backed matrix data alive after the base handle is
// released. Construction failure unwinds the native state before reaching R.
// [[Rcpp::export(rng=false)]]
SEXP standard_matrix_open_response_reader_cpp(SEXP handle,
                                             Nullable<IntegerVector> source_cells = R_NilValue) {
    const auto* matrix = standard_checked_matrix(handle);
    StandardPositions selected{nullptr, 0};
    if (source_cells.isNotNull()) {
        IntegerVector cells(source_cells);
        selected = standard_positions(cells, matrix->ncol(), "Source cells");
    }
    Rtatami::BoundNumericPointer bound(handle);
    XPtr<StandardResponseReader> out(static_cast<StandardResponseReader*>(nullptr), true,
                                     standard_response_reader_tag(), bound->original);
    auto* reader = new StandardResponseReader(bound->ptr, source_cells.isNull() ? nullptr : &selected);
    R_SetExternalPtrAddr(out, reader);
    return out;
}

// [[Rcpp::export(rng=false)]]
NumericVector standard_matrix_read_response_cpp(SEXP handle, int response) {
    auto* reader = standard_checked_response_reader(handle);
    if (response < 1 || response > reader->nrow()) stop("Requested response is outside the one-based feature range.");
    // fetch/copy/mapping writes every element before a successful return.
    NumericVector out(no_init(reader->size()));
    reader->read(response - 1, REAL(out));
    return out;
}

// [[Rcpp::export(rng=false)]]
void standard_matrix_close_response_reader_cpp(SEXP handle) {
    auto* reader = standard_checked_response_reader(handle, true);
    delete reader;
    R_ClearExternalPtr(handle);
    R_SetExternalPtrProtected(handle, R_NilValue);
}

// Validate integer UMI counts in the backend's preferred physical orientation. This
// one-time import scan uses sparse native extraction and no dense whole-matrix
// materialization. Standard sparse coordinates must be sorted and unique.
// Check standard SparseArray metadata before a numeric adapter can copy sparse
// results into dimension-sized buffers. SparseArray's S4 validity deliberately
// does not inspect SVT leaves. This scan borrows R vectors and owns no buffers.
// [[Rcpp::export(rng=false)]]
void standard_matrix_validate_svt_cpp(SEXP seed) {
    SEXP dimensions = R_do_slot(seed, Rf_install("dim"));
    SEXP tree = R_do_slot(seed, Rf_install("SVT"));
    SEXP version = R_do_slot(seed, Rf_install(".svt_version"));
    SEXP type = R_do_slot(seed, Rf_install("type"));
    if (TYPEOF(dimensions) != INTSXP || XLENGTH(dimensions) != 2 ||
        INTEGER(dimensions)[0] < 0 || INTEGER(dimensions)[1] < 0) {
        stop("Invalid SVT sparse matrix dimensions.");
    }
    if (TYPEOF(version) != INTSXP || XLENGTH(version) != 1 ||
        (INTEGER(version)[0] != 1 && !(INTEGER(version)[0] == 0 && tree == R_NilValue))) {
        stop("Unsupported SVT sparse matrix layout version; convert with a compatible SparseArray release.");
    }
    if (TYPEOF(type) != STRSXP || XLENGTH(type) != 1 || STRING_ELT(type, 0) == NA_STRING) {
        stop("Invalid SVT sparse matrix value type.");
    }
    const char* name = CHAR(STRING_ELT(type, 0));
    const int value_type = std::strcmp(name, "double") == 0 ? REALSXP :
        (std::strcmp(name, "integer") == 0 ? INTSXP : -1);
    if (value_type < 0) stop("SVT count matrices require numeric integer UMI counts.");
    if (tree == R_NilValue) return;
    const int rows = INTEGER(dimensions)[0], columns = INTEGER(dimensions)[1];
    if (TYPEOF(tree) != VECSXP || XLENGTH(tree) != columns) {
        stop("Invalid SVT sparse matrix column structure.");
    }
    for (int column = 0; column < columns; ++column) {
        SEXP leaf = VECTOR_ELT(tree, column);
        if (leaf == R_NilValue) continue;
        if (TYPEOF(leaf) != VECSXP || XLENGTH(leaf) != 2) {
            stop("Invalid SVT sparse matrix leaf structure.");
        }
        SEXP values = VECTOR_ELT(leaf, 0), indices = VECTOR_ELT(leaf, 1);
        if (TYPEOF(indices) != INTSXP || XLENGTH(indices) > rows) {
            stop("SVT sparse matrix has noncanonical row indices or too many entries in a column.");
        }
        if (values != R_NilValue &&
            (TYPEOF(values) != value_type || XLENGTH(values) != XLENGTH(indices))) {
            stop("SVT sparse matrix values and row indices have incompatible types or lengths.");
        }
        const int* offsets = INTEGER(indices);
        int previous = -1;
        for (R_xlen_t i = 0; i < XLENGTH(indices); ++i) {
            if (offsets[i] <= previous || offsets[i] >= rows) {
                stop("SVT sparse matrix has noncanonical row indices.");
            }
            previous = offsets[i];
        }
    }
}

// HDF5Array already loads its compressed-pointer ranges into seed metadata.
// Verify that a raw sparse column/row cannot exceed its source extent before
// constructing an extractor. This does not read HDF5 datasets or count values.
// [[Rcpp::export(rng=false)]]
void standard_matrix_validate_h5_ranges_cpp(IntegerVector dimensions, SEXP starts,
                                            SEXP widths, bool rows) {
    if (dimensions.size() != 2 || dimensions[0] < 0 || dimensions[1] < 0) {
        stop("Invalid native HDF5 sparse matrix dimensions.");
    }
    const int major = dimensions[rows ? 0 : 1], minor = dimensions[rows ? 1 : 0];
    if ((TYPEOF(starts) != INTSXP && TYPEOF(starts) != REALSXP) ||
        (TYPEOF(widths) != INTSXP && TYPEOF(widths) != REALSXP) ||
        XLENGTH(starts) != major || XLENGTH(widths) != major) {
        stop("Invalid native HDF5 sparse pointer-range metadata.");
    }
    double expected = 1;
    for (int i = 0; i < major; ++i) {
        const double start = TYPEOF(starts) == INTSXP ? INTEGER(starts)[i] : REAL(starts)[i];
        const double width = TYPEOF(widths) == INTSXP ? INTEGER(widths)[i] : REAL(widths)[i];
        if (!std::isfinite(start) || start != expected ||
            !std::isfinite(width) || width < 0 || width != std::floor(width) || width > minor) {
            stop("Native HDF5 sparse pointer ranges are noncanonical or exceed the compressed-axis extent.");
        }
        expected = start + width;
        if (expected > 9007199254740992.0) {
            stop("Native HDF5 sparse pointer ranges exceed exact metadata coordinate capacity.");
        }
    }
}

// [[Rcpp::export(rng=false)]]
void standard_matrix_validate_cpp(SEXP handle) {
    const auto* matrix = standard_checked_matrix(handle);
    const bool rows = matrix->prefer_rows();
    const int major = rows ? matrix->nrow() : matrix->ncol();
    const int minor = rows ? matrix->ncol() : matrix->nrow();
    if (major == 0 || minor == 0) return;
    {
        auto reader = rows ? matrix->sparse_row() : matrix->sparse_column();
        std::vector<double> values(minor);
        std::vector<int> indices(minor);
        for (int k = 0; k < major; ++k) {
            const auto range = reader->fetch(k, values.data(), indices.data());
            int previous = -1;
            for (int entry = 0; entry < range.number; ++entry) {
                if (range.index[entry] <= previous || range.index[entry] >= minor) {
                    throw std::invalid_argument("Standard count matrix has noncanonical sparse coordinates.");
                }
                const double value = range.value[entry];
                if (!std::isfinite(value) || value < 0 || value != std::floor(value)) {
                    throw std::invalid_argument("Standard count matrices require finite nonnegative integer UMI counts.");
                }
                previous = range.index[entry];
            }
        }
    }
}

// Read a single response row into its requested analysis-cell order. Native
// indexed extraction never allocates a dense row across omitted source cells.
// Prepare R inputs/output first and free all native readers before returning.
// [[Rcpp::export(rng=false)]]
NumericVector standard_matrix_read_row_cpp(SEXP handle, int response,
                                           Nullable<IntegerVector> source_cells = R_NilValue) {
    const auto* matrix = standard_checked_matrix(handle);
    if (response < 1 || response > matrix->nrow()) stop("Requested response is outside the one-based feature range.");
    if (source_cells.isNull()) {
        NumericVector out(matrix->ncol());
        if (matrix->ncol() == 0) return out;
        double* output = REAL(out);
        {
            auto reader = matrix->dense_row();
            std::vector<double> buffer(matrix->ncol());
            const auto* data = reader->fetch(response - 1, buffer.data());
            std::copy(data, data + matrix->ncol(), output);
        }
        return out;
    }
    IntegerVector selected(source_cells);
    const auto input = standard_positions(selected, matrix->ncol(), "Source cells");
    NumericVector out(input.size);
    double* output = REAL(out);
    if (input.size) {
        auto cells = standard_copy_positions(input);
        auto unique = cells;
        std::sort(unique.begin(), unique.end());
        unique.erase(std::unique(unique.begin(), unique.end()), unique.end());
        auto reader = matrix->dense_row(unique);
        std::vector<double> buffer(unique.size());
        const auto* data = reader->fetch(response - 1, buffer.data());
        for (int k = 0; k < input.size; ++k) {
            const auto at = std::lower_bound(unique.begin(), unique.end(), cells[k]) - unique.begin();
            output[k] = data[at];
        }
    }
    return out;
}

// As with response readers, root an empty pointer and its descriptor before
// constructing native owners. The R caller registers close before opening it.
// [[Rcpp::export(rng=false)]]
SEXP standard_matrix_open_threshold_reader_cpp(SEXP handle) {
    standard_checked_matrix(handle);
    Rtatami::BoundNumericPointer bound(handle);
    XPtr<StandardThresholdReader> out(static_cast<StandardThresholdReader*>(nullptr), true,
                                      standard_threshold_reader_tag(), bound->original);
    auto* reader = new StandardThresholdReader(bound->ptr);
    R_SetExternalPtrAddr(out, reader);
    return out;
}

// Read each row's values exactly once. The R caller roots and deterministically
// closes the context even if any R allocation longjmps. No owning C++ stack
// object survives across result allocation; only the rooted context owns native
// extractors, cached data and NNZ-sized scratch buffers.
// [[Rcpp::export(rng=false)]]
List standard_matrix_threshold_rows_cpp(SEXP handle, IntegerVector responses, double threshold) {
    auto* reader = standard_checked_threshold_reader(handle);
    const auto rows = standard_positions(responses, reader->nrow(), "Requested response");
    List out(rows.size);
    for (int row = 0; row < rows.size; ++row) {
        const int n = reader->collect(rows.data[row] - 1, threshold);
        IntegerVector selected(no_init(n));
        if (n) std::copy(reader->data(), reader->data() + n, INTEGER(selected));
        out[row] = selected;
    }
    return out;
}

// [[Rcpp::export(rng=false)]]
void standard_matrix_close_threshold_reader_cpp(SEXP handle) {
    auto* reader = standard_checked_threshold_reader(handle, true);
    delete reader;
    R_ClearExternalPtr(handle);
    R_SetExternalPtrProtected(handle, R_NilValue);
}

// Compatibility for direct private single-row calls with a base matrix handle.
// Package R storage operations use the single-pass prepared context above.
// Here native owners end before allocation, then the same collection logic is
// replayed; keep counts immutable between these two scopes.
// [[Rcpp::export(rng=false)]]
IntegerVector standard_matrix_threshold_row_cpp(SEXP handle, int response, double threshold) {
    const auto* matrix = standard_checked_matrix(handle);
    if (response < 1 || response > matrix->nrow()) stop("Requested response is outside the one-based feature range.");
    Rtatami::BoundNumericPointer bound(handle);
    int n;
    {
        StandardThresholdReader reader(bound->ptr);
        n = reader.collect(response - 1, threshold);
    }
    IntegerVector out(no_init(n));
    int* output = INTEGER(out);
    if (n) {
        StandardThresholdReader reader(bound->ptr);
        if (reader.collect(response - 1, threshold) != n) {
            throw std::runtime_error("Count backing changed during threshold extraction.");
        }
        std::copy(reader.data(), reader.data() + n, output);
    }
    return out;
}

// Package-owned QC semantics with maintained sparse extraction. The optional
// all-feature NT summary follows the in-memory Matrix route, including nuclear
// calls. Without that summary only requested response rows are read.
// [[Rcpp::export(rng=false)]]
List standard_matrix_pair_counts_cpp(SEXP handle, List groups, List nt_groups,
                                     IntegerVector responses, IntegerVector group_ids,
                                     bool complement, IntegerVector source_cells,
                                     bool retain_summary) {
    const auto* matrix = standard_checked_matrix(handle);
    if (responses.size() != group_ids.size()) stop("Requested response/group positions must have matching native lengths.");
    const auto cells = standard_positions(source_cells, matrix->ncol(), "Source cells");
    const int ng = standard_group_count(groups), nnt = standard_group_count(nt_groups);
    Shield<SEXP> normalized_groups(Rf_allocVector(VECSXP, ng));
    Shield<SEXP> normalized_nt(Rf_allocVector(VECSXP, nnt));
    auto group_views = standard_groups(groups, cells.size, normalized_groups);
    auto nt_views = standard_groups(nt_groups, cells.size, normalized_nt);
    const auto requested_rows = standard_positions(responses, matrix->nrow(), "Requested response");
    const auto requested_groups = standard_positions(group_ids, ng, "Requested group");
    if (requested_rows.size > 1 && !std::is_sorted(requested_rows.data, requested_rows.data + requested_rows.size)) {
        stop("Standard pair requests must be in response scan order.");
    }
    IntegerVector totals(retain_summary ? matrix->nrow() : 0);
    IntegerMatrix nt_counts(retain_summary ? nnt : 0, retain_summary ? matrix->nrow() : 0);
    IntegerVector treated(requested_rows.size), control(requested_rows.size);
    List out = List::create(_["n_nonzero_mat"] = nt_counts, _["n_nonzero_tot"] = totals,
                            _["n_nonzero_trt"] = treated, _["n_nonzero_cntrl"] = control);
    int* total_data = INTEGER(totals);
    int* nt_data = INTEGER(nt_counts);
    int* treated_data = INTEGER(treated);
    int* control_data = INTEGER(control);
    {
        const auto owned_groups = standard_copy_groups(group_views, ng);
        const auto owned_nt = standard_copy_groups(nt_views, nnt);
        const auto rows = standard_copy_positions(requested_rows);
        const auto gids = standard_copy_positions(requested_groups);
        StandardStoredRows reader(matrix, cells);
        int request = 0;
        for (int row = 0; row < matrix->nrow();) {
            if (!retain_summary) {
                if (request == requested_rows.size) break;
                row = rows[request];
            }
            reader.fetch(row);
            int64_t nt_total = 0;
            for (int g = 0; g < nnt; ++g) {
                const int n = reader.count(owned_nt[g]);
                if (retain_summary) nt_data[g + static_cast<R_xlen_t>(row) * nnt] = n;
                nt_total += n;
            }
            if (nt_total > std::numeric_limits<int>::max()) throw std::overflow_error("NT group sum exceeds integer count capacity.");
            const int total = complement ? reader.total() : static_cast<int>(nt_total);
            if (retain_summary) total_data[row] = total;
            while (request < requested_rows.size && rows[request] == row) {
                const int n = reader.count(owned_groups[gids[request]]);
                treated_data[request] = n;
                control_data[request] = complement ? total - n : total;
                ++request;
            }
            if (retain_summary) ++row;
        }
    }
    return out;
}

// Count only requested feature rows, sorting the I/O order while retaining the
// caller's order/repeats in the result columns. No values are needed for QC.
// [[Rcpp::export(rng=false)]]
IntegerMatrix standard_matrix_group_counts_cpp(SEXP handle, IntegerVector responses,
                                               List groups, IntegerVector source_cells) {
    const auto* matrix = standard_checked_matrix(handle);
    const auto cells = standard_positions(source_cells, matrix->ncol(), "Source cells");
    const auto rows = standard_positions(responses, matrix->nrow(), "Requested response");
    const int ng = standard_group_count(groups);
    Shield<SEXP> normalized(Rf_allocVector(VECSXP, ng));
    auto group_views = standard_groups(groups, cells.size, normalized);
    IntegerMatrix out(ng, rows.size);
    int* output = INTEGER(out);
    {
        const auto owned_groups = standard_copy_groups(group_views, ng);
        const auto requested = standard_copy_positions(rows);
        std::vector<int> order(rows.size);
        for (int k = 0; k < rows.size; ++k) order[k] = k;
        std::sort(order.begin(), order.end(), [&](int left, int right) { return requested[left] < requested[right]; });
        StandardStoredRows reader(matrix, cells);
        int previous = -1;
        for (int k : order) {
            if (requested[k] != previous) {
                reader.fetch(requested[k]);
                previous = requested[k];
            }
            for (int g = 0; g < ng; ++g) output[g + static_cast<R_xlen_t>(k) * ng] = reader.count(owned_groups[g]);
        }
    }
    return out;
}
