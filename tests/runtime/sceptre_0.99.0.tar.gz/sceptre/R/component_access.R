# Private read boundaries for modules that consume prepared analysis state.
# Resolve these small lists once per operation, never once per cell or draw.
# Values are borrowed read-only: matrices and tables are not materialized or
# deep-copied. Public extraction retains its separate ownership guarantees.
# Updates still go through the validated parameter/preparation/cache/result
# lifecycle; these readers deliberately have no replacement methods.

analysis_settings <- function(object) {
    spec <- object@spec
    list(
        formula_object = spec@formula_object,
        side_code = spec@side_code,
        resampling_approximation = spec@resampling_approximation,
        control_group_complement = spec@control_group_complement,
        run_permutations = spec@run_permutations,
        n_nonzero_trt_thresh = spec@n_nonzero_trt_thresh,
        n_nonzero_cntrl_thresh = spec@n_nonzero_cntrl_thresh,
        grna_integration_strategy = spec@grna_integration_strategy,
        grna_assignment_method = spec@grna_assignment_method,
        grna_assignment_hyperparameters =
            spec@grna_assignment_hyperparameters,
        multiple_testing_alpha = spec@multiple_testing_alpha,
        multiple_testing_method = spec@multiple_testing_method,
        cellwise_qc_thresholds = spec@cellwise_qc_thresholds,
        additional_cells_to_remove = spec@additional_cells_to_remove
    )
}

prepared_analysis_inputs <- function(object) {
    preparation <- object@preparation
    list(
        analysis_cells = preparation@analysis_cells,
        analysis_groups = preparation@analysis_groups,
        design_matrix = preparation@design_matrix
    )
}

guide_assignment_summary <- function(object) {
    preparation <- object@preparation
    list(
        guide_assignments = preparation@guide_assignments,
        assignment_exclusions = preparation@assignment_exclusions,
        guide_counts_per_cell = preparation@guide_counts_per_cell
    )
}

pair_qc_summary <- function(object) {
    preparation <- object@preparation
    list(
        discovery_pairs_with_info = preparation@discovery_pairs_with_info,
        positive_control_pairs_with_info =
            preparation@positive_control_pairs_with_info,
        nt_nonzero_matrix = preparation@nt_nonzero_matrix,
        control_nonzero_totals = preparation@control_nonzero_totals
    )
}

cell_qc_metrics <- function(object) {
    object@preparation@cell_removal_metrics
}

preparation_stages <- function(object) {
    object@preparation@stages
}
