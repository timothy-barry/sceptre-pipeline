# SCE owns counts, cell covariates, feature labels and guide annotations.
# Readers return native Bioconductor values. Ordinary data.frame conversion
# belongs only at public/table-algorithm boundaries, never in a legacy codec.
screen_meta <- function(x) S4Vectors::metadata(x)$sceptre
`screen_meta<-` <- function(x, value) {
    S4Vectors::metadata(x)$sceptre <- value
    x
}

screen_response_counts <- function(x) {
    SummarizedExperiment::assay(x, "counts", withDimnames = FALSE)
}
`screen_response_counts<-` <- function(x, value) {
    SummarizedExperiment::assay(x, "counts", withDimnames = FALSE) <- value
    x
}
screen_guides <- function(x) {
    SingleCellExperiment::altExp(
        x,
        "gRNA",
        withDimnames = FALSE,
        withColData = FALSE
    )
}
screen_guide_counts <- function(x) {
    SummarizedExperiment::assay(
        screen_guides(x),
        "counts",
        withDimnames = FALSE
    )
}
`screen_guide_counts<-` <- function(x, value) {
    guide <- screen_guides(x)
    SummarizedExperiment::assay(guide, "counts", withDimnames = FALSE) <- value
    SingleCellExperiment::altExp(x, "gRNA") <- guide
    x
}
screen_count_matrices <- function(x) {
    list(response = screen_response_counts(x), grna = screen_guide_counts(x))
}
screen_response_metadata <- function(x) SummarizedExperiment::rowData(x)
screen_response_names <- function(x) {
    labels <- screen_response_metadata(x)$response_name
    if (is.null(labels)) character() else as.character(labels)
}
`screen_response_names<-` <- function(x, value) {
    if (length(value) && length(value) != nrow(x)) {
        stop("Response labels must match response rows")
    }
    SummarizedExperiment::rowData(x)$response_name <-
        if (length(value)) as.character(value) else NULL
    x
}
# Main colData contains model covariates only; guide summaries have their own axis.
screen_cell_covariates <- function(x) SummarizedExperiment::colData(x)
`screen_cell_covariates<-` <- function(x, value) {
    value <- S4Vectors::DataFrame(value, check.names = FALSE)
    if (nrow(value) != ncol(x)) {
        stop("Cell covariates must match source cells")
    }
    rownames(value) <- colnames(x)
    SummarizedExperiment::colData(x) <- value
    x
}

# Annotation values are feature-aligned rowData. The small ordered ID vector
# preserves supplied traversal order independently of the unchanged count axis.
screen_guide_annotations <- function(x) {
    guide <- screen_guides(x)
    ids <- S4Vectors::metadata(guide)$sceptre$annotation_order
    ids <- ids[ids %in% rownames(guide)]
    value <- SummarizedExperiment::rowData(guide)[
        match(ids, rownames(guide)),
        ,
        drop = FALSE
    ]
    rownames(value) <- NULL
    value
}
`screen_guide_annotations<-` <- function(x, value) {
    value <- S4Vectors::DataFrame(value, check.names = FALSE)
    guide <- screen_guides(x)
    if (!nrow(value)) {
        if (!"grna_id" %in% names(value)) {
            value$grna_id <- character()
        }
        if (!"grna_target" %in% names(value)) value$grna_target <- character()
    }
    if (
        !all(c("grna_id", "grna_target") %in% names(value)) ||
            anyNA(value$grna_id) ||
            anyNA(value$grna_target) ||
            !all(value$grna_id %in% rownames(guide))
    ) {
        stop(
            "Guide annotations must map to count-row IDs and nonmissing targets"
        )
    }
    if (anyDuplicated(value$grna_id)) {
        stop(
            "Guide annotations require one row per grna_id; duplicate or multi-target mappings are unsupported. Resolve the original annotations explicitly before importing or migrating."
        )
    }
    ids <- as.character(value$grna_id)
    rows <- if (nrow(value)) {
        match(rownames(guide), ids)
    } else {
        rep(NA_integer_, nrow(guide))
    }
    aligned <- value[rows, , drop = FALSE]
    rownames(aligned) <- rownames(guide)
    SummarizedExperiment::rowData(guide) <- aligned
    S4Vectors::metadata(guide)$sceptre <- list(annotation_order = ids)
    SingleCellExperiment::altExp(x, "gRNA") <- guide
    x
}

screen_backing_anchors <- function(x) {
    value <- screen_meta(x)$backing_stores
    if (is.null(value)) list() else value
}
`screen_backing_anchors<-` <- function(x, value) {
    if (
        !is.list(value) ||
            (length(value) && !identical(names(value), c("response", "grna")))
    ) {
        stop("Backing anchors must map response and grna data")
    }
    meta <- screen_meta(x)
    meta$backing_stores <- value
    screen_meta(x) <- meta
    x
}

screen_identity <- function(x) screen_meta(x)$identity
`screen_identity<-` <- function(x, value) {
    meta <- screen_meta(x)
    meta$identity <- value
    screen_meta(x) <- meta
    x
}
screen_low_moi <- function(x) screen_meta(x)$low_moi
`screen_low_moi<-` <- function(x, value) {
    meta <- screen_meta(x)
    meta$low_moi <- value
    screen_meta(x) <- meta
    x
}
screen_guide_summary <- function(x) {
    as.list(SummarizedExperiment::colData(screen_guides(x)))
}
`screen_guide_summary<-` <- function(x, value) {
    if (
        (length(value) && is.null(names(value))) ||
            anyNA(names(value)) ||
            !all(names(value) %in% c("max_grna", "max_grna_frac_umis")) ||
            anyDuplicated(names(value))
    ) {
        stop("Unknown or repeated guide summary field")
    }
    if (any(lengths(value) != ncol(x))) {
        stop("Guide summaries must match source cells")
    }
    guide <- screen_guides(x)
    cd <- S4Vectors::make_zero_col_DFrame(ncol(x))
    rownames(cd) <- colnames(x)
    for (name in names(value)) {
        cd[[name]] <- value[[name]]
    }
    SummarizedExperiment::colData(guide) <- cd
    SingleCellExperiment::altExp(x, "gRNA") <- guide
    x
}

new_screen_experiment <- function(
    response_matrix = NULL,
    grna_matrix = NULL,
    covariate_data_frame = data.frame(),
    grna_target_data_frame = data.frame(),
    response_names = character(),
    low_moi = logical(),
    import_grna_assignment_info = list(),
    identity = character()
) {
    empty <- function(n, cells) {
        m <- matrix(numeric(), 0L, n, dimnames = list(NULL, cells))
        DelayedArray::DelayedArray(m)
    }
    if (is.null(response_matrix)) {
        response_matrix <- empty(
            if (is.null(grna_matrix)) 0L else ncol(grna_matrix),
            if (is.null(grna_matrix)) NULL else colnames(grna_matrix)
        )
    }
    if (is.null(grna_matrix)) {
        grna_matrix <- empty(ncol(response_matrix), colnames(response_matrix))
    }
    response_matrix <- DelayedArray::DelayedArray(response_matrix)
    grna_matrix <- DelayedArray::DelayedArray(grna_matrix)
    if (
        ncol(response_matrix) != ncol(grna_matrix) ||
            (!is.null(colnames(response_matrix)) &&
                !is.null(colnames(grna_matrix)) &&
                !identical(colnames(response_matrix), colnames(grna_matrix)))
    ) {
        stop("Modality cell order differs")
    }
    cells <- colnames(response_matrix)
    if (is.null(cells)) {
        cells <- colnames(grna_matrix)
    }
    covariates <- S4Vectors::DataFrame(
        covariate_data_frame,
        check.names = FALSE
    )
    if (!nrow(covariates) && !ncol(covariates)) {
        covariates <- S4Vectors::make_zero_col_DFrame(ncol(response_matrix))
    }
    if (nrow(covariates) != ncol(response_matrix)) {
        stop("Cell covariates must match source cells")
    }
    rownames(covariates) <- cells
    x <- SingleCellExperiment::SingleCellExperiment(
        assays = list(counts = response_matrix),
        colData = covariates,
        metadata = list(
            sceptre = list(
                layout = 2L,
                identity = identity,
                low_moi = low_moi
            )
        )
    )
    guide <- SummarizedExperiment::SummarizedExperiment(
        assays = list(counts = grna_matrix)
    )
    SingleCellExperiment::altExp(x, "gRNA") <- guide
    screen_response_names(x) <- response_names
    screen_guide_annotations(x) <- grna_target_data_frame
    # Old uninitialized imports can name an absent (zero-length) summary.
    import_grna_assignment_info <- import_grna_assignment_info[
        lengths(import_grna_assignment_info) > 0L | ncol(x) == 0L
    ]
    screen_guide_summary(x) <- import_grna_assignment_info
    x
}

#' Extract the canonical SingleCellExperiment from a sceptre analysis
#' @param sceptre_object A sceptre analysis object.
#' @return Its experimental data as an ordinary SingleCellExperiment. Counts
#' remain backed; analysis preparation, fits and results are not embedded in it.
#' @examples
#' response <- matrix(c(1, 0, 2, 3, 1, 0), nrow = 2,
#'     dimnames = list(c("gene1", "gene2"), c("cell1", "cell2", "cell3")))
#' guides <- matrix(c(1, 0, 2), nrow = 1,
#'     dimnames = list("guide1", colnames(response)))
#' annotation <- data.frame(grna_id = "guide1", grna_target = "target1")
#' object <- import_data(response, guides, annotation, moi = "low")
#' sce <- get_screen_experiment(object)
#' stopifnot(identical(colnames(sce), colnames(response)))
#' SummarizedExperiment::assay(sce, "counts")
#' @export
get_screen_experiment <- function(sceptre_object) {
    sceptre_object <- migrate_sceptre_object(sceptre_object)
    sceptre_object@data
}

validate_screen_experiment <- function(x) {
    valid <- methods::validObject(x, test = TRUE)
    if (!isTRUE(valid)) {
        return(valid)
    }
    if (
        !"counts" %in% SummarizedExperiment::assayNames(x) ||
            !"gRNA" %in% SingleCellExperiment::altExpNames(x)
    ) {
        return("Screen experiment requires response counts and gRNA altExp")
    }
    guide <- screen_guides(x)
    if (
        !"counts" %in% SummarizedExperiment::assayNames(guide) ||
            !methods::is(screen_response_counts(x), "DelayedMatrix") ||
            !methods::is(screen_guide_counts(x), "DelayedMatrix")
    ) {
        return(
            "Screen experiment counts must be ordinary DelayedMatrix objects"
        )
    }
    meta <- screen_meta(x)
    if (
        !is.list(meta) ||
            !identical(meta$layout, 2L) ||
            !is.character(meta$identity) ||
            length(meta$identity) > 1L ||
            anyNA(meta$identity) ||
            !is.logical(meta$low_moi) ||
            length(meta$low_moi) > 1L ||
            anyNA(meta$low_moi) ||
            any(c("covariate_names", "guide_summary_columns") %in% names(meta))
    ) {
        return("Invalid native screen metadata")
    }
    summaries <- SummarizedExperiment::colData(guide)
    if (
        !all(names(summaries) %in% c("max_grna", "max_grna_frac_umis")) ||
            anyDuplicated(names(summaries))
    ) {
        return("Invalid guide cell-summary columns")
    }
    annotations <- SummarizedExperiment::rowData(guide)
    order <- S4Vectors::metadata(guide)$sceptre$annotation_order
    if (
        !all(c("grna_id", "grna_target") %in% names(annotations)) ||
            !is.character(order) ||
            anyNA(order) ||
            anyDuplicated(order)
    ) {
        return("Invalid guide rowData annotation order")
    }
    active <- !is.na(annotations$grna_target)
    if (
        anyNA(annotations$grna_id[active]) ||
            anyDuplicated(annotations$grna_id[active]) ||
            !identical(
                as.character(annotations$grna_id[active]),
                as.character(rownames(guide)[active])
            ) ||
            !setequal(
                as.character(annotations$grna_id[active]),
                order[order %in% rownames(guide)]
            )
    ) {
        return("Guide rowData must map one target per annotated count row")
    }
    TRUE
}
