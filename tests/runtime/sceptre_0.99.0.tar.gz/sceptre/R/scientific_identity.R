# Version-two scientific certificates encode values, not table allocation.
# Order, column/vector types, factor levels and meaningful array metadata remain
# inputs. data.frame/data.table subclasses, row-name encodings and self-reference
# pointers do not change a hypothesis family. Runtime/build certificates remain
# separate and intentionally bind implementation bytes.
scientific_value <- function(x) {
    if (methods::is(x, "RunPlan")) {
        return(scientific_value(run_plan_payload(x, include_identity = TRUE)))
    }
    if (inherits(x, "formula")) {
        return(identity_value(x))
    }
    if (is.data.frame(x)) {
        return(list(
            table = stats::setNames(lapply(x, scientific_value), names(x)),
            nrow = nrow(x)
        ))
    }
    if (is.list(x) && !isS4(x)) {
        meta <- attributes(x)
        meta$names <- NULL
        if (length(meta)) {
            meta <- meta[sort(names(meta), method = "radix")]
        }
        return(list(
            values = stats::setNames(lapply(x, scientific_value), names(x)),
            metadata = lapply(meta, scientific_value)
        ))
    }
    if (is.atomic(x) && !isS4(x)) {
        meta <- attributes(x)
        # Attribute order and compact/ALTREP allocation are incidental. Retain
        # the attribute values themselves (factor levels, names, dimensions...).
        if (length(meta)) {
            meta <- meta[sort(names(meta), method = "radix")]
        }
        values <- c(unclass(x))
        attributes(values) <- NULL
        return(list(type = typeof(x), values = values, metadata = meta))
    }
    x
}
scientific_digest <- function(value) {
    digest::digest(scientific_value(value), algo = "sha256")
}
run_plan_version <- function(plan) {
    identity <- if (methods::is(plan, "RunPlan")) {
        plan@identity
    } else {
        plan$identity
    }
    if (is.null(identity$protocol)) 1L else identity$protocol
}
run_plan_policy <- function(plan) {
    identity <- if (methods::is(plan, "RunPlan")) {
        plan@identity
    } else {
        plan$identity
    }
    if (identical(run_plan_version(plan), 2L)) identity$policy else NULL
}
run_plan_digest <- function(plan) {
    payload <- run_plan_payload(plan)
    if (identical(run_plan_version(plan), 2L)) {
        scientific_digest(payload)
    } else {
        digest::digest(payload, algo = "sha256")
    }
}
run_pairs_identical <- function(a, b, plan) {
    if (identical(run_plan_version(plan), 2L)) {
        identical(scientific_value(a), scientific_value(b))
    } else {
        identical(a, b)
    }
}
