# Native count backing: file/view descriptors, data-version anchors and relocation.
# These functions operate on ordinary DelayedMatrix values, never saved readers.
# HDF5Array seeds contain file locations and dataset metadata, not live readers.
# Visit seeds without fetching values, including delayed subset/transpose views.
count_backing_paths <- function(x) {
    if (!methods::is(x, "DelayedMatrix")) {
        return(character())
    }
    paths <- DelayedArray::seedApply(x, function(seed) {
        if (isS4(seed) && "filepath" %in% methods::slotNames(seed)) {
            return(as.character(methods::slot(seed, "filepath")))
        }
        character()
    })
    unique(unlist(paths, use.names = FALSE))
}

count_matrix_is_backed <- function(x) length(count_backing_paths(x)) > 0L

# Describe the delayed view itself, replacing locations with content hashes.
# Dataset selection, row/column permutations and labels remain part of identity.
# No numerical realization is performed. Ordinary Matrix payloads are left as
# their existing vectors, to be hashed once at the import boundary.
count_backing_metadata <- function(x, hashes) {
    if (isS4(x)) {
        fields <- methods::slotNames(x)
        values <- lapply(fields, function(field) {
            value <- methods::slot(x, field)
            if (field == "filepath") {
                normalized <- normalizePath(
                    as.character(value),
                    mustWork = TRUE
                )
                return(unname(hashes[normalized]))
            }
            count_backing_metadata(value, hashes)
        })
        return(list(class = class(x), slots = stats::setNames(values, fields)))
    }
    if (is.list(x)) {
        return(lapply(x, count_backing_metadata, hashes = hashes))
    }
    if (typeof(x) %in% c("externalptr", "environment")) {
        stop("Count matrix metadata cannot contain a process-local handle.")
    }
    x
}

count_backing_descriptor <- function(x) {
    paths <- count_backing_paths(x)
    if (!length(paths)) {
        return(NULL)
    }
    paths <- vapply(paths, normalizePath, character(1), mustWork = TRUE)
    hashes <- tools::md5sum(paths)
    if (anyNA(hashes)) {
        stop("Cannot verify native count backing files.")
    }
    list(
        files = data.frame(path = unname(paths), content_md5 = unname(hashes)),
        content_md5 = digest::digest(
            count_backing_metadata(x, hashes),
            algo = "md5"
        ),
        dimensions = as.integer(dim(x)),
        dimnames = dimnames(x)
    )
}


# An opaque immutable dataset-version token, not a content fingerprint.
# OpenSSL uses its maintained OS-seeded random generator, independently of R's
# scientific RNG. Fail on entropy errors; never fall back to .Random.seed.
new_screen_version_id <- function() {
    paste0(
        "dataset-v1-",
        paste(as.character(openssl::rand_bytes(16L)), collapse = "")
    )
}

# Central import/explicit replacement boundary: create a new data version even
# for equal contents. Current-schema read/migration and persistence do not call
# this renewer. Old schema-one/two conversion creates one new current-object
# version; writing that converted object preserves it on all later reads.
initialize_screen_identity <- function(object) {
    anchors <- lapply(
        screen_count_matrices(object@data),
        count_backing_descriptor
    )
    screen_identity(object@data) <- new_screen_version_id()
    # Content/backing verification is separate from cache version identity.
    screen_backing_anchors(object@data) <- anchors
    object
}

validate_count_backing <- function(store, descriptor) {
    if (is.null(descriptor)) {
        stop(
            "Backing store has no anchored content descriptor; reimport the screen."
        )
    }
    actual <- count_backing_descriptor(store)
    keys <- c("content_md5", "dimensions", "dimnames")
    if (is.null(actual) || !identical(actual[keys], descriptor[keys])) {
        stop(
            "Backing store content does not match the saved descriptor; cached analyses cannot be reused."
        )
    }
    invisible(NULL)
}

# Verify existing anchors rather than treating edited files as a new baseline.
validate_count_backing_for_save <- function(object) {
    for (modality in c("response", "grna")) {
        matrix <- screen_count_matrices(object@data)[[modality]]
        if (count_matrix_is_backed(matrix)) {
            validate_count_backing(
                matrix,
                screen_backing_anchors(object@data)[[modality]]
            )
        }
    }
    invisible(NULL)
}


# Replace file locations without rebuilding the saved delayed operation tree.
# H5SparseMatrixSeed's public path<- method does not support relocation. The
# exported tree walker preserves all views while this narrow clone changes only
# known HDF5 metadata. read_sceptre_object verifies exact file/view anchors before
# returning the replacement; no count extraction occurs here.
relocate_native_count_files <- function(matrix, paths, arg_name) {
    original <- count_backing_paths(matrix)
    if (!length(original)) {
        stop("The saved modality has no native HDF5 backing files.")
    }
    if (
        !is.character(paths) ||
            length(paths) != length(original) ||
            anyNA(paths)
    ) {
        stop(
            arg_name,
            " must supply one path per distinct saved backing file, in saved order."
        )
    }
    replacements <- vapply(
        paths,
        normalize_existing_file_path,
        character(1),
        arg_name = arg_name,
        USE.NAMES = FALSE
    )
    DelayedArray::modify_seeds(matrix, function(seed) {
        if (!(isS4(seed) && "filepath" %in% methods::slotNames(seed))) {
            return(seed)
        }
        if (
            !(methods::is(seed, "H5SparseMatrixSeed") ||
                methods::is(seed, "HDF5ArraySeed"))
        ) {
            stop("Relocation requires a supported native HDF5 seed.")
        }
        index <- match(as.character(methods::slot(seed, "filepath")), original)
        if (length(index) != 1L || is.na(index)) {
            stop("Native backing file does not match the saved file mapping.")
        }
        methods::slot(seed, "filepath") <- replacements[[index]]
        seed
    })
}

#' Expand and check an existing object or count-file path
#' @param file_path One nonmissing path that must already exist.
#' @param arg_name Argument name used in error messages.
#' @return Absolute path with forward slashes and the home-directory
#'   abbreviation
#'   expanded. Reject remaining ~ characters. Do not open or modify the file.
#' @noRd
normalize_existing_file_path <- function(file_path, arg_name) {
    if (is.null(file_path)) {
        stop(arg_name, " must be supplied.")
    }
    if (
        !(is.character(file_path) &&
            length(file_path) == 1L &&
            !is.na(file_path))
    ) {
        stop(arg_name, " must be a single file path.")
    }
    file_path <- normalizePath(
        path.expand(file_path),
        winslash = "/",
        mustWork = TRUE
    )
    check_path_has_no_tilde(file_path, arg_name)
    return(file_path)
}
