#' Import complete raw counts from a SingleCellExperiment
#'
#' Import response counts and one guide alternative experiment without changing
#' their feature or cell order. Supported native backed assays remain backed.
#' Cell covariates are calculated from all supplied features before SCEPTRE QC.
#' Supply the complete raw libraries; features removed upstream cannot be
#' recovered, and normalized assays must not be substituted for raw counts.
#'
#' @param sce A SingleCellExperiment containing complete raw response counts.
#' @param grna_target_data_frame Guide metadata with grna_id in complete guide
#'   assay row order. May include vector_id for aggregation during import.
#' @param moi Either `"low"` or `"high"`.
#' @param response_assay,grna_assay Raw count assay names; default `"counts"`.
#' @param grna_alt_exp Name of the guide alternative experiment.
#' @param covariates Names of colData fields to include as extra covariates.
#' @param response_name_column Optional response rowData field of gene symbols
#'   used to identify mitochondrial genes. Otherwise use response row names.
#' @param directory_to_write Explicit directory for new standard HDF5 counts
#'   when vector_id aggregation is requested for file-backed guides. Native
#'   assays with RAM seeds aggregate in memory and require no directory.
#' @return An imported sceptre_object. The supplied SCE is unchanged.
#' @examples
#' response <- matrix(c(1, 0, 2, 3, 1, 0), nrow = 2,
#'     dimnames = list(c("gene1", "gene2"), c("cell1", "cell2", "cell3")))
#' guides <- matrix(c(1, 0, 2), nrow = 1,
#'     dimnames = list("guide1", colnames(response)))
#' annotation <- data.frame(grna_id = "guide1", grna_target = "target1")
#' sce <- SingleCellExperiment::SingleCellExperiment(list(counts = response))
#' SingleCellExperiment::altExp(sce, "gRNA") <-
#'     SingleCellExperiment::SingleCellExperiment(list(counts = guides))
#' object <- import_from_sce(sce, annotation, moi = "low")
#' stopifnot(identical(colnames(get_screen_experiment(object)), colnames(sce)))
#' @export
import_from_sce <- function(
    sce,
    grna_target_data_frame,
    moi,
    response_assay = "counts",
    grna_alt_exp = "gRNA",
    grna_assay = "counts",
    covariates = character(),
    response_name_column = NULL,
    directory_to_write = NULL
) {
    if (
        !requireNamespace("SingleCellExperiment", quietly = TRUE) ||
            !requireNamespace("SummarizedExperiment", quietly = TRUE)
    ) {
        stop(
            "SCE import requires SingleCellExperiment and SummarizedExperiment."
        )
    }
    if (!methods::is(sce, "SingleCellExperiment")) {
        stop("`sce` must be a SingleCellExperiment.")
    }
    if (
        !is.character(grna_alt_exp) ||
            length(grna_alt_exp) != 1L ||
            is.na(grna_alt_exp) ||
            !grna_alt_exp %in% SingleCellExperiment::altExpNames(sce)
    ) {
        stop("The guide alternative experiment is missing.")
    }
    guides <- SingleCellExperiment::altExp(
        sce,
        grna_alt_exp,
        withDimnames = FALSE
    )
    # Alternative experiments share the parent's cell axis. An SCE can validly
    # store that axis only on the parent; retain checks on any explicit labels.
    if (is.null(colnames(guides))) {
        colnames(guides) <- colnames(sce)
    }
    response <- standard_sce_raw_assay(sce, response_assay)
    grna <- standard_sce_raw_assay(guides, grna_assay)
    if (!identical(colnames(response), colnames(grna))) {
        stop("Response and guide cell IDs must match exactly and in order.")
    }
    if (
        !is.data.frame(grna_target_data_frame) ||
            !identical(
                as.character(grna_target_data_frame$grna_id),
                rownames(grna)
            )
    ) {
        stop(
            "Guide metadata grna_id must match all guide rows exactly in order."
        )
    }
    cd <- SummarizedExperiment::colData(sce)
    if (
        !is.character(covariates) ||
            anyNA(covariates) ||
            anyDuplicated(covariates) ||
            !all(covariates %in% colnames(cd))
    ) {
        stop("`covariates` must name distinct colData fields.")
    }
    extra <- as.data.frame(cd[, covariates, drop = FALSE])
    if (!length(covariates)) {
        extra <- data.frame()
    }
    symbols <- NA_character_
    if (!is.null(response_name_column)) {
        rd <- SummarizedExperiment::rowData(sce)
        if (
            !is.character(response_name_column) ||
                length(response_name_column) != 1L ||
                is.na(response_name_column) ||
                !response_name_column %in% colnames(rd)
        ) {
            stop("`response_name_column` must name one response rowData field.")
        }
        symbols <- as.character(rd[[response_name_column]])
        if (anyNA(symbols)) {
            stop("Response feature symbols must not be missing.")
        }
    }
    import_data(
        response,
        grna,
        grna_target_data_frame,
        moi,
        extra_covariates = extra,
        response_names = symbols,
        directory_to_write = directory_to_write
    )
}

#' Validate assay labels without realizing backed count data
#' @param experiment SummarizedExperiment containing a raw count assay.
#' @param assay_name Name of that assay.
#' @return Assay with exact feature/cell labels, retaining its storage backend.
#' @noRd
standard_sce_raw_assay <- function(experiment, assay_name) {
    if (
        !is.character(assay_name) ||
            length(assay_name) != 1L ||
            is.na(assay_name) ||
            !assay_name %in% SummarizedExperiment::assayNames(experiment)
    ) {
        stop("A requested raw count assay is missing.")
    }
    raw <- SummarizedExperiment::assay(
        experiment,
        assay_name,
        withDimnames = FALSE
    )
    for (axis in seq_len(length(dim(experiment)))) {
        ids <- dimnames(experiment)[[axis]]
        if (
            is.null(ids) ||
                length(ids) != dim(experiment)[axis] ||
                anyNA(ids) ||
                any(!nzchar(ids)) ||
                anyDuplicated(ids)
        ) {
            stop(
                "SCE feature and cell IDs must be present, nonempty and unique."
            )
        }
        stored <- dimnames(raw)[[axis]]
        if (!is.null(stored) && !identical(stored, ids)) {
            stop("Stored assay labels conflict with SCE feature or cell IDs.")
        }
    }
    SummarizedExperiment::assay(experiment, assay_name)
}
