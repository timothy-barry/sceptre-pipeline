#' Import 10x counts into standard feature-oriented HDF5 storage
#'
#' Read Cell Ranger Matrix Market directories or feature-barcode HDF5 files
#' using DropletUtils. Process one input sample at a time and write standard
#' sparse HDF5 counts with physically contiguous features, retaining file feature
#' order, raw UMI counts, stored zeros, and cell barcodes. No ondisc calls are
#' made. Each sample is stored once; gene and guide matrices are ordinary row
#' views of that shared immutable backing. All stored counts must be finite
#' nonnegative integer UMIs. Gene and guide covariates use the complete supplied
#' libraries; guide vector aggregation precedes guide covariates, as in import_data().
#'
#' @param samples Paths to Cell Ranger directories or count-matrix HDF5 files.
#'   Directories must contain standard feature and matrix files. Barcode files
#'   must be supplied for every sample or none; missing barcodes remain unnamed.
#'   All samples must have the same feature IDs, symbols, types, and row order.
#' @param moi Either `"low"` or `"high"`.
#' @param grna_target_data_frame Guide metadata as in [import_data()].
#' @param directory_to_write Directory for new backing files. Each call creates
#'   its own subdirectory; existing files are never overwritten. Keep that
#'   subdirectory with the returned object.
#' @param extra_covariates Optional cell covariates in concatenated sample order.
#'   Supplied row names must match the retained cell IDs. With multiple samples,
#'   cell IDs are prefixed `b1_`, `b2_`, etc., and the batch covariate is set to
#'   the corresponding sample index, matching import_data_from_cellranger().
#' @param block_rows Positive integer number of features per native fallback
#'   block when concatenating samples or writing complex sparse views. The
#'   maintained writer controls its own block grid for plain single inputs.
#'   Matrix Market parsing still loads one sparse sample into memory, using
#'   integer storage for integer input when supported. HDF5 inputs remain
#'   backed.
#'   This is not a constant-memory text parser.
#' @param compression_level Integer HDF5 compression level from 0 to 9; the
#'   default 3 balances file size and import time without changing global
#'   settings.
#' @return An initialized sceptre_object with standard sparse backed counts.
#' @examples
#' response <- matrix(c(1L, 0L, 2L, 3L, 1L, 0L), nrow = 2,
#'     dimnames = list(c("gene1", "gene2"), c("cell1", "cell2", "cell3")))
#' guides <- matrix(c(1, 0, 2), nrow = 1,
#'     dimnames = list("guide1", colnames(response)))
#' annotation <- data.frame(grna_id = "guide1", grna_target = "target1")
#' local({
#'     directory <- tempfile("sceptre-10x-example-")
#'     dir.create(directory)
#'     on.exit(unlink(directory, recursive = TRUE))
#'     input <- file.path(directory, "input")
#'     DropletUtils::write10xCounts(
#'         input, Matrix::Matrix(rbind(response, guides), sparse = TRUE),
#'         version = "3", type = "mtx",
#'         gene.id = c(rownames(response), rownames(guides)),
#'         gene.symbol = c(rownames(response), rownames(guides)),
#'         gene.type = c(rep("Gene Expression", 2), "CRISPR Guide Capture")
#'     )
#'     object <- import_data_from_10x(
#'         input, "low", annotation, file.path(directory, "backing")
#'     )
#'     counts <- SummarizedExperiment::assay(get_screen_experiment(object))
#'     stopifnot(identical(as.matrix(counts), response))
#' })
#' @export
import_data_from_10x <- function(
    samples,
    moi,
    grna_target_data_frame,
    directory_to_write,
    extra_covariates = data.frame(),
    block_rows = 32L,
    compression_level = 3L
) {
    if (!requireNamespace("DropletUtils", quietly = TRUE)) {
        stop("10x import requires the DropletUtils package.")
    }
    if (
        !is.character(samples) ||
            !length(samples) ||
            anyNA(samples) ||
            any(!file.exists(samples))
    ) {
        stop(
            "`samples` must name existing Cell Ranger directories or HDF5 files."
        )
    }
    if (
        length(block_rows) != 1L ||
            is.na(block_rows) ||
            !is.finite(block_rows) ||
            block_rows < 1 ||
            block_rows != floor(block_rows) ||
            block_rows > .Machine$integer.max
    ) {
        stop(
            "`block_rows` must be a positive integer within coordinate capacity."
        )
    }
    if (
        length(compression_level) != 1L || is.na(compression_level) ||
            !is.finite(compression_level) || compression_level < 0 ||
            compression_level > 9 || compression_level != floor(compression_level)
    ) {
        stop("`compression_level` must be an integer from 0 to 9.")
    }
    if (length(moi) != 1L || is.na(moi) || !moi %in% c("low", "high")) {
        stop("`moi` must be low or high.")
    }
    directory_to_write <- prepare_directory_to_write(directory_to_write)
    owned <- tempfile("tenx-", tmpdir = directory_to_write)
    if (!dir.create(owned)) {
        stop("Could not create 10x import directory.")
    }
    complete <- FALSE
    on.exit(if (!complete) unlink(owned, recursive = TRUE), add = TRUE)
    prepared <- tenx_prepare_samples(samples, owned)
    batches <- vector("list", length(samples))
    reference <- NULL
    for (i in seq_along(samples)) {
        message("Reading 10x sample ", i, " of ", length(samples), ".")
        arguments <- list(samples = prepared$paths[i], col.names = TRUE)
        if ("mtx.two.pass" %in% names(formals(DropletUtils::read10xCounts))) {
            arguments$mtx.two.pass <- TRUE
        }
        if ("mtx.class" %in% names(formals(DropletUtils::read10xCounts))) {
            # Integer Matrix Market input remains integer-valued in the SVT
            # representation instead of allocating a full double count vector.
            arguments$mtx.class <- "SVT_SparseMatrix"
        }
        sce <- do.call(DropletUtils::read10xCounts, arguments)
        feature <- as.data.frame(SummarizedExperiment::rowData(sce))
        if (!all(c("ID", "Symbol", "Type") %in% names(feature))) {
            stop(
                "10x input must describe Gene Expression and CRISPR Guide Capture features."
            )
        }
        feature <- feature[, c("ID", "Symbol", "Type"), drop = FALSE]
        feature[] <- lapply(feature, as.character)
        rownames(feature) <- NULL
        if (anyNA(feature)) {
            stop("10x feature metadata must not contain missing values.")
        }
        if (is.null(reference)) {
            reference <- feature
        }
        if (!identical(reference, feature)) {
            stop(
                "Feature IDs, symbols, types, and row order must match across samples."
            )
        }
        cells <- if (prepared$barcodes) colnames(sce) else NULL
        if (
            prepared$barcodes &&
                (is.null(cells) ||
                    anyNA(cells) ||
                    any(!nzchar(cells)) ||
                    anyDuplicated(cells))
        ) {
            stop("10x samples must have nonempty unique cell barcodes.")
        }
        if (length(samples) > 1L && !is.null(cells)) {
            cells <- paste0("b", i, "_", cells)
        }
        counts <- SummarizedExperiment::assay(sce, "counts")
        rm(sce)
        # Validate the parser's original entries before any transpose/coercion
        # could normalize duplicate coordinates or invalid count values.
        storage_prepare_standard_matrix(DelayedArray::DelayedArray(counts))
        if (methods::is(counts, "SVT_SparseMatrix")) {
            # SVT leaves are columns. Transpose once physically, then expose a
            # lazy transpose so feature reads follow the stored leaves.
            counts <- t(DelayedArray::DelayedArray(t(counts)))
        } else if (methods::is(counts, "sparseMatrix")) {
            counts <- DelayedArray::DelayedArray(methods::as(counts, "RsparseMatrix"))
        } else {
            # HDF5 input remains backed; do not realize it to reorient counts.
            counts <- DelayedArray::DelayedArray(counts)
        }
        colnames(counts) <- cells
        # The original parser representation is no longer reachable. Release
        # its memory before writing, rather than retaining it via the SCE and
        # constructing separate full-size sparse gene/guide copies.
        gc(FALSE)
        full <- tenx_write_feature_major(
            list(counts),
            file.path(owned, paste0("batch-", i, "-counts.h5")),
            as.integer(block_rows),
            level = as.integer(compression_level)
        )
        batch <- list(cells = cells, n_cells = ncol(counts))
        for (modality in c("Gene Expression", "CRISPR Guide Capture")) {
            rows <- which(feature$Type == modality)
            if (!length(rows)) {
                stop("10x sample is missing modality: ", modality, ".")
            }
            ids <- feature$ID[rows]
            if (any(!nzchar(ids)) || anyDuplicated(ids)) {
                stop(
                    "10x feature IDs must be nonempty and unique within each modality."
                )
            }
            # Both modalities are views of one immutable sample file. Keep
            # file feature order without extracting separate in-memory copies.
            matrix <- full[rows, , drop = FALSE]
            rownames(matrix) <- ids
            name <- if (modality == "Gene Expression") "response" else "guide"
            batch[[name]] <- matrix
        }
        batches[[i]] <- batch
        rm(counts, full, matrix, batch)
    }
    cells <- if (prepared$barcodes) {
        unlist(lapply(batches, `[[`, "cells"), use.names = FALSE)
    } else {
        NULL
    }
    n_cells <- sum(vapply(batches, `[[`, integer(1), "n_cells"))
    if (
        !is.data.frame(extra_covariates) ||
            !nrow(extra_covariates) %in% c(0L, n_cells)
    ) {
        stop(
            "Extra covariates must be a data frame with one row per cell, or empty."
        )
    }
    if (
        !is.null(cells) &&
            nrow(extra_covariates) &&
            .row_names_info(extra_covariates, 1L) > 0L &&
            !identical(rownames(extra_covariates), cells)
    ) {
        stop(
            "Extra covariate row names must match the imported cell IDs in order."
        )
    }
    if (length(samples) > 1L) {
        batch <- factor(rep(
            paste0("b", seq_along(samples)),
            vapply(batches, `[[`, integer(1), "n_cells")
        ))
        if (!nrow(extra_covariates)) {
            extra_covariates <- data.frame(
                row.names = if (is.null(cells)) seq_len(n_cells) else cells
            )
        }
        extra_covariates$batch <- batch
    }
    stores <- lapply(c("response", "guide"), function(name) {
        parts <- lapply(batches, `[[`, name)
        if (length(parts) == 1L) {
            return(parts[[1L]])
        }
        tenx_write_feature_major(
            parts,
            file.path(owned, paste0(name, ".h5")),
            as.integer(block_rows),
            level = as.integer(compression_level)
        )
    })
    result <- import_data(
        response_matrix = stores[[1L]],
        grna_matrix = stores[[2L]],
        grna_target_data_frame = grna_target_data_frame,
        moi = moi,
        extra_covariates = extra_covariates,
        response_names = reference$Symbol[reference$Type == "Gene Expression"],
        directory_to_write = owned
    )
    if (length(samples) > 1L) {
        unlink(file.path(
            owned,
            paste0("batch-", seq_along(samples), "-counts.h5")
        ))
    }
    unlink(prepared$staged, recursive = TRUE)
    complete <- TRUE
    result
}

# DropletUtils requires barcode files. For the established barcode-free MTX
# interface, stage read-only links plus temporary position labels, then discard
# these labels immediately after parsing. Source files are never edited.
tenx_prepare_samples <- function(samples, owned) {
    present <- vapply(
        samples,
        function(path) {
            if (!dir.exists(path)) {
                return(TRUE)
            }
            files <- list.files(path, pattern = "^barcodes\\.tsv(\\.gz)?$")
            if (length(files) > 1L) {
                stop("10x directory has multiple barcode files.")
            }
            length(files) == 1L
        },
        logical(1)
    )
    if (any(present) && !all(present)) {
        stop(
            "Barcode files must either be present in every input sample or absent from every input sample."
        )
    }
    paths <- samples
    staged <- character()
    if (!any(present)) {
        for (i in seq_along(samples)) {
            directory <- file.path(owned, paste0("source-", i))
            dir.create(directory)
            staged <- c(staged, directory)
            files <- list.files(
                samples[i],
                pattern = "^(features\\.tsv|genes\\.tsv|matrix\\.mtx)(\\.gz)?$",
                full.names = TRUE
            )
            for (file in files) {
                target <- file.path(directory, basename(file))
                if (
                    !file.symlink(normalizePath(file), target) &&
                        !file.copy(file, target)
                ) {
                    stop("Could not stage barcode-free 10x input.")
                }
            }
            matrix <- files[grepl("matrix\\.mtx(\\.gz)?$", files)]
            if (length(matrix) != 1L) {
                stop("10x directory must contain exactly one count matrix.")
            }
            writeLines(
                as.character(seq_len(get_mtx_metadata(matrix)$n_cells)),
                file.path(directory, "barcodes.tsv")
            )
            paths[i] <- directory
        }
    }
    list(paths = paths, staged = staged, barcodes = all(present))
}

# Keep physical feature order while concatenating batches along the cell axis.
# HDF5Array owns the sparse output format; beachmat owns input extraction.
tenx_write_feature_major <- function(parts, path, block_rows, level = NULL) {
    n_features <- nrow(parts[[1L]])
    n_cells <- sum(vapply(parts, ncol, integer(1)))
    if (!n_features || !n_cells || n_cells > .Machine$integer.max) {
        stop(
            "10x import requires nonempty dimensions within native coordinate capacity."
        )
    }
    # The maintained writer preserves stored zeros on qualified in-memory seeds and
    # transposition/dimname wrappers. Its sparse extraction can normalize zeros
    # on reordered/repeated subsets and fails on some combined sparse trees.
    # Keep those inputs on the exact bounded native-coordinate path below.
    if (length(parts) == 1L && tenx_whole_writer_supported(parts[[1L]])) {
        storage_prepare_standard_matrix(parts[[1L]])
        out <- t(HDF5Array::writeTENxMatrix(
            t(parts[[1L]]), filepath = path, group = "counts", level = level,
            verbose = FALSE
        ))
        dimnames(out) <- dimnames(parts[[1L]])
        return(out)
    }
    cells <- unlist(lapply(parts, colnames), use.names = FALSE)
    sink <- HDF5Array::TENxRealizationSink(
        c(n_cells, n_features),
        dimnames = list(cells, rownames(parts[[1L]])),
        type = "double",
        filepath = path,
        group = "counts",
        level = level
    )
    # close(sink) validates a complete output; it cannot finalize partial data.
    # On failure the public importer removes its owned output directory after
    # the native input handles below are released by this function's on.exit.
    handles <- list()
    on.exit(
        for (handle in handles) {
            standard_matrix_release_cpp(handle)
        },
        add = TRUE
    )
    for (part in parts) {
        handles[[length(handles) + 1L]] <- storage_standard_handle(part)
    }
    offsets <- c(0L, head(cumsum(vapply(parts, ncol, integer(1))), -1L))
    for (start in seq.int(1L, n_features, by = block_rows)) {
        size <- min(block_rows, n_features - start + 1L)
        if (length(handles) == 1L) {
            # Native extraction already emits features in order and canonical
            # cells within each feature. Avoid zero offsets, concatenation,
            # sorting and three indexed copies for this common case.
            coordinates <- tenx_import_block_cpp(handles[[1L]], start, size)
            block <- SparseArray::COO_SparseArray(
                dim = c(n_cells, size),
                nzcoo = cbind(coordinates$cell, coordinates$feature),
                nzdata = coordinates$value
            )
        } else {
            blocks <- lapply(seq_along(handles), function(i) {
                block <- tenx_import_block_cpp(handles[[i]], start, size)
                block$cell <- as.integer(block$cell + offsets[i])
                block
            })
            if (
                sum(vapply(
                    blocks,
                    function(block) length(block$value),
                    numeric(1)
                )) >
                    .Machine$integer.max
            ) {
                stop(
                    "10x import block exceeds coordinate capacity; reduce block_rows."
                )
            }
            value <- unlist(lapply(blocks, `[[`, "value"), use.names = FALSE)
            cell <- unlist(lapply(blocks, `[[`, "cell"), use.names = FALSE)
            feature <- unlist(
                lapply(blocks, `[[`, "feature"),
                use.names = FALSE
            )
            order <- order(feature, cell, method = "radix")
            block <- SparseArray::COO_SparseArray(
                dim = c(n_cells, size),
                nzcoo = cbind(cell[order], feature[order]),
                nzdata = value[order]
            )
        }
        viewport <- S4Arrays::ArrayViewport(
            c(n_cells, n_features),
            IRanges::IRanges(start = c(1L, start), width = c(n_cells, size))
        )
        sink <- DelayedArray::write_block(sink, viewport, block)
    }
    HDF5Array::close(sink)
    t(methods::as(sink, "TENxMatrix"))
}

# Subsets and concatenation use the exact native-coordinate fallback. Restrict
# the maintained whole-input path to memory trees qualified for stored zeros.
# HDF5 sparse extraction can drop explicit zeros, so backed inputs stay bounded.
tenx_whole_writer_supported <- function(matrix) {
    inspect <- function(node, depth = 0L) {
        if (depth > 128L) return(FALSE)
        if (methods::is(node, "DelayedMatrix")) {
            return(inspect(methods::slot(node, "seed"), depth + 1L))
        }
        if (methods::is(node, "DelayedAperm") || methods::is(node, "DelayedSetDimnames")) {
            return(inspect(methods::slot(node, "seed"), depth + 1L))
        }
        any(vapply(
            c("dgRMatrix", "SVT_SparseMatrix"),
            function(cl) methods::is(node, cl),
            logical(1L)
        ))
    }
    inspect(matrix)
}
