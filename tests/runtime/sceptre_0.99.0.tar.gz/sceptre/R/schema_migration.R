# Serialized S4 attributes are inspected directly: the registered class may
# already have changed, so slotNames() cannot describe the physical old object.
legacy_saved_components <- function(saved, version) {
    if (
        version == 1L &&
            !all(
                c("response_matrix", "grna_matrix", "functs_called") %in%
                    names(saved)
            )
    ) {
        stop("Unrecognized legacy sceptre saved-object layout.")
    }
    if (
        version == 2L &&
            !all(
                c("data", "spec", "preparation", "fits", "results") %in%
                    names(saved)
            )
    ) {
        stop("Unrecognized component sceptre saved-object layout.")
    }
    components <- if (version == 1L) {
        stats::setNames(
            rep(list(saved), 5L),
            c("data", "spec", "preparation", "fits", "results")
        )
    } else {
        lapply(
            saved[c("data", "spec", "preparation", "fits", "results")],
            attributes
        )
    }
    components
}

normalize_legacy_component_fields <- function(components) {
    # Boundary aliases are intentionally confined here; current objects use
    # domain names and ordinary count matrices rather than schema-one/two wrappers.
    legacy_preparation_names <- c(
        design_matrix = "covariate_matrix",
        nt_nonzero_matrix = "M_matrix",
        control_nonzero_totals = "n_nonzero_tot_vector",
        guide_assignments = "initial_grna_assignment_list",
        source_groups = "grna_assignments_raw",
        analysis_groups = "grna_assignments",
        guide_counts_per_cell = "grnas_per_cell",
        assignment_exclusions = "cells_w_zero_or_twoplus_grnas",
        analysis_cells = "cells_in_use"
    )
    for (field in names(legacy_preparation_names)) {
        components$preparation[[
            field
        ]] <- components$preparation[[legacy_preparation_names[[field]]]]
    }
    for (field in c("response_matrix", "grna_matrix")) {
        store <- components$data[[field]]
        if (is.list(store)) {
            if (length(store) > 1L) {
                stop("Malformed legacy count-store wrapper.")
            }
            store <- if (length(store)) store[[1L]] else NULL
            if (is.list(store) && !length(store)) store <- NULL
        }
        descriptor <- components$data$backend[[sub("_matrix$", "", field)]]
        components$data[field] <- list(as_count_matrix(store, descriptor))
    }
    components
}

copy_legacy_components <- function(components, version) {
    out <- methods::new("sceptre_object")
    # Only current component payloads cross the boundary; removed counters,
    # execution flags and working budgets do not become a parallel live schema.
    if (version == 1L) {
        components$data$grna_target_data_frame$grna_group <- NULL
    }
    out@data <- do.call(
        new_screen_experiment,
        components$data[intersect(
            names(components$data),
            names(formals(new_screen_experiment))
        )]
    )
    for (owner in c("spec", "preparation")) {
        component <- methods::slot(out, owner)
        fields <- setdiff(
            intersect(
                methods::slotNames(component),
                names(components[[owner]])
            ),
            "stages"
        )
        for (field in fields) {
            methods::slot(component, field, check = FALSE) <- components[[
                owner
            ]][[field]]
        }
        methods::slot(out, owner) <- component
    }
    out
}

migrate_legacy_requests <- function(out, components) {
    # Prefer original schema-two requests when available. Earlier saved formats
    # only retain expanded left-join rows, whose ordered blocks can be reversed
    # without dropping repeated requests.
    request_certainty <- character()
    for (field in c("discovery_pairs", "positive_control_pairs")) {
        expanded <- components$spec[[field]]
        if (is.null(expanded)) {
            expanded <- data.frame()
        }
        methods::slot(out@preparation, field) <- expanded
        original <- components$spec$requested[[field]]
        recovered <- recover_legacy_requested_pairs(
            expanded,
            original,
            components$preparation$grna_target_data_frame,
            components$spec$grna_integration_strategy
        )
        methods::slot(out@spec, field) <- recovered$pairs
        request_certainty[field] <- recovered$certainty
    }
    list(object = out, certainty = request_certainty)
}

migrate_legacy_guide_groups <- function(out, components) {
    metadata <- components$preparation$grna_target_data_frame
    groups <- metadata$grna_group
    if (is.null(groups) && length(out@spec@grna_integration_strategy)) {
        canonical <- screen_guide_annotations(out@data)
        groups <- if (out@spec@grna_integration_strategy == "union") {
            canonical$grna_target
        } else {
            ifelse(
                canonical$grna_target == "non-targeting",
                "non-targeting",
                canonical$grna_id
            )
        }
    }
    if (!is.null(groups)) {
        out@preparation@guide_groups <- as.character(groups)
    }
    out
}

migrate_legacy_results <- function(out, components, version) {
    previous_results <- components$results
    old_records <- previous_results$records
    effective_fields <- c(
        "B1",
        "B2",
        "B3",
        "calibration_group_size",
        "n_calibration_pairs",
        "negative_control_pairs"
    )
    effective <- components$spec[intersect(
        effective_fields,
        names(components$spec)
    )]
    analysis_fields <- c(
        run_calibration_check = "calibration_result",
        run_power_check = "power_result",
        run_discovery_analysis = "discovery_result"
    )
    for (analysis in names(analysis_fields)) {
        table <- previous_results[[analysis_fields[[analysis]]]]
        old <- old_records[[analysis]]
        if (is.null(table)) {
            table <- data.frame()
        }
        if (nrow(table) || !is.null(old)) {
            out@results[[analysis_result_key(analysis)]] <- owned_result_value(
                migrate_historical_record(table, old, version, effective)
            )
        }
    }
    out
}

#' @noRd
migrate_sceptre_object <- function(object) {
    if (!methods::is(object, "sceptre_object")) {
        stop("Expected a `sceptre_object`.")
    }
    saved <- attributes(object)
    version <- if (is.null(saved$schema_version)) 1L else saved$schema_version
    legacy_results <- version %in% c(3L, 4L, 6L)
    if (legacy_results) {
        object@data <- migrate_screen_data_to_sce(saved$data)
        object <- migrate_backing_anchor_owner(object, saved$results)
        object@results <- migrate_result_container(saved$results)
        object@schema_version <- 7L
        version <- 7L
    }
    if (identical(version, 7L)) {
        # readRDS does not invoke S4 validity. Admit working choices and known
        # result shapes without demanding that historical preparation is current.
        object <- normalize_saved_count_matrices(object)
        validate_analysis_spec(object@spec)
        object <- normalize_saved_run_plans(normalize_saved_fit_cache(object))
        if (legacy_results) {
            object <- admit_legacy_result_entries(object)
        }
        valid_results <- validate_analysis_results(object@results)
        if (!isTRUE(valid_results)) {
            stop(valid_results)
        }
        return(object)
    }
    if (!version %in% c(1L, 2L)) {
        stop("Unsupported sceptre saved-object schema version.")
    }
    components <- legacy_saved_components(saved, version)
    components <- normalize_legacy_component_fields(components)
    out <- copy_legacy_components(components, version)
    requests <- migrate_legacy_requests(out, components)
    out <- requests$object
    request_certainty <- requests$certainty
    out <- migrate_legacy_guide_groups(out, components)
    # Count row identifiers do not reveal the feature labels supplied at import
    # (for example, Ensembl IDs can have separate mitochondrial gene labels).
    # Schema one did not persist those labels; keep their provenance unknown.
    out <- migrate_legacy_results(out, components, version)
    out <- initialize_screen_identity(out)
    if (!any(request_certainty == "unknown")) {
        out@preparation@stages <- migrate_preparation_stages(
            out,
            saved$functs_called
        )
    }
    validObject(out)
    out
}

# A cache representation changes no scientific input or result certificate.
# Accept only the documented old response cache, whose actual scope still
# validates, and the current unified representation. Never infer unknown fields.
#' @noRd
normalize_saved_fit_cache <- function(object) {
    saved <- attributes(object)$fits
    if (methods::is(saved, "FitCache")) {
        validObject(saved)
        return(object)
    }
    physical <- attributes(saved)
    if (
        !identical(as.character(physical$class)[1L], "ResponseFitCache") ||
            !setequal(names(physical), c("entries", "identity", "class"))
    ) {
        stop(
            "Unrecognized schema-three fit-cache layout; cached provenance ",
            "cannot be verified."
        )
    }
    cache <- methods::new(
        "FitCache",
        response_fits = physical$entries,
        response_identity = physical$identity
    )
    if (
        length(cache@response_fits) &&
            !identical(
                cache@response_identity,
                response_fit_identity(
                    object,
                    cache@response_identity$cells,
                    fit_identity_protocol(cache@response_identity)
                )
            )
    ) {
        stop(
            "Saved response fits do not match the actual data and design ",
            "inputs."
        )
    }
    object@fits <- cache
    object
}

# The outer schema and canonical input identities do not change when the
# existing plan value is promoted from a named list to its typed representation.
# Normalize the nested boundary value without recomputing or blessing identity.
#' @noRd
normalize_saved_run_plans <- function(object) {
    normalize_record <- function(record) {
        if (!is.list(record)) {
            return(record)
        }
        if (is.list(record$provenance) && !is.null(record$provenance$plan)) {
            saved_plan <- record$provenance$plan
            converted <- tryCatch(as_run_plan(saved_plan), error = identity)
            if (inherits(converted, "error")) {
                record$provenance$plan <- NULL
                record$provenance$unrecognized_plan <- list(
                    source = "saved-schema3",
                    error = conditionMessage(converted),
                    payload = saved_plan
                )
                record$invalidated_by <- unique(c(
                    record$invalidated_by,
                    "unrecognized saved run plan"
                ))
            } else {
                record$provenance$plan <- converted
            }
        }
        if (is.list(record$history)) {
            record$history <- lapply(record$history, normalize_record)
        }
        record
    }
    object@results <- lapply(object@results, normalize_record)
    object
}

reconstruct_legacy_pair_blocks <- function(expanded, canonical, metadata) {
    starts <- integer()
    position <- 1L
    while (position <= nrow(expanded)) {
        groups <- as.character(metadata$grna_group[
            metadata$grna_target == expanded$grna_target[position]
        ])
        width <- length(groups)
        block <- seq.int(position, length.out = width)
        if (
            !width ||
                max(block) > nrow(expanded) ||
                !identical(as.character(expanded$grna_group[block]), groups) ||
                !all(vapply(
                    block,
                    function(row) {
                        identical(
                            as.list(canonical[row, , drop = FALSE]),
                            as.list(canonical[position, , drop = FALSE])
                        )
                    },
                    logical(1)
                ))
        ) {
            return(list(pairs = canonical, certainty = "unknown"))
        }
        starts <- c(starts, position)
        position <- position + width
    }
    list(pairs = canonical[starts, , drop = FALSE], certainty = "reconstructed")
}

# Recover multiplicity from the historical left-join traversal, rather than
# uniquing rows. Unrecognized layouts remain readable but require fresh setup.
#' @noRd
recover_legacy_requested_pairs <- function(
    expanded,
    original,
    metadata,
    strategy
) {
    strip_group <- function(pairs) {
        pairs[, setdiff(names(pairs), "grna_group"), drop = FALSE]
    }
    if (is.data.frame(original)) {
        original <- strip_group(original)
        for (field in intersect(
            c("grna_target", "response_id"),
            names(original)
        )) {
            original[[field]] <- as.character(original[[field]])
        }
        return(list(pairs = original, certainty = "saved_original"))
    }
    canonical <- strip_group(expanded)
    if (
        !nrow(expanded) ||
            identical(strategy, "union") ||
            !"grna_group" %in% names(expanded)
    ) {
        return(list(pairs = canonical, certainty = "reconstructed"))
    }
    if (
        !strategy %in% c("singleton", "bonferroni") ||
            !all(c("grna_target", "grna_group") %in% names(metadata))
    ) {
        return(list(pairs = canonical, certainty = "unknown"))
    }
    reconstruct_legacy_pair_blocks(expanded, canonical, metadata)
}

#' @noRd
migrate_historical_record <- function(table, old, version, effective = list()) {
    if (!is.list(old)) {
        old <- list()
    }
    history <- lapply(old$history, function(entry) {
        previous <- if (is.null(entry$result)) entry$table else entry$result
        if (is.null(previous)) {
            previous <- data.frame()
        }
        migrate_historical_record(previous, entry, version, effective)
    })
    list(
        table = table,
        identity = NULL,
        provenance = list(
            source = "legacy",
            schema_version = as.integer(version),
            certainty = "unknown",
            saved_provenance = old$provenance,
            effective_snapshot = effective
        ),
        invalidated_by = "legacy provenance unknown",
        history = history
    )
}

migrate_preparation_stage <- function(object, stage) {
    commit_preparation_stage(object, stage)
}

legacy_pair_payload_valid <- function(pairs, requested) {
    is.data.frame(pairs) &&
        nrow(pairs) == nrow(requested) &&
        (!nrow(pairs) ||
            (all(
                c(
                    "response_id",
                    "grna_group",
                    "n_nonzero_trt",
                    "n_nonzero_cntrl",
                    "pass_qc"
                ) %in%
                    names(pairs)
            ) &&
                is.logical(pairs$pass_qc) &&
                !anyNA(pairs$pass_qc)))
}

legacy_source_cells_valid <- function(x, n) {
    is.numeric(x) &&
        !anyNA(x) &&
        !any(x != as.integer(x)) &&
        !any(x < 1L | x > n) &&
        !anyDuplicated(x)
}

legacy_design_payload_valid <- function(object, prep, n) {
    n > 0L &&
        nrow(prep@design_matrix) == n &&
        ncol(prep@design_matrix) > 0L &&
        length(prep@guide_groups) ==
            nrow(screen_guide_annotations(object@data)) &&
        !anyNA(prep@design_matrix)
}

# Flags are evidence only when their corresponding durable payload validates.
#' @noRd
migrate_preparation_stages <- function(object, flags) {
    prep <- object@preparation
    n <- nrow(screen_cell_covariates(object@data))
    flag <- function(name) isTRUE(unname(flags[name]))
    object@preparation@stages <- list()
    design_ok <- flag("set_analysis_parameters") &&
        legacy_design_payload_valid(object, prep, n)
    if (design_ok) {
        object <- migrate_preparation_stage(object, "design")
    }
    assignment_ok <- design_ok &&
        flag("assign_grnas") &&
        length(prep@guide_assignments) > 0L &&
        all(
            c("grna_group_idxs", "indiv_nt_grna_idxs") %in%
                names(prep@source_groups)
        ) &&
        all(vapply(
            prep@guide_assignments,
            legacy_source_cells_valid,
            logical(1),
            n = n
        ))
    if (assignment_ok) {
        object <- migrate_preparation_stage(object, "assignment")
    }
    cells_ok <- assignment_ok &&
        flag("run_qc") &&
        length(prep@analysis_cells) > 0L &&
        legacy_source_cells_valid(prep@analysis_cells, n) &&
        is.list(prep@analysis_groups$grna_group_idxs)
    if (cells_ok) {
        object <- migrate_preparation_stage(object, "cell_qc")
    }
    if (
        cells_ok &&
            legacy_pair_payload_valid(
                prep@discovery_pairs_with_info,
                prep@discovery_pairs
            ) &&
            legacy_pair_payload_valid(
                prep@positive_control_pairs_with_info,
                prep@positive_control_pairs
            )
    ) {
        object <- migrate_preparation_stage(object, "pair_qc")
    }
    object@preparation@stages
}

# Dataset identity is created only at import/explicit data-version boundaries.
# Live backing handles are deliberately excluded: their identity is
# process-local.
#' @noRd
normalize_saved_count_matrices <- function(object) {
    object@data <- migrate_screen_data_to_sce(object@data)
    object
}

# Move known import authority once; do not duplicate it across durable owners.
migrate_backing_anchor_owner <- function(
    object,
    previous_results = attributes(object)$results
) {
    old <- if (isS4(previous_results)) {
        attributes(previous_results)$import_metadata$backing_stores
    } else {
        NULL
    }
    if (!is.null(old)) {
        current <- screen_backing_anchors(object@data)
        if (length(current) && !identical(current, old)) {
            stop("Conflicting experimental-data backing anchors")
        }
        screen_backing_anchors(object@data) <- old
    }
    object
}

# Decode only the recognized old outer owner. Import bookkeeping is obsolete;
# backing authority has already moved to the data owner before this conversion.
migrate_result_container <- function(previous) {
    physical <- attributes(previous)
    if (
        !isS4(previous) ||
            !identical(as.character(physical$class)[1L], "ResultRecord") ||
            !setequal(
                names(physical),
                c("records", "import_metadata", "class")
            ) ||
            !is.list(physical$records) ||
            !is.list(physical$import_metadata) ||
            (length(physical$records) && is.null(names(physical$records))) ||
            anyDuplicated(names(physical$records)) ||
            any(!names(physical$records) %in% analysis_names())
    ) {
        stop("Unrecognized historical result-container layout")
    }
    result <- new_analysis_results()
    for (analysis in names(physical$records)) {
        result[analysis_result_key(analysis)] <- list(physical$records[[
            analysis
        ]])
    }
    result
}

# Old scope labels were never sufficient evidence of completeness. Retain tables,
# identities and provenance, but admit currentness only after the original plan
# and its finalized family/probabilities validate. Unknown/partial records remain
# explicitly historical; no replacement bookkeeping owner is created.
admit_legacy_result_entries <- function(object) {
    admit_record <- function(record, analysis) {
        if (is.null(record)) {
            return(NULL)
        }
        if (!is.list(record)) {
            stop("Malformed historical result entry")
        }
        complete <- identical(record$scope, "complete_family")
        record$scope <- NULL
        if (is.list(record$history)) {
            record$history <- lapply(
                record$history,
                admit_record,
                analysis = analysis
            )
        }
        if (!complete) {
            record$invalidated_by <- unique(c(
                record$invalidated_by,
                "legacy result completeness unknown"
            ))
        } else if (is.null(record$invalidated_by)) {
            error <- tryCatch(
                {
                    plan <- as_run_plan(record$provenance$plan)
                    if (!identical(plan@analysis, analysis)) {
                        stop("Result analysis and plan disagree")
                    }
                    validate_result_family(object, record$table, plan)
                    validate_completed_probabilities(
                        object,
                        analysis,
                        record$table
                    )
                    NULL
                },
                error = function(condition) conditionMessage(condition)
            )
            if (!is.null(error)) {
                record$invalidated_by <- "legacy result failed complete-family validation"
            }
        }
        record
    }
    for (analysis in analysis_names()) {
        key <- analysis_result_key(analysis)
        object@results[key] <- list(admit_record(
            object@results[[key]],
            analysis
        ))
    }
    object
}
