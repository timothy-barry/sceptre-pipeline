# Resolve experimental CRT configuration once, at RunPlan construction.
# Workers only consume the frozen policy and never read global options.
crt_prototype_policy <- function(
    value = getOption("sceptre.experimental.crt", NULL)
) {
    if (is.null(value)) {
        value <- list(mode = "reference", max_guides = 1L)
    }
    if (
        !is.list(value) ||
            is.null(value$mode) ||
            length(value$mode) != 1L ||
            !is.character(value$mode) ||
            is.na(value$mode) ||
            !value$mode %in% c("reference", "sampler", "cohort") ||
            anyDuplicated(names(value)) ||
            !all(names(value) %in% c("mode", "max_guides", "max_draw_bytes"))
    ) {
        stop("Invalid CRT execution policy")
    }
    if (is.null(value$max_guides)) {
        value$max_guides <- 8L
    }
    if (is.null(value$max_draw_bytes)) {
        value$max_draw_bytes <- 256 * 1024^2
    }
    policy <- list(
        mode = value$mode,
        max_guides = value$max_guides,
        max_draw_bytes = value$max_draw_bytes
    )
    validate_execution_policy(policy)
    policy
}
validate_execution_policy <- function(policy) {
    if (identical(policy, list(mode = "permutations"))) {
        return(TRUE)
    }
    if (
        !is.list(policy) ||
            !identical(
                names(policy),
                c("mode", "max_guides", "max_draw_bytes")
            ) ||
            !is.character(policy$mode) ||
            length(policy$mode) != 1L ||
            is.na(policy$mode) ||
            !policy$mode %in% c("reference", "sampler", "cohort")
    ) {
        stop("Invalid CRT execution policy")
    }
    for (name in c("max_guides", "max_draw_bytes")) {
        value <- policy[[name]]
        minimum <- if (name == "max_guides") 1 else 0
        if (
            !is.numeric(value) ||
                length(value) != 1L ||
                !is.finite(value) ||
                value < minimum ||
                value != floor(value)
        ) {
            stop("Invalid CRT policy limit: ", name)
        }
    }
    TRUE
}
resolve_execution_policy <- function(object, analysis) {
    if (object@spec@run_permutations) {
        return(list(mode = "permutations"))
    }
    policy <- crt_prototype_policy()
    if (
        policy$mode != "reference" &&
            !object@spec@control_group_complement &&
            analysis != "run_calibration_check"
    ) {
        stop(
            "Experimental CRT policies require shared response fits; NT discovery/power requires reference mode"
        )
    }
    policy
}
require_run_policy <- function(plan) {
    policy <- run_plan_policy(plan)
    if (is.null(policy)) {
        stop(
            "Historical RunPlan has unknown execution policy; create a new plan before execution"
        )
    }
    validate_execution_policy(policy)
    policy
}

crt_prototype_score_test <- function(
    expression,
    score,
    treatment,
    bank,
    opts,
    output_amount
) {
    run_association_test(
        y = expression,
        mu = score$mu,
        a = score$a,
        w = score$w,
        D = score$D,
        trt_idxs = treatment$trt_idxs,
        use_all_cells = TRUE,
        n_trt = treatment$n_trt,
        synthetic_idxs = bank,
        B1 = opts$B1,
        B2 = opts$B2,
        B3 = opts$B3,
        fit_parametric_curve = opts$fit_parametric_curve,
        return_resampling_dist = output_amount == 3L,
        side_code = opts$side_code
    )
}

# A worker holds a bounded cohort of banks and one gene's score arrays at a time.
# The unchanged upstream fit pass and partitioning preserve cached fit order/RNG.
crt_prototype_cohort_block <- function(
    block_groups,
    context,
    response_fits,
    prepare_group,
    execution,
    reader
) {
    policy <- context$execution_policy
    index <- context$index
    run_cohort <- function(cursor, pending) {
        cohort <- list()
        banks <- list()
        updates <- list()
        used <- 0
        return_pending <- NULL
        on.exit(
            for (bank in banks) {
                crt_cohort_close_cpp(bank)
            },
            add = TRUE
        )
        while (
            cursor <= length(block_groups) && length(cohort) < policy$max_guides
        ) {
            group_idx <- block_groups[cursor]
            id <- as.character(index$group_ids[group_idx])
            prepared <- if (is.null(pending)) {
                prepare_group(group_idx, cursor)
            } else {
                pending
            }
            if (is.null(prepared$probabilities)) {
                prepared$probabilities <- fit_assignment_probabilities(
                    prepared$treatment$trt_idxs,
                    context$design
                )
            }
            receipt <- crt_cohort_bank_cpp(
                prepared$probabilities,
                context$test_options$total_resamples,
                policy$max_draw_bytes - used
            )
            if (!receipt$accepted) {
                if (!length(cohort)) {
                    stop(
                        "One full-budget CRT bank exceeds draw-byte limit: ",
                        receipt$bytes
                    )
                }
                # Keep the exact fit and its emitted warnings while the next
                # cohort waits for bank capacity; do not refit it.
                return_pending <- prepared
                break
            }
            return_pending <- NULL
            pending <- NULL
            banks[[length(banks) + 1L]] <- receipt$bank
            updates <- c(updates, prepared$updates)
            rows <- index$rows_by_group[[as.character(group_idx)]]
            cohort[[length(cohort) + 1L]] <- list(
                position = cursor,
                rows = rows,
                response_rows = index$pair_rows$response_idx[rows],
                treatment = prepared$treatment,
                bank = receipt$bank,
                raw = vector("list", length(rows))
            )
            used <- used + receipt$bytes
            cursor <- cursor + 1L
        }
        genes <- sort(unique(unlist(
            lapply(cohort, `[[`, "response_rows"),
            use.names = FALSE
        )))
        for (row in genes) {
            expression <- reader$read(row)
            score <- prepare_score_components(
                expression,
                context$design,
                lookup_response_fit(
                    response_fits,
                    as.character(index$response_ids[row])
                )
            )
            for (g in seq_along(cohort)) {
                for (j in which(cohort[[g]]$response_rows == row)) {
                    cohort[[g]]$raw[[j]] <- crt_prototype_score_test(
                        expression,
                        score,
                        cohort[[g]]$treatment,
                        cohort[[g]]$bank,
                        context$test_options,
                        execution$output_amount
                    )
                }
            }
        }
        results <- lapply(cohort, function(group) {
            pair_results_from_native(
                context$pairs[group$rows, , drop = FALSE],
                group$raw,
                execution$output_amount
            )
        })
        list(
            cursor = cursor,
            pending = return_pending,
            results = results,
            positions = vapply(cohort, `[[`, integer(1), "position"),
            updates = updates
        )
    }
    results <- vector("list", length(block_groups))
    updates <- list()
    cursor <- 1L
    pending <- NULL
    while (cursor <= length(block_groups)) {
        cohort <- run_cohort(cursor, pending)
        results[cohort$positions] <- cohort$results
        updates <- c(updates, cohort$updates)
        cursor <- cohort$cursor
        pending <- cohort$pending
    }
    list(
        result = bind_analysis_results(results),
        perturbation_updates = updates
    )
}
