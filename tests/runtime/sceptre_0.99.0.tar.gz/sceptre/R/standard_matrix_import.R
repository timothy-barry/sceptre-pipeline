#' Collapse native guide counts in memory or durable sparse HDF5 storage
#' @param grna_matrix Validated standard matrix with guides in rows.
#' @param grna_target_data_frame Guide metadata with vector_id.
#' @param directory_to_write Explicit directory for a new count file when the
#'   input has file-backed seeds. RAM inputs require no output directory.
#' @return A feature-major standard DelayedMatrix of vector counts. Keep source
#'   cell order and first-seen vector order. Drop zero sums as the in-memory
#'   importer does when converting its dense aggregated counts to sparse form.
#' @details Sum each integer-count guide group with the maintained native
#'   matrix interface. Output workspace is one vector across source cells,
#'   not all vectors or guides. No dense guide-by-cell input blocks are needed.
#'   File-backed inputs use HDF5Array's maintained sparse realization sink; RAM
#'   inputs use maintained SparseArray construction. No source file is modified;
#'   a partially written new file is removed if import fails.
#' @noRd
collapse_standard_grna_matrix <- function(
    grna_matrix,
    grna_target_data_frame,
    directory_to_write
) {
    if (!count_matrix_is_backed(grna_matrix)) {
        return(collapse_standard_ram_grna_matrix(
            grna_matrix,
            grna_target_data_frame
        ))
    }
    directory_to_write <- prepare_directory_to_write(directory_to_write)
    vector_ids <- unique(grna_target_data_frame$vector_id)
    n_cells <- ncol(grna_matrix)
    n_vectors <- length(vector_ids)
    if (anyNA(vector_ids)) {
        stop("Backed guide vector IDs must not contain missing values.")
    }
    if (!n_cells || !n_vectors) {
        return(DelayedArray::DelayedArray(matrix(
            numeric(),
            n_vectors,
            n_cells,
            dimnames = list(as.character(vector_ids), colnames(grna_matrix))
        )))
    }
    path <- tempfile(
        "vector-counts-",
        tmpdir = directory_to_write,
        fileext = ".h5"
    )
    complete <- FALSE
    on.exit(if (!complete && file.exists(path)) unlink(path))
    sink <- HDF5Array::TENxRealizationSink(
        dim = c(n_cells, n_vectors),
        dimnames = list(colnames(grna_matrix), as.character(vector_ids)),
        type = "double",
        filepath = path,
        group = "counts"
    )
    for (k in seq_len(n_vectors)) {
        ids <- grna_target_data_frame$grna_id[
            grna_target_data_frame$vector_id == vector_ids[k]
        ]
        rows <- match(ids, rownames(grna_matrix))
        sums <- storage_standard_call(
            grna_matrix[rows, , drop = FALSE],
            function(initialized) {
                if (utils::packageVersion("beachmat") >= "2.28.0") {
                    beachmat::tatami.sums(
                        initialized,
                        row = FALSE,
                        num.threads = 1L
                    )
                } else {
                    beachmat::tatami.column.sums(initialized, num.threads = 1L)
                }
            }
        )
        viewport <- S4Arrays::ArrayViewport(
            c(n_cells, n_vectors),
            IRanges::IRanges(start = c(1L, k), width = c(n_cells, 1L))
        )
        sink <- DelayedArray::write_block(
            sink,
            viewport,
            matrix(sums, ncol = 1L)
        )
    }
    HDF5Array::close(sink)
    result <- t(methods::as(sink, "TENxMatrix"))
    complete <- TRUE
    result
}

# Keep native RAM counts in RAM. Each output column is one guide vector in a
# transposed standard sparse array, so no dense vector-by-cell matrix is needed.
# SparseArray owns construction and zero omission; no SVT slots are modified.
collapse_standard_ram_grna_matrix <- function(
    grna_matrix,
    grna_target_data_frame
) {
    vector_ids <- unique(grna_target_data_frame$vector_id)
    if (anyNA(vector_ids)) {
        stop("Guide vector IDs must not contain missing values.")
    }
    n_cells <- ncol(grna_matrix)
    output <- SparseArray::SVT_SparseArray(
        dim = c(n_cells, length(vector_ids)),
        type = "double",
        dimnames = list(colnames(grna_matrix), as.character(vector_ids))
    )
    if (!n_cells || !length(vector_ids)) {
        return(t(DelayedArray::DelayedArray(output)))
    }
    for (k in seq_along(vector_ids)) {
        ids <- grna_target_data_frame$grna_id[
            grna_target_data_frame$vector_id == vector_ids[k]
        ]
        rows <- match(ids, rownames(grna_matrix))
        if (anyNA(rows)) {
            stop("Guide IDs must occur in the guide count matrix.")
        }
        # Keep every selected guide together for each cell. The existing
        # bounded dense-column helper preserves this platform's colSums()
        # accumulator, including valid large integer counts.
        output[, k] <- sum_sparse_vector_rows(grna_matrix[rows, , drop = FALSE])
    }
    t(DelayedArray::DelayedArray(output))
}
