# Read and convert counts in memory or standard native matrices here. Native
# readers are transient; saved matrices contain ordinary Bioconductor
# descriptors.

#' Find a gene's row in the count matrix
#' @param store Sparse matrix or native DelayedMatrix with row names.
#' @param id Gene or other feature name, already checked by the caller.
#' @return Matching row numbers, starting at 1; `integer()` if none match.
#'   If row names repeat, all matching rows are returned.
#' @noRd
storage_response_index <- function(store, id) {
    which(id == rownames(store))
}

#' Read one gene's counts for the requested cells
#' @param store Row-accessible sparse Matrix or native DelayedMatrix.
#' @param response_idx Gene's row number in `store`, starting at 1.
#' @param source_cells Original count-matrix column numbers, in the desired
#'   order.
#'   NULL selects all cells; `integer()` selects none. Repeats are kept.
#' @return Numeric count vector in the requested order, including for one cell.
#' @details Ordinary Matrix input reads a complete source row before selecting cells.
#'   Standard matrices use indexed native extraction of only selected cells.
#'   No path changes source counts or materializes a complete count matrix.
#' @noRd
storage_read_response <- function(store, response_idx, source_cells = NULL) {
    if (storage_is_standard_matrix(store)) {
        return(storage_standard_read_response(store, response_idx, source_cells))
    }
    y <- load_csr_row(store@j, store@p, store@x, response_idx, ncol(store))
    if (is.null(source_cells)) y else y[source_cells]
}

#' Reuse a response reader for a worker's fixed cell view
#' @inheritParams storage_read_response
#' @return A list containing read(response_idx) and close() functions.
#' @details Open after entering the worker process, then register close() with
#'   on.exit(). Never save the reader in a screen object or pass it across forks.
#' @noRd
storage_open_response_reader <- function(store, source_cells = NULL) {
    if (storage_is_standard_matrix(store)) {
        return(storage_standard_open_response_reader(store, source_cells))
    }
    # Each reader owns its close state; sibling readers stay independent.
    state <- new.env(parent = emptyenv())
    state$closed <- FALSE
    list(
        read = function(response_idx) {
            if (state$closed) {
                stop("Response reader is closed.")
            }
            storage_read_response(store, response_idx, source_cells)
        },
        close = function() {
            state$closed <- TRUE
            invisible(NULL)
        }
    )
}

#' Find cells whose stored count reaches a feature's assignment threshold
#' @param store Row-accessible sparse matrix (`dgRMatrix`) or a
#'   supported standard matrix.
#' @param feature_idx Feature's row number in `store`, starting at 1.
#' @param threshold Count threshold.
#' @return Original matrix column numbers, starting at 1, in storage order.
#' @details Test only entries actually stored in the sparse matrix. An unstored
#'   zero is never returned, even for threshold zero; an explicitly stored zero
#'   can pass. Values and thresholds use double comparisons. Standard dense
#'   matrices omit numerical zeros as the existing dense-to-sparse importer
#'   does; sparse matrices retain stored zeros.
#'   The input matrix is unchanged.
#' @noRd
storage_threshold_row <- function(store, feature_idx, threshold) {
    if (storage_is_standard_matrix(store)) {
        storage_standard_threshold_rows(store, feature_idx, threshold)[[1L]]
    } else {
        threshold_count_matrix(store@j, store@p, store@x,
            feature_idx, as.numeric(threshold))
    }
}

#' Find threshold memberships for a batch of features
#' @inheritParams storage_threshold_row
#' @param feature_idxs One-based feature positions, in the requested order.
#' @return List of cell-position vectors; feature order and repeats are kept.
#' @noRd
storage_threshold_rows <- function(store, feature_idxs, threshold) {
    if (storage_is_standard_matrix(store)) {
        return(storage_standard_threshold_rows(
            store,
            feature_idxs,
            threshold
        ))
    }
    lapply(feature_idxs, function(i) storage_threshold_row(store, i, threshold))
}

#' Count stored entries for each requested gene-guide pair
#' @param store Row-accessible sparse matrix (`dgRMatrix`) or a
#'   supported standard matrix;
#'   genes are rows and original cells are columns.
#' @param pair_index Table giving each request's gene row (`response_idx`) and
#'   position in `groups` (`group_idx`), both starting at 1. Repeated requests
#'   and any request order are allowed.
#' @param groups Treatment-cell lists. Numbers are positions within
#'   `source_cells`,
#'   not original matrix columns. For `source_cells = c(2, 4, 5)`, group `c(1,
#'   3)`
#'   means original cells 2 and 5.
#' @param source_cells Original matrix columns kept after QC, in analysis order.
#' @param controls `"complement"` for all other kept cells, or NT-control
#'   positions
#'   within `source_cells`.
#' @param nt_groups Optional NT-guide cell lists, also as positions within
#'   `source_cells`. Low-MOI callers supply their NT groups for a summary across
#'   all genes. These lists are counted as supplied, without removing overlaps.
#'   NULL requests pair counts without retaining that summary.
#' @param nuclear Retained private compatibility argument; native readers use
#'   the declared summary scope independently of execution placement.
#' @return `n_nonzero_trt` and `n_nonzero_cntrl`, integer vectors in request order.
#'   When retained, `n_nonzero_mat` has NT groups in rows and all genes in columns;
#'   `n_nonzero_tot` has a total per gene. Otherwise these two fields contain the
#'   existing empty placeholders `matrix()` and `integer()`.
#' @details These counts count stored entries, including explicitly stored
#'   zeros,
#'   rather than testing whether loaded values are positive. Complement totals
#'   count kept cells; NT totals sum the supplied NT groups, so an overlap would
#'   be counted again. Requests are sorted for reading, then restored to their
#'   original order. In-memory C++ code copies and converts its own positions.
#'   Caller inputs remain unchanged.
#' @noRd
storage_pair_counts <- function(
    store,
    pair_index,
    groups,
    source_cells,
    controls,
    nt_groups = NULL,
    nuclear = FALSE
) {
    complement <- is.character(controls) && identical(controls, "complement")
    all_nt_idxs <- if (complement) integer() else as.integer(controls)
    summarize <- !is.null(nt_groups)
    if (is.null(nt_groups)) {
        nt_groups <- if (complement) list() else list(all_nt_idxs)
    }
    scan_order <- order(pair_index$response_idx, method = "radix")
    response_idxs <- as.integer(pair_index$response_idx[scan_order])
    group_idxs <- as.integer(pair_index$group_idx[scan_order])
    if (storage_is_standard_matrix(store)) {
        out <- storage_standard_call(
            store,
            standard_matrix_pair_counts_cpp,
            groups,
            nt_groups,
            response_idxs,
            group_idxs,
            complement,
            as.integer(source_cells),
            summarize
        )
        if (!summarize) {
            out$n_nonzero_mat <- matrix()
            out$n_nonzero_tot <- integer()
        }
    } else {
        out <- storage_sparse_pair_counts(
            store,
            groups,
            source_cells,
            nt_groups,
            response_idxs,
            group_idxs,
            complement,
            summarize
        )
    }
    restore_order <- order(scan_order)
    out$n_nonzero_trt <- out$n_nonzero_trt[restore_order]
    out$n_nonzero_cntrl <- out$n_nonzero_cntrl[restore_order]
    out
}

#' Count stored entries for guide groups across a requested list of genes
#' @inheritParams storage_pair_counts
#' @param response_idxs Original gene-row numbers, starting at 1, in requested
#'   order.
#' @return Integer matrix with one row per group and one column per requested
#'   gene. Keep request order, repeats and matrix dimensions, even for zero or
#'   one row/column.
#' @details Ordinary Matrix kernels count all genes before selecting requested columns.
#'   Standard matrices read only requested rows. Sparse counts include
#'   explicitly stored zeros; standard dense inputs omit numerical zeros.
#' @noRd
storage_group_counts <- function(store, response_idxs, groups, source_cells) {
    if (storage_is_standard_matrix(store)) {
        return(storage_standard_call(store, standard_matrix_group_counts_cpp,
            as.integer(response_idxs), groups, as.integer(source_cells)))
    }
    out <- sparse_group_counts(j = store@j, p = store@p,
        n_cells_orig = ncol(store), groups = groups, cells_in_use = source_cells)
    out[, response_idxs, drop = FALSE]
}

#' Write two feature-major native sparse HDF5 matrices
#' @param response_matrix,grna_matrix Validated row-oriented count matrices.
#' @param directory_to_write Fresh output directory owned by the importer.
#' @param integer_id Retained private compatibility argument, unused.
#' @return Standard response_matrix and grna_matrix descriptors.
#' @noRd
storage_create_backed_pair <- function(
    response_matrix, grna_matrix, directory_to_write, integer_id = NULL
) {
    list(
        response_matrix = tenx_write_feature_major(
            list(DelayedArray::DelayedArray(response_matrix)),
            file.path(directory_to_write, "response.h5"), 32L, level = 3L),
        grna_matrix = tenx_write_feature_major(
            list(DelayedArray::DelayedArray(grna_matrix)),
            file.path(directory_to_write, "grna.h5"), 32L, level = 3L)
    )
}

#' Open native HDF5 matrices produced by this package
#' @param response_file,grna_file Feature-major HDF5 files with a counts group.
#' @param integer_id Retained private compatibility argument, unused.
#' @return Standard response_matrix and grna_matrix descriptors; callers verify
#'   imported content anchors before reusing fits or results.
#' @noRd
storage_reopen_backed_pair <- function(response_file, grna_file, integer_id = NULL) {
    list(
        response_matrix = t(HDF5Array::TENxMatrix(response_file, "counts")),
        grna_matrix = t(HDF5Array::TENxMatrix(grna_file, "counts"))
    )
}

#' Calculate count summaries for each cell
#' @param store Column-accessible sparse matrix (`dgCMatrix`) or a supported
#'   standard matrix, with features in rows and cells in columns.
#' @param mt_gene_idxs Mitochondrial feature-row numbers, starting at 1; may be empty.
#' @param compute_p_mito,compute_max_feature Whether to calculate mitochondrial
#'   fractions and the largest feature's contribution.
#' @return One value per cell for `n_nonzero` (counts greater than 0.5),
#'   `n_umi`,
#'   `p_mito`, `frac_umis_max_feature` and `max_feature`. Unlike R row numbers,
#'   `max_feature` starts at 0; ties use the first maximum. Disabled optional
#'   summaries remain zero. A computed ratio with zero total counts can be
#'   non-finite. C++ copies mitochondrial positions before converting them,
#'   leaving the caller's vector unchanged.
#' @noRd
storage_cell_covariates <- function(
    store,
    mt_gene_idxs,
    compute_p_mito,
    compute_max_feature
) {
    if (storage_is_standard_matrix(store)) {
        return(storage_standard_cell_covariates(
            store,
            mt_gene_idxs,
            compute_p_mito,
            compute_max_feature
        ))
    }
    compute_cell_covariates_cpp(
        i = store@i,
        p = store@p,
        x = store@x,
        n_genes = nrow(store),
        n_cells = ncol(store),
        mt_gene_idxs = mt_gene_idxs,
        compute_p_mito = compute_p_mito,
        compute_max_feature = compute_max_feature
    )
}

#' Convert a count matrix for efficient access by row or column
#' @param matrix_in Numeric dense matrix, numeric or logical sparse matrix, or
#'   a supported standard matrix. Sparse input may
#'   use row, column or triplet storage.
#' @param make_row_accessible TRUE requests row storage (`dgRMatrix`); FALSE
#'   requests column storage (`dgCMatrix`).
#' @return Sparse matrix with the same dimensions and names, or the supplied
#'   standard matrix. Numeric sparse matrices already in the requested
#'   form are returned as is. Standard matrices retain physical storage order;
#'   their native readers select an appropriate access direction.
#' @details Keep stored numeric values, including zeros and fractions. For logical
#'   sparse input, every stored entry becomes one, even an explicitly stored
#'   FALSE; this preserves the package's existing convention. Duplicate triplet entries
#'   are not combined here. Sorting uses copies so callers' sparse vectors are
#'   unchanged. Dense input is first treated as a general matrix to retain both
#'   triangles of symmetric-looking data; this can require an extra dense copy.
#'   Sparse input is not converted to dense matrices.
#' @noRd
set_matrix_accessibility <- function(matrix_in, make_row_accessible = TRUE) {
    if (storage_is_standard_matrix(matrix_in)) {
        return(matrix_in)
    }
    owns_i <- owns_j <- owns_x <- FALSE
    # For logical sparse input, count every stored entry as 1, even stored
    # FALSE.
    if (methods::is(matrix_in, "lgRMatrix")) {
        attr(matrix_in, "class") <- "dgRMatrix"
        matrix_in@x <- rep(1.0, length(matrix_in@j))
        owns_x <- TRUE
    }
    if (methods::is(matrix_in, "lgCMatrix")) {
        attr(matrix_in, "class") <- "dgCMatrix"
        matrix_in@x <- rep(1.0, length(matrix_in@i))
        owns_x <- TRUE
    }
    if (methods::is(matrix_in, "lgTMatrix")) {
        attr(matrix_in, "class") <- "dgTMatrix"
        matrix_in@x <- rep(1.0, length(matrix_in@j))
        owns_x <- TRUE
    }

    if (methods::is(matrix_in, "dgRMatrix") && make_row_accessible) {
        out <- matrix_in
    } else if (methods::is(matrix_in, "dgCMatrix") && !make_row_accessible) {
        out <- matrix_in
    } else {
        n_responses <- nrow(matrix_in)
        response_ids <- rownames(matrix_in)
        cell_ids <- colnames(matrix_in)
        n_cells <- ncol(matrix_in)
        if (methods::is(matrix_in, "dgTMatrix")) {
            i <- matrix_in@i
            j <- matrix_in@j
        } else if (methods::is(matrix_in, "matrix")) {
            # Auto-detecting symmetric structure would store only one triangle;
            # a general output must retain every original dense entry instead.
            matrix_in <- methods::as(
                methods::as(matrix_in, "generalMatrix"),
                "TsparseMatrix"
            )
            i <- matrix_in@i
            j <- matrix_in@j
            owns_i <- owns_j <- owns_x <- TRUE
        } else if (methods::is(matrix_in, "dgCMatrix")) {
            i <- matrix_in@i
            j <- sparse_pointer_to_indices(matrix_in@p)
            owns_j <- TRUE
        } else if (methods::is(matrix_in, "dgRMatrix")) {
            i <- sparse_pointer_to_indices(matrix_in@p)
            j <- matrix_in@j
            owns_i <- TRUE
        } else {
            stop("Class not recognized.")
        }
        x <- matrix_in@x

        # Sorting changes vectors in place. Copy vectors taken from the input
        # sparse matrix so its slots stay unchanged. Dense conversion, pointer
        # expansion and replacing logical values already made fresh vectors;
        # those can be sorted directly. Do not guess whether copying is needed
        # from R's reference counts.
        dt <- list(
            i = if (owns_i) i else data.table::copy(i),
            j = if (owns_j) j else data.table::copy(j),
            x = if (owns_x) x else data.table::copy(x)
        )
        data.table::setDT(dt)

        if (make_row_accessible) {
            data.table::setorderv(x = dt, cols = c("i", "j"))
            p <- obtain_pointer_vector(i = dt$i, dim = n_responses)
            out <- Matrix::sparseMatrix(j = 1, p = c(0, 1), x = 1, repr = "R")
            out@j <- dt$j
        } else {
            data.table::setorderv(x = dt, cols = c("j", "i"))
            p <- obtain_pointer_vector(i = dt$j, dim = n_cells)
            out <- Matrix::sparseMatrix(i = 1, p = c(0, 1), x = 1, repr = "C")
            out@i <- dt$i
        }
        out@p <- p
        out@x <- dt$x
        out@Dim <- c(n_responses, n_cells)
        rownames(out) <- response_ids
        colnames(out) <- cell_ids
    }
    return(out)
}

#' Expand sparse-matrix entry counts into a row or column number per entry
#' @param p Compressed sparse pointer: cumulative entry counts starting at zero,
#'   with length equal to the number of rows/columns plus one. Counts must not
#'   decrease, and the vector must describe at least one row/column.
#' @return Row/column numbers starting at zero, one per stored entry. For
#'   example,
#'   `p = c(0, 2, 2, 3)` gives `c(0, 0, 2)`: two entries in the first
#'   row/column,
#'   none in the second and one in the third. The input and entry order are
#'   kept.
#' @noRd
sparse_pointer_to_indices <- function(p) {
    l <- diff(p)
    rep(x = seq(0, length(l) - 1L), times = l)
}

storage_sparse_pair_counts <- function(
    store,
    groups,
    source_cells,
    nt_groups,
    response_idxs,
    group_idxs,
    complement,
    summarize
) {
    out <- sparse_pair_counts(
        j = store@j,
        p = store@p,
        n_cells_orig = ncol(store),
        grna_group_idxs = groups,
        nt_groups_analysis = nt_groups,
        to_analyze_response_idxs = response_idxs,
        to_analyze_grna_idxs = group_idxs,
        control_group_complement = complement,
        cells_in_use = source_cells
    )
    if (!summarize) {
        out$n_nonzero_mat <- matrix()
        out$n_nonzero_tot <- integer()
    }
    out
}
