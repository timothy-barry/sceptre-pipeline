#' Compute cell summaries from a maintained native matrix reader
#' @param matrix_in Supported nonnegative integer UMI counts, with features in rows.
#' @param mt_gene_idxs Mitochondrial rows, starting at one. Repeated rows carry
#'   integer weights in the mitochondrial numerator.
#' @param compute_p_mito,compute_max_feature Whether to calculate these optional
#'   summaries. Disabled result vectors retain the legacy zero values.
#' @return The same low-level summary list as compute_cell_covariates_cpp().
#' @details The reader chooses sparse row or column traversal according to the
#'   physical backend and calculates all requested summaries in one pass. It
#'   does not realize or transpose the complete matrix. Fractions are rejected.
#'   Its native handle is created in the current process and is never saved.
#' @noRd
storage_standard_cell_covariates <- function(
    matrix_in,
    mt_gene_idxs,
    compute_p_mito,
    compute_max_feature
) {
    storage_standard_call(
        matrix_in,
        standard_matrix_cell_covariates_cpp,
        as.integer(mt_gene_idxs),
        compute_p_mito,
        compute_max_feature
    )
}
