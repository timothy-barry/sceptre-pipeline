# Schema-four decoder, used once during migration only. Current screens do not
# retain historical row-name encodings or column-attribute templates.
screen_internal_defaults <- function(kind) {
    switch(
        kind,
        cell = c(
            covariate_rowname = ".sceptre_covariate_rowname",
            max_grna = ".sceptre_max_grna",
            max_grna_frac_umis = ".sceptre_max_grna_frac_umis"
        ),
        guide = c(
            annotation_order = ".sceptre_annotation_order",
            legacy_rowname = ".sceptre_legacy_rowname"
        ),
        stop("Unknown screen bookkeeping axis: ", kind)
    )
}

screen_internal_columns <- function(meta, kind) {
    defaults <- screen_internal_defaults(kind)
    stored <- meta[[paste0(kind, "_internal_columns")]]
    if (!is.null(stored)) {
        defaults[names(stored)] <- stored
    }
    defaults
}

# Keep row-aware vector/matrix/list semantics in repeated guide annotations.
# Shape attributes come from maintained row operations; other S3 attributes
# (notably AsIs and factor levels) come from the original supplied column.
restore_screen_column <- function(x, template) {
    if (is.null(template) || isTRUE(template$is_s4)) {
        return(x)
    }
    current <- attributes(x)
    shape <- current[intersect(
        names(current),
        c("names", "dim", "dimnames", "row.names")
    )]
    desired <- c(shape, template$attributes)
    if (!length(desired)) {
        desired <- NULL
    }
    # Avoid copying an ordinary large numeric covariate just to reassign NULL.
    if (!identical(current, desired)) {
        attributes(x) <- desired
    }
    x
}

bind_screen_annotation_column <- function(pieces, ordering, template) {
    if (!length(pieces)) {
        return(restore_screen_column(template$prototype, template))
    }
    value <- S4Vectors::bindROWS(pieces[[1L]], pieces[-1L], use.names = TRUE)
    restore_screen_column(S4Vectors::extractROWS(value, ordering), template)
}

legacy_screen_field <- function(x, name) {
    if (!methods::is(x, 'SingleCellExperiment')) {
        stop('Working data must be a SingleCellExperiment')
    }
    meta <- screen_meta(x)
    cell_columns <- screen_internal_columns(meta, "cell")
    guide_columns <- screen_internal_columns(meta, "guide")
    if (name == 'response_matrix') {
        return(SummarizedExperiment::assay(x, 'counts', withDimnames = FALSE))
    }
    if (name == 'grna_matrix') {
        return(SummarizedExperiment::assay(
            SingleCellExperiment::altExp(
                x,
                'gRNA',
                withDimnames = FALSE,
                withColData = FALSE
            ),
            'counts',
            withDimnames = FALSE
        ))
    }
    if (name == 'response_names') {
        return(
            if (isTRUE(meta$response_names_present)) {
                as.character(SummarizedExperiment::rowData(x)$response_name)
            } else {
                character()
            }
        )
    }
    if (name == 'covariate_data_frame') {
        if (isTRUE(meta$covariate_was_empty)) {
            return(data.frame())
        }
        cd <- SummarizedExperiment::colData(x)
        columns <- stats::setNames(
            lapply(meta$covariate_names, function(n) {
                restore_screen_column(
                    cd[[n]],
                    meta$covariate_column_templates[[n]]
                )
            }),
            meta$covariate_names
        )
        rows <- if (!ncol(x)) {
            if (meta$covariate_rowname_type == 'character') {
                character()
            } else {
                integer()
            }
        } else if (isTRUE(meta$covariate_automatic_rownames)) {
            c(NA_integer_, -ncol(x))
        } else if (isTRUE(meta$covariate_rowname_column)) {
            value <- cd[[cell_columns[["covariate_rowname"]]]]
            if (meta$covariate_rowname_type == 'integer') {
                as.integer(value)
            } else {
                as.character(value)
            }
        } else {
            rownames(cd)
        }
        return(structure(columns, class = 'data.frame', row.names = rows))
    }
    if (name == 'grna_target_data_frame') {
        guide <- SingleCellExperiment::altExp(
            x,
            'gRNA',
            withDimnames = FALSE,
            withColData = FALSE
        )
        rows <- SummarizedExperiment::rowData(guide)
        if (isTRUE(meta$guide_list_rows)) {
            positions <- unlist(
                rows[[guide_columns[["annotation_order"]]]],
                use.names = FALSE
            )
            ordering <- if (length(positions)) order(positions) else integer()
            columns <- lapply(meta$guide_metadata_names, function(n) {
                bind_screen_annotation_column(
                    unname(as.list(rows[[n]])),
                    ordering,
                    meta$guide_column_templates[[n]]
                )
            })
            names(columns) <- meta$guide_metadata_names
            out <- structure(
                columns,
                class = 'data.frame',
                row.names = if (length(positions)) {
                    c(NA_integer_, -length(positions))
                } else {
                    integer()
                }
            )
            original_rows <- if (isTRUE(meta$guide_rowname_column)) {
                unlist(
                    rows[[guide_columns[["legacy_rowname"]]]],
                    use.names = FALSE
                )[ordering]
            } else {
                NULL
            }
        } else {
            positions <- which(
                !is.na(rows[[guide_columns[["annotation_order"]]]])
            )
            positions <- positions[order(rows[[guide_columns[[
                "annotation_order"
            ]]]][positions])]
            selected <- rows[positions, , drop = FALSE]
            columns <- stats::setNames(
                lapply(meta$guide_metadata_names, function(n) {
                    value <- selected[[n]]
                    template <- meta$guide_column_templates[[n]]
                    if (is.null(value) && !is.null(template)) {
                        value <- template$prototype
                    }
                    restore_screen_column(value, template)
                }),
                meta$guide_metadata_names
            )
            out <- structure(
                columns,
                class = 'data.frame',
                row.names = if (length(positions)) {
                    rownames(selected)
                } else {
                    integer()
                }
            )
            original_rows <- if (isTRUE(meta$guide_rowname_column)) {
                selected[[guide_columns[["legacy_rowname"]]]]
            } else {
                NULL
            }
        }
        if (!nrow(out)) {
            attr(out, 'row.names') <- if (
                meta$guide_rowname_type == 'character'
            ) {
                character()
            } else {
                integer()
            }
        } else if (isTRUE(meta$guide_automatic_rownames)) {
            attr(out, 'row.names') <- if (nrow(out)) {
                c(NA_integer_, -nrow(out))
            } else {
                integer()
            }
        } else if (isTRUE(meta$guide_rowname_column)) {
            attr(out, 'row.names') <- if (
                meta$guide_rowname_type == 'integer'
            ) {
                as.integer(original_rows)
            } else {
                as.character(original_rows)
            }
        }
        return(out)
    }
    if (name == 'import_grna_assignment_info') {
        cd <- SummarizedExperiment::colData(x)
        return(stats::setNames(
            lapply(meta$guide_summary_names, function(n) {
                v <- cd[[cell_columns[[n]]]]
                if (is.null(v)) {
                    if (n == 'max_grna') character() else numeric()
                } else {
                    v
                }
            }),
            meta$guide_summary_names
        ))
    }
    if (name %in% c('identity', 'low_moi')) {
        return(meta[[name]])
    }
    stop('Unknown screen field: ', name)
}


# Historical data layouts are decoded only here; current data has no parent maps.
migrate_screen_data_to_sce <- function(data) {
    if (methods::is(data, "SingleCellExperiment")) {
        meta <- screen_meta(data)
        if (identical(meta$layout, 2L)) return(data)
        if (identical(meta$layout, 1L)) {
            guide <- screen_guides(data)
            cd <- SummarizedExperiment::colData(data)
            values <- list(
                response_matrix = screen_response_counts(data),
                grna_matrix = screen_guide_counts(data),
                covariate_data_frame = cd[, meta$covariate_names, drop = FALSE],
                grna_target_data_frame = S4Vectors::metadata(guide)$sceptre_annotations,
                response_names = screen_response_names(data),
                low_moi = meta$low_moi,
                import_grna_assignment_info = stats::setNames(
                    lapply(meta$guide_summary_columns, function(name) cd[[name]]),
                    names(meta$guide_summary_columns)
                ),
                identity = meta$identity
            )
            out <- do.call(new_screen_experiment, values)
            if (!is.null(meta$backing_stores)) screen_backing_anchors(out) <- meta$backing_stores
            return(out)
        }
        if (!is.null(meta$layout)) {
            stop("Unsupported native screen data layout.")
        }
        fields <- names(formals(new_screen_experiment))
        values <- stats::setNames(
            lapply(fields, function(name) legacy_screen_field(data, name)), fields
        )
    } else {
        fields <- names(formals(new_screen_experiment))
        physical <- attributes(data)
        values <- physical[intersect(fields, names(physical))]
    }
    do.call(new_screen_experiment, values)
}
