# Count matrices are ordinary Bioconductor values. Native readers are opened
# transiently by numerical operations and are never attached to these objects.
# Coercion and checked access preserve ordinary DelayedMatrix values.
as_count_matrix <- function(x, descriptor = NULL) {
    if (is.null(x)) {
        if (!is.null(descriptor)) {
            stop(
                "Legacy ondisc descriptors require explicit conversion or reimport with native HDF5 counts."
            )
        }
        return(DelayedArray::DelayedArray(matrix(numeric(), 0L, 0L)))
    }
    if (
        inherits(x, "odm") ||
            identical(as.character(class(x))[1L], "BackedCountStore")
    ) {
        stop(
            "Legacy ondisc counts require explicit conversion or reimport with native HDF5 counts."
        )
    }
    if (!methods::is(x, "DelayedMatrix")) {
        if (!is.matrix(x) && !methods::is(x, "Matrix")) {
            stop(
                "Count matrices must be Matrix, ordinary matrix or DelayedMatrix objects."
            )
        }
        x <- DelayedArray::DelayedArray(x)
    }
    if (!is.null(descriptor)) {
        validate_count_backing(x, descriptor)
    }
    x
}

require_count_matrix <- function(x) {
    if (!methods::is(x, "DelayedMatrix")) {
        stop("Count matrix is unavailable; import native counts.")
    }
    x
}
