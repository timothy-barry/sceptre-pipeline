# Standard matrices remain ordinary matrix descriptors in saved objects. Native
# handles are created inside a storage operation and never attached to an assay
# or sceptre object, so reopening starts from the saved matrix descriptor.

#' Identify a standard matrix handled by the native storage adapter
#' @param x A count matrix.
#' @return TRUE for a DelayedMatrix, including HDF5Array matrix subclasses.
#' @noRd
storage_is_standard_matrix <- function(x) {
    methods::is(x, "DelayedMatrix")
}

#' Check the native matrix tree using metadata alone
#' @param matrix_in A standard count matrix descriptor.
#' @return Whether the supported tree contains an HDF5 seed.
#' @noRd
storage_standard_native_tree <- function(matrix_in) {
    inspect <- function(node, depth = 0L) {
        if (depth > 128L) {
            stop("Standard count matrix has too many delayed wrappers.")
        }
        if (methods::is(node, "DelayedMatrix")) {
            return(inspect(methods::slot(node, "seed"), depth + 1L))
        }
        wrappers <- c("DelayedSubset", "DelayedAperm", "DelayedSetDimnames")
        if (
            any(vapply(
                wrappers,
                function(cl) methods::is(node, cl),
                logical(1)
            ))
        ) {
            return(inspect(methods::slot(node, "seed"), depth + 1L))
        }
        if (methods::is(node, "H5SparseMatrixSeed")) {
            methods::validObject(node, complete = TRUE)
            row_compressed <- methods::is(node, "CSR_H5SparseMatrixSeed")
            if (
                !row_compressed && !methods::is(node, "CSC_H5SparseMatrixSeed")
            ) {
                stop(
                    "Native HDF5 sparse seeds require a known compressed layout."
                )
            }
            ranges <- methods::slot(node, "indptr_ranges")
            if (
                !is.data.frame(ranges) ||
                    !all(c("start", "width") %in% names(ranges))
            ) {
                stop("Invalid native HDF5 sparse pointer-range metadata.")
            }
            standard_matrix_validate_h5_ranges_cpp(
                methods::slot(node, "dim"),
                ranges$start,
                ranges$width,
                row_compressed
            )
            return(TRUE)
        }
        if (methods::is(node, "HDF5ArraySeed")) {
            methods::validObject(node, complete = TRUE)
            return(TRUE)
        }
        if (methods::is(node, "SVT_SparseMatrix")) {
            methods::validObject(node, complete = TRUE)
            standard_matrix_validate_svt_cpp(node)
            return(FALSE)
        }
        ordinary <- c("dgCMatrix", "dgRMatrix", "dgeMatrix")
        if (
            is.matrix(node) ||
                any(vapply(
                    ordinary,
                    function(cl) methods::is(node, cl),
                    logical(1)
                ))
        ) {
            if (methods::is(node, "Matrix")) {
                methods::validObject(node, complete = TRUE)
            }
            return(FALSE)
        }
        stop(
            "Standard storage requires a native raw-count seed with only ",
            "subsetting, transposition or dimname wrappers; unsupported node: ",
            class(node)[1L],
            "."
        )
    }
    inspect(matrix_in)
}

#' Create a transient native reader for a standard count matrix
#' @param matrix_in A standard count matrix with native beachmat support.
#' @return Process-local external pointer. Never save this pointer.
#' @noRd
storage_standard_handle <- function(matrix_in) {
    needs_hdf5 <- storage_standard_native_tree(matrix_in)
    if (!requireNamespace("beachmat", quietly = TRUE)) {
        stop("Standard matrix storage requires the beachmat package.")
    }
    # Register direct HDF5 methods before initialization. Without the extension,
    # beachmat can fall back to R block processing, which is not admitted here.
    if (needs_hdf5) {
        if (!requireNamespace("beachmat.hdf5", quietly = TRUE)) {
            stop("Standard HDF5 storage requires the beachmat.hdf5 package.")
        }
    }
    arguments <- list(
        x = matrix_in,
        hdf5.realize = FALSE,
        memorize = FALSE,
        hdf5.cache.size = 8L * 1024L * 1024L
    )
    # beachmat 2.26 is the R 4.5 / Bioconductor 3.22 implementation of this
    # native API. It predates .unknown.action; the metadata gate above ensures
    # that only native-supported trees reach either release's initializer.
    if (utils::packageVersion("beachmat") >= "2.28.0") {
        arguments$.unknown.action <- "error"
    }
    do.call(beachmat::initializeCpp, arguments)
}

#' Bound native cache and file lifetimes to one storage operation
#' @param matrix_in A standard count matrix descriptor.
#' @param FUN Native consumer whose first argument is the initialized handle.
#' @param ... Remaining consumer arguments.
#' @return The consumer's result, after releasing the native reader.
#' @noRd
storage_standard_call <- function(matrix_in, FUN, ...) {
    handle <- storage_standard_handle(matrix_in)
    on.exit(standard_matrix_release_cpp(handle), add = TRUE)
    FUN(handle, ...)
}

#' Admit a native matrix tree using metadata alone
#' @param matrix_in A standard matrix descriptor.
#' @return The unchanged matrix after checking dimensions, native support and
#'   numeric storage type. Count values are checked by a native scan separately.
#' @noRd
storage_standard_admission <- function(matrix_in) {
    if (!storage_is_standard_matrix(matrix_in)) {
        stop("Standard storage requires a DelayedMatrix or HDF5Array matrix.")
    }
    storage_standard_native_tree(matrix_in)
    d <- dim(matrix_in)
    if (length(d) != 2L || anyNA(d) || any(d < 0 | d > .Machine$integer.max)) {
        stop("Standard matrix dimensions exceed native coordinate capacity.")
    }
    if (!DelayedArray::type(matrix_in) %in% c("integer", "double")) {
        stop("Standard count matrices must contain numeric integer UMI counts.")
    }
    matrix_in
}

#' Check a standard integer UMI matrix without changing its physical storage
#' @inheritParams storage_standard_admission
#' @return The unchanged matrix after admission and validation of finite
#'   nonnegative integer UMI counts. Fractional counts are not admitted.
#' @noRd
storage_prepare_standard_matrix <- function(matrix_in) {
    storage_standard_admission(matrix_in)
    storage_standard_call(matrix_in, standard_matrix_validate_cpp)
    matrix_in
}

#' Open a worker-local reader with a fixed analysis-cell view
#' @inheritParams storage_read_response
#' @return A list with read(response_idx) and idempotent close() functions.
#' @details Create this reader inside the worker process and close it on exit.
#'   It retains the ordinary descriptor and a native extractor only for that
#'   scope; neither the reader nor its pointer belongs in a saved screen object.
#' @noRd
storage_standard_open_response_reader <- function(store, source_cells) {
    handle <- storage_standard_handle(store)
    on.exit(standard_matrix_release_cpp(handle), add = TRUE)
    reader <- NULL
    complete <- FALSE
    on.exit(
        {
            if (!complete && !is.null(reader)) {
                standard_matrix_close_response_reader_cpp(reader)
            }
        },
        add = TRUE
    )
    reader <- standard_matrix_open_response_reader_cpp(
        handle,
        if (is.null(source_cells)) NULL else as.integer(source_cells)
    )
    out <- list(
        read = function(response_idx) {
            standard_matrix_read_response_cpp(reader, as.integer(response_idx))
        },
        close = function() {
            standard_matrix_close_response_reader_cpp(reader)
            invisible(NULL)
        }
    )
    complete <- TRUE
    out
}

#' Read a standard count row without materializing unselected cells
#' @inheritParams storage_read_response
#' @return Numeric counts in the requested order, including repeated cells.
#' @noRd
storage_standard_read_response <- function(store, response_idx, source_cells) {
    storage_standard_call(
        store,
        standard_matrix_read_row_cpp,
        as.integer(response_idx),
        if (is.null(source_cells)) NULL else as.integer(source_cells)
    )
}

#' Read a batch of guide thresholds with one native data pass
#' @inheritParams storage_threshold_rows
#' @return List of exact-size cell-position vectors in feature request order.
#' @details Only the transient context owns native scratch/extractors while R
#'   allocates results. Cleanup is registered before context construction, so R
#'   allocation errors and native errors both close its backing resources.
#' @noRd
storage_standard_threshold_rows <- function(store, feature_idxs, threshold) {
    handle <- storage_standard_handle(store)
    on.exit(standard_matrix_release_cpp(handle), add = TRUE)
    reader <- NULL
    on.exit(
        {
            if (!is.null(reader)) {
                standard_matrix_close_threshold_reader_cpp(reader)
            }
        },
        add = TRUE
    )
    reader <- standard_matrix_open_threshold_reader_cpp(handle)
    standard_matrix_threshold_rows_cpp(
        reader,
        as.integer(feature_idxs),
        as.numeric(threshold)
    )
}
