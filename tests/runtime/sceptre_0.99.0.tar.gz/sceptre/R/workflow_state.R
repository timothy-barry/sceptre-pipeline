# A preparation stage exists only after successful validation. Results are
# completed records with their own scientific input identity. No call journal or
# duplicate workflow flags are saved in the public coordinator.
# Formula environments are execution contexts, not stable value identities. The
# actual compiled design and durable assignment values are fingerprinted below.
identity_value <- function(x) {
    if (inherits(x, "formula")) {
        return(list(formula = paste(deparse(x), collapse = "")))
    }
    if (is.list(x) && !is.data.frame(x)) {
        return(lapply(x, identity_value))
    }
    x
}

preparation_stage_names <- function() {
    c("design", "assignment", "cell_qc", "pair_qc")
}

preparation_stage_inputs <- function(object, stage) {
    p <- object@preparation
    s <- object@spec
    inputs <- switch(
        stage,
        design = list(
            screen_identity(object@data),
            s@formula_object,
            s@grna_integration_strategy,
            s@discovery_pairs,
            s@positive_control_pairs,
            p@design_matrix,
            p@guide_groups,
            p@discovery_pairs,
            p@positive_control_pairs
        ),
        assignment = list(
            screen_identity(object@data),
            s@grna_assignment_method,
            s@grna_assignment_hyperparameters,
            p@guide_groups,
            p@guide_assignments,
            p@source_groups,
            p@assignment_exclusions
        ),
        cell_qc = list(
            screen_identity(object@data),
            p@stages$assignment$identity,
            s@cellwise_qc_thresholds,
            s@additional_cells_to_remove,
            p@analysis_cells,
            p@cell_removal_metrics,
            p@analysis_groups
        ),
        pair_qc = prepared_pair_qc_inputs(object),
        stop("Unknown preparation stage: ", stage)
    )
    inputs
}

stage_input_identity <- function(object, stage, protocol = NULL) {
    if (is.null(protocol)) {
        protocol <- object@preparation@stages[[stage]]$protocol
    }
    inputs <- identity_value(preparation_stage_inputs(object, stage))
    if (identical(protocol, 2L)) {
        scientific_digest(inputs)
    } else {
        digest::digest(inputs, algo = "sha256")
    }
}

# A resolver belongs to exactly one immutable, read-only query. Never retain it
# on an object or reuse it after changing any component. Only scalar results are
# cached, together with small actual-input certificates. Scientific payloads
# are not retained separately; short-circuit guards stay intact.
new_currentness_query <- function(object) {
    force(object)
    stages <- new.env(hash = FALSE, parent = emptyenv())
    results <- new.env(hash = FALSE, parent = emptyenv())
    inputs <- new.env(hash = FALSE, parent = emptyenv())
    scalar_name <- function(x) {
        is.character(x) && length(x) == 1L && !is.na(x)
    }
    check_stage <- function(stage) {
        if (
            !scalar_name(stage) ||
                !stage %in%
                    c(
                        "import_data",
                        "set_analysis_parameters",
                        "assign_grnas",
                        preparation_stage_names(),
                        "run_qc"
                    )
        ) {
            return(currentness_stage_complete(object, stage, query))
        }
        key <- switch(
            stage,
            set_analysis_parameters = "design",
            assign_grnas = "assignment",
            stage
        )
        if (exists(key, envir = stages, inherits = FALSE)) {
            return(get(key, envir = stages, inherits = FALSE))
        }
        value <- currentness_stage_complete(object, stage, query)
        assign(key, value, envir = stages)
        value
    }
    check_result <- function(analysis) {
        if (!scalar_name(analysis) || !analysis %in% analysis_names()) {
            return(currentness_result_record_is_current(
                object,
                analysis,
                query
            ))
        }
        if (exists(analysis, envir = results, inherits = FALSE)) {
            return(get(analysis, envir = results, inherits = FALSE))
        }
        value <- currentness_result_record_is_current(object, analysis, query)
        assign(analysis, value, envir = results)
        value
    }
    check_inputs <- function(protocol) {
        key <- as.character(protocol)
        if (!exists(key, envir = inputs, inherits = FALSE)) {
            assign(
                key,
                analysis_input_identity(object, protocol),
                envir = inputs
            )
        }
        get(key, envir = inputs, inherits = FALSE)
    }
    query <- list(
        stage = check_stage,
        result = check_result,
        plan_inputs = check_inputs
    )
    query
}

stage_complete <- function(object, stage) {
    new_currentness_query(object)$stage(stage)
}

currentness_stage_complete <- function(object, stage, query) {
    if (stage == "import_data") {
        return(length(screen_identity(object@data)) == 1L)
    }
    stage <- switch(
        stage,
        set_analysis_parameters = "design",
        assign_grnas = "assignment",
        stage
    )
    if (stage == "run_qc") {
        return(
            query$stage("cell_qc") &&
                query$stage("pair_qc")
        )
    }
    if (!stage %in% preparation_stage_names()) {
        stop("Unknown preparation stage: ", stage)
    }
    record <- object@preparation@stages[[stage]]
    if (!is.list(record) || is.null(record$identity)) {
        return(FALSE)
    }
    if (!is.null(record$protocol) && !identical(record$protocol, 2L)) {
        return(FALSE)
    }
    dependency <- switch(
        stage,
        design = "import_data",
        assignment = "design",
        cell_qc = "assignment",
        pair_qc = "cell_qc"
    )
    query$stage(dependency) &&
        identical(record$identity, stage_input_identity(object, stage))
}

require_stage <- function(object, stage, query = NULL) {
    complete <- if (is.null(query)) {
        stage_complete(object, stage)
    } else {
        query$stage(stage)
    }
    if (!complete) {
        public <- switch(
            stage,
            design = "set_analysis_parameters",
            assignment = "assign_grnas",
            cell_qc = "run_qc",
            pair_qc = "run_qc",
            stage
        )
        stop(
            "The function `",
            public,
            "()` must be called successfully before this stage."
        )
    }
    invisible(NULL)
}

begin_preparation_stage <- function(object, stage) {
    stage <- switch(
        stage,
        set_analysis_parameters = "design",
        assign_grnas = "assignment",
        run_qc = "cell_qc",
        stage
    )
    dependency <- switch(
        stage,
        design = "import_data",
        assignment = "design",
        cell_qc = "assignment",
        pair_qc = "cell_qc"
    )
    if (is.null(dependency)) {
        stop("Unknown preparation stage: ", stage)
    }
    require_stage(object, dependency)
    downstream <- switch(
        stage,
        design = preparation_stage_names(),
        assignment = c("assignment", "cell_qc", "pair_qc"),
        cell_qc = c("cell_qc", "pair_qc"),
        pair_qc = "pair_qc"
    )
    object@preparation@stages[downstream] <- NULL
    invalidate_result_records(object, paste(stage, "inputs changed"))
}

commit_preparation_stage <- function(object, stage) {
    validObject(object)
    p <- object@preparation
    if (stage == "design") {
        if (
            nrow(p@design_matrix) != ncol(get_response_matrix(object)) ||
                length(p@guide_groups) !=
                    nrow(screen_guide_annotations(object@data))
        ) {
            stop("Design and guide mapping must align with imported data.")
        }
    } else if (stage == "assignment") {
        if (
            !all(
                c("grna_group_idxs", "indiv_nt_grna_idxs") %in%
                    names(p@source_groups)
            )
        ) {
            stop(
                "Source guide groups must be prepared before assignment is ",
                "committed."
            )
        }
    } else if (stage == "cell_qc") {
        if (
            !length(p@analysis_cells) ||
                !is.list(p@analysis_groups$grna_group_idxs)
        ) {
            stop(
                "Cell QC must produce retained cells and aligned guide groups."
            )
        }
    } else if (stage == "pair_qc") {
        validate_pair_qc_stage(p)
    } else {
        stop("Unknown preparation stage: ", stage)
    }
    object@preparation@stages[[stage]] <- list(
        protocol = 2L,
        identity = stage_input_identity(object, stage, 2L)
    )
    object
}

workflow_status <- function(object) {
    query <- new_currentness_query(object)
    preparation <- c(
        import_data = query$stage("import_data"),
        set_analysis_parameters = query$stage("design"),
        assign_grnas = query$stage("assignment"),
        run_qc = query$stage("run_qc")
    )
    analyses <- names(result_analysis_fields())
    c(
        preparation,
        stats::setNames(
            vapply(
                analyses,
                function(name) query$result(name),
                logical(1)
            ),
            analyses
        )
    )
}

# Validate pair coverage before committing the stage identity.
validate_pair_qc_stage <- function(p) {
    for (type in c("discovery", "positive_control")) {
        pairs <- methods::slot(p, paste0(type, "_pairs_with_info"))
        if (
            nrow(pairs) != nrow(methods::slot(p, paste0(type, "_pairs"))) ||
                (nrow(pairs) &&
                    (!all(
                        c(
                            "response_id",
                            "grna_group",
                            "n_nonzero_trt",
                            "n_nonzero_cntrl",
                            "pass_qc"
                        ) %in%
                            names(pairs)
                    ) ||
                        anyNA(pairs$pass_qc)))
        ) {
            stop(
                "Pair QC must cover the complete prepared hypothesis family."
            )
        }
    }
    invisible(NULL)
}

prepared_pair_qc_inputs <- function(object) {
    p <- object@preparation
    s <- object@spec
    list(
        screen_identity(object@data),
        p@stages$cell_qc$identity,
        s@grna_integration_strategy,
        s@n_nonzero_trt_thresh,
        s@n_nonzero_cntrl_thresh,
        p@discovery_pairs,
        p@positive_control_pairs,
        p@discovery_pairs_with_info,
        p@positive_control_pairs_with_info,
        p@nt_nonzero_matrix,
        p@control_nonzero_totals
    )
}
