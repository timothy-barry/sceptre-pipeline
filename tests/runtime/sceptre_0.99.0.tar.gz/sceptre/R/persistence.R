#' Save and reopen a sceptre object with native count matrices
#'
#' Count matrices contain standard Bioconductor seeds, never live readers.
#' Backing files remain external and immutable. These helpers verify imported
#' content anchors. Ordinary saveRDS/readRDS also preserve the descriptors.
#' @param sceptre_object A sceptre object.
#' @param file Path to an RDS file.
#' @param response_matrix,grna_matrix Optional native descriptors after relocation.
#'   Omit unchanged modalities. Supplied content, views and labels must match
#'   import.
#' @return The reader returns an object; the writer invisibly returns file.
#' @examples
#' response <- matrix(c(1, 0, 2, 3, 1, 0), nrow = 2,
#'     dimnames = list(c("gene1", "gene2"), c("cell1", "cell2", "cell3")))
#' guides <- matrix(c(1, 0, 2), nrow = 1,
#'     dimnames = list("guide1", colnames(response)))
#' annotation <- data.frame(grna_id = "guide1", grna_target = "target1")
#' object <- import_data(response, guides, annotation, moi = "low")
#' local({
#'     path <- tempfile(fileext = ".rds")
#'     on.exit(unlink(path))
#'     write_sceptre_object(object, path)
#'     restored <- read_sceptre_object(path)
#'     stopifnot(identical(get_screen_experiment(restored),
#'         get_screen_experiment(object)))
#' })
#' @export
write_sceptre_object <- function(sceptre_object, file) {
    sceptre_object <- migrate_sceptre_object(sceptre_object)
    validate_count_backing_for_save(sceptre_object)
    base::saveRDS(sceptre_object, file)
    invisible(file)
}

#' @rdname write_sceptre_object
#' @export
read_sceptre_object <- function(
    file,
    response_matrix = NULL,
    grna_matrix = NULL
) {
    object <- migrate_sceptre_object(readRDS(file))
    replacements <- list(response = response_matrix, grna = grna_matrix)
    anchors <- screen_backing_anchors(object@data)
    for (modality in names(replacements)) {
        matrix <- replacements[[modality]]
        if (is.null(matrix)) {
            next
        }
        replacement <- as_count_matrix(matrix)
        anchor <- anchors[[modality]]
        if (is.null(anchor)) {
            if (
                !identical(
                    replacement,
                    screen_count_matrices(object@data)[[modality]]
                )
            ) {
                stop("Relocation cannot change an imported in-memory modality.")
            }
        } else {
            validate_count_backing(replacement, anchor)
        }
        if (modality == "response") {
            screen_response_counts(object@data) <- replacement
        } else {
            screen_guide_counts(object@data) <- replacement
        }
    }
    validate_count_backing_for_save(object)
    validObject(object)
    object
}

#' Save and reopen native counts using historical function names
#'
#' Compatibility names for this candidate's native HDF5 files. Historical ODM
#' files require reimport with the preserved legacy package. Prefer
#' [write_sceptre_object()] and [read_sceptre_object()].
#' @param sceptre_object A sceptre object.
#' @param directory_to_write Directory for sceptre_object.rds.
#' @param sceptre_object_fp Saved RDS path.
#' @param response_odm_file_fp,grna_odm_file_fp Replacement native HDF5 paths,
#'   one per distinct backing file in the saved response or guide matrix, in
#'   saved file order. Saved subsets and permutations are kept.
#' @return The reader returns a sceptre object. The writer returns
#'   `NULL` invisibly.
#' @examples
#' response <- matrix(c(1, 0, 2, 3, 1, 0), nrow = 2,
#'     dimnames = list(c("gene1", "gene2"), c("cell1", "cell2", "cell3")))
#' guides <- matrix(c(1, 0, 2), nrow = 1,
#'     dimnames = list("guide1", colnames(response)))
#' annotation <- data.frame(grna_id = "guide1", grna_target = "target1")
#' local({
#'     directory <- tempfile("sceptre-backed-example-")
#'     dir.create(directory)
#'     on.exit(unlink(directory, recursive = TRUE))
#'     object <- import_data(response, guides, annotation, moi = "low",
#'         use_ondisc = TRUE, directory_to_write = directory)
#'     write_ondisc_backed_sceptre_object(object, directory)
#'     restored <- read_sceptre_object(file.path(directory, "sceptre_object.rds"))
#'     counts <- SummarizedExperiment::assay(get_screen_experiment(restored))
#'     stopifnot(identical(as.matrix(counts), response))
#' })
#' @export
write_ondisc_backed_sceptre_object <- function(
    sceptre_object,
    directory_to_write
) {
    directory <- prepare_directory_to_write(directory_to_write)
    write_sceptre_object(
        sceptre_object,
        file.path(directory, "sceptre_object.rds")
    )
    invisible(NULL)
}

#' @rdname write_ondisc_backed_sceptre_object
#' @export
read_ondisc_backed_sceptre_object <- function(
    sceptre_object_fp,
    response_odm_file_fp,
    grna_odm_file_fp
) {
    saved <- migrate_sceptre_object(readRDS(sceptre_object_fp))
    response <- relocate_native_count_files(
        screen_response_counts(saved@data),
        response_odm_file_fp,
        "response_odm_file_fp"
    )
    grna <- relocate_native_count_files(
        screen_guide_counts(saved@data),
        grna_odm_file_fp,
        "grna_odm_file_fp"
    )
    read_sceptre_object(sceptre_object_fp, response, grna)
}
